gdjs.MainMenuCode = {};
gdjs.MainMenuCode.GDBackgroundObjects1= [];
gdjs.MainMenuCode.GDBackgroundObjects2= [];
gdjs.MainMenuCode.GDBackgroundObjects3= [];
gdjs.MainMenuCode.GDmenuBannerObjects1= [];
gdjs.MainMenuCode.GDmenuBannerObjects2= [];
gdjs.MainMenuCode.GDmenuBannerObjects3= [];
gdjs.MainMenuCode.GDNIGGARIOObjects1= [];
gdjs.MainMenuCode.GDNIGGARIOObjects2= [];
gdjs.MainMenuCode.GDNIGGARIOObjects3= [];
gdjs.MainMenuCode.GDStartButtonObjects1= [];
gdjs.MainMenuCode.GDStartButtonObjects2= [];
gdjs.MainMenuCode.GDStartButtonObjects3= [];
gdjs.MainMenuCode.GDTopScoreObjects1= [];
gdjs.MainMenuCode.GDTopScoreObjects2= [];
gdjs.MainMenuCode.GDTopScoreObjects3= [];
gdjs.MainMenuCode.GDWoldNameObjects1= [];
gdjs.MainMenuCode.GDWoldNameObjects2= [];
gdjs.MainMenuCode.GDWoldNameObjects3= [];
gdjs.MainMenuCode.GDLivesObjects1= [];
gdjs.MainMenuCode.GDLivesObjects2= [];
gdjs.MainMenuCode.GDLivesObjects3= [];
gdjs.MainMenuCode.GDBlackBGObjects1= [];
gdjs.MainMenuCode.GDBlackBGObjects2= [];
gdjs.MainMenuCode.GDBlackBGObjects3= [];
gdjs.MainMenuCode.GDMarioObjects1= [];
gdjs.MainMenuCode.GDMarioObjects2= [];
gdjs.MainMenuCode.GDMarioObjects3= [];


gdjs.MainMenuCode.mapOfGDgdjs_9546MainMenuCode_9546GDStartButtonObjects1Objects = Hashtable.newFrom({"StartButton": gdjs.MainMenuCode.GDStartButtonObjects1});
gdjs.MainMenuCode.asyncCallback17509508 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Level1", false);
}}
gdjs.MainMenuCode.eventsList0 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(3), (runtimeScene) => (gdjs.MainMenuCode.asyncCallback17509508(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainMenuCode.asyncCallback17510580 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("StartButton"), gdjs.MainMenuCode.GDStartButtonObjects3);

{for(var i = 0, len = gdjs.MainMenuCode.GDStartButtonObjects3.length ;i < len;++i) {
    gdjs.MainMenuCode.GDStartButtonObjects3[i].setOpacity(255);
}
}}
gdjs.MainMenuCode.eventsList1 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.MainMenuCode.GDStartButtonObjects2) asyncObjectsList.addObject("StartButton", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.MainMenuCode.asyncCallback17510580(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainMenuCode.asyncCallback17510132 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("StartButton"), gdjs.MainMenuCode.GDStartButtonObjects2);
{for(var i = 0, len = gdjs.MainMenuCode.GDStartButtonObjects2.length ;i < len;++i) {
    gdjs.MainMenuCode.GDStartButtonObjects2[i].setOpacity(100);
}
}
{ //Subevents
gdjs.MainMenuCode.eventsList1(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.MainMenuCode.eventsList2 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.MainMenuCode.asyncCallback17510132(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainMenuCode.eventsList3 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Background"), gdjs.MainMenuCode.GDBackgroundObjects1);
gdjs.copyArray(runtimeScene.getObjects("BlackBG"), gdjs.MainMenuCode.GDBlackBGObjects1);
gdjs.copyArray(runtimeScene.getObjects("Lives"), gdjs.MainMenuCode.GDLivesObjects1);
gdjs.copyArray(runtimeScene.getObjects("Mario"), gdjs.MainMenuCode.GDMarioObjects1);
gdjs.copyArray(runtimeScene.getObjects("TopScore"), gdjs.MainMenuCode.GDTopScoreObjects1);
gdjs.copyArray(runtimeScene.getObjects("WoldName"), gdjs.MainMenuCode.GDWoldNameObjects1);
{gdjs.evtTools.storage.readNumberFromJSONFile("MarioCopy", "Score", runtimeScene, runtimeScene.getScene().getVariables().getFromIndex(0));
}{for(var i = 0, len = gdjs.MainMenuCode.GDBackgroundObjects1.length ;i < len;++i) {
    gdjs.MainMenuCode.GDBackgroundObjects1[i].setColor("202;202;202");
}
}{gdjs.evtTools.window.setFullScreen(runtimeScene, true, true);
}{for(var i = 0, len = gdjs.MainMenuCode.GDBlackBGObjects1.length ;i < len;++i) {
    gdjs.MainMenuCode.GDBlackBGObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.MainMenuCode.GDMarioObjects1.length ;i < len;++i) {
    gdjs.MainMenuCode.GDMarioObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.MainMenuCode.GDWoldNameObjects1.length ;i < len;++i) {
    gdjs.MainMenuCode.GDWoldNameObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.MainMenuCode.GDLivesObjects1.length ;i < len;++i) {
    gdjs.MainMenuCode.GDLivesObjects1[i].hide();
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "MenuTimer");
}{for(var i = 0, len = gdjs.MainMenuCode.GDTopScoreObjects1.length ;i < len;++i) {
    gdjs.MainMenuCode.GDTopScoreObjects1[i].setBBText("TOP - " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0))));
}
}{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)));
}{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "New Super Mario Bros. U Overworld 8 Bit.mp3", 1, false, 30, 1);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Escape");
if (isConditionTrue_0) {
{gdjs.evtTools.window.setFullScreen(runtimeScene, false, true);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("StartButton"), gdjs.MainMenuCode.GDStartButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.MainMenuCode.mapOfGDgdjs_9546MainMenuCode_9546GDStartButtonObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("BlackBG"), gdjs.MainMenuCode.GDBlackBGObjects1);
gdjs.copyArray(runtimeScene.getObjects("Lives"), gdjs.MainMenuCode.GDLivesObjects1);
gdjs.copyArray(runtimeScene.getObjects("Mario"), gdjs.MainMenuCode.GDMarioObjects1);
gdjs.copyArray(runtimeScene.getObjects("WoldName"), gdjs.MainMenuCode.GDWoldNameObjects1);
{for(var i = 0, len = gdjs.MainMenuCode.GDBlackBGObjects1.length ;i < len;++i) {
    gdjs.MainMenuCode.GDBlackBGObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.MainMenuCode.GDMarioObjects1.length ;i < len;++i) {
    gdjs.MainMenuCode.GDMarioObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.MainMenuCode.GDWoldNameObjects1.length ;i < len;++i) {
    gdjs.MainMenuCode.GDWoldNameObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.MainMenuCode.GDLivesObjects1.length ;i < len;++i) {
    gdjs.MainMenuCode.GDLivesObjects1[i].hide(false);
}
}
{ //Subevents
gdjs.MainMenuCode.eventsList0(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "MenuTimer") >= 1;
if (isConditionTrue_0) {

{ //Subevents
gdjs.MainMenuCode.eventsList2(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "MenuTimer") >= 2;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "MenuTimer");
}}

}


{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.storage.writeNumberInJSONFile("MarioCopy", "Score", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)));
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("BlackBG"), gdjs.MainMenuCode.GDBlackBGObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainMenuCode.GDBlackBGObjects1.length;i<l;++i) {
    if ( gdjs.MainMenuCode.GDBlackBGObjects1[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.MainMenuCode.GDBlackBGObjects1[k] = gdjs.MainMenuCode.GDBlackBGObjects1[i];
        ++k;
    }
}
gdjs.MainMenuCode.GDBlackBGObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.sound.setSoundOnChannelVolume(runtimeScene, 1, gdjs.evtTools.sound.getSoundOnChannelVolume(runtimeScene, 1) - (1));
}}

}


};

gdjs.MainMenuCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.MainMenuCode.GDBackgroundObjects1.length = 0;
gdjs.MainMenuCode.GDBackgroundObjects2.length = 0;
gdjs.MainMenuCode.GDBackgroundObjects3.length = 0;
gdjs.MainMenuCode.GDmenuBannerObjects1.length = 0;
gdjs.MainMenuCode.GDmenuBannerObjects2.length = 0;
gdjs.MainMenuCode.GDmenuBannerObjects3.length = 0;
gdjs.MainMenuCode.GDNIGGARIOObjects1.length = 0;
gdjs.MainMenuCode.GDNIGGARIOObjects2.length = 0;
gdjs.MainMenuCode.GDNIGGARIOObjects3.length = 0;
gdjs.MainMenuCode.GDStartButtonObjects1.length = 0;
gdjs.MainMenuCode.GDStartButtonObjects2.length = 0;
gdjs.MainMenuCode.GDStartButtonObjects3.length = 0;
gdjs.MainMenuCode.GDTopScoreObjects1.length = 0;
gdjs.MainMenuCode.GDTopScoreObjects2.length = 0;
gdjs.MainMenuCode.GDTopScoreObjects3.length = 0;
gdjs.MainMenuCode.GDWoldNameObjects1.length = 0;
gdjs.MainMenuCode.GDWoldNameObjects2.length = 0;
gdjs.MainMenuCode.GDWoldNameObjects3.length = 0;
gdjs.MainMenuCode.GDLivesObjects1.length = 0;
gdjs.MainMenuCode.GDLivesObjects2.length = 0;
gdjs.MainMenuCode.GDLivesObjects3.length = 0;
gdjs.MainMenuCode.GDBlackBGObjects1.length = 0;
gdjs.MainMenuCode.GDBlackBGObjects2.length = 0;
gdjs.MainMenuCode.GDBlackBGObjects3.length = 0;
gdjs.MainMenuCode.GDMarioObjects1.length = 0;
gdjs.MainMenuCode.GDMarioObjects2.length = 0;
gdjs.MainMenuCode.GDMarioObjects3.length = 0;

gdjs.MainMenuCode.eventsList3(runtimeScene);

return;

}

gdjs['MainMenuCode'] = gdjs.MainMenuCode;
