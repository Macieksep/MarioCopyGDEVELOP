gdjs.Level1Code = {};
gdjs.Level1Code.forEachIndex3 = 0;

gdjs.Level1Code.forEachObjects3 = [];

gdjs.Level1Code.forEachTemporary3 = null;

gdjs.Level1Code.forEachTotalCount3 = 0;

gdjs.Level1Code.GDPlayerObjects1= [];
gdjs.Level1Code.GDPlayerObjects2= [];
gdjs.Level1Code.GDPlayerObjects3= [];
gdjs.Level1Code.GDPlayerObjects4= [];
gdjs.Level1Code.GDPlayerObjects5= [];
gdjs.Level1Code.GDPlayerObjects6= [];
gdjs.Level1Code.GDGroundObjects1= [];
gdjs.Level1Code.GDGroundObjects2= [];
gdjs.Level1Code.GDGroundObjects3= [];
gdjs.Level1Code.GDGroundObjects4= [];
gdjs.Level1Code.GDGroundObjects5= [];
gdjs.Level1Code.GDGroundObjects6= [];
gdjs.Level1Code.GDUndergroundGroundObjects1= [];
gdjs.Level1Code.GDUndergroundGroundObjects2= [];
gdjs.Level1Code.GDUndergroundGroundObjects3= [];
gdjs.Level1Code.GDUndergroundGroundObjects4= [];
gdjs.Level1Code.GDUndergroundGroundObjects5= [];
gdjs.Level1Code.GDUndergroundGroundObjects6= [];
gdjs.Level1Code.GDPipeObjects1= [];
gdjs.Level1Code.GDPipeObjects2= [];
gdjs.Level1Code.GDPipeObjects3= [];
gdjs.Level1Code.GDPipeObjects4= [];
gdjs.Level1Code.GDPipeObjects5= [];
gdjs.Level1Code.GDPipeObjects6= [];
gdjs.Level1Code.GDPipe2Objects1= [];
gdjs.Level1Code.GDPipe2Objects2= [];
gdjs.Level1Code.GDPipe2Objects3= [];
gdjs.Level1Code.GDPipe2Objects4= [];
gdjs.Level1Code.GDPipe2Objects5= [];
gdjs.Level1Code.GDPipe2Objects6= [];
gdjs.Level1Code.GDPipeLengthObjects1= [];
gdjs.Level1Code.GDPipeLengthObjects2= [];
gdjs.Level1Code.GDPipeLengthObjects3= [];
gdjs.Level1Code.GDPipeLengthObjects4= [];
gdjs.Level1Code.GDPipeLengthObjects5= [];
gdjs.Level1Code.GDPipeLengthObjects6= [];
gdjs.Level1Code.GDLuckyBlockObjects1= [];
gdjs.Level1Code.GDLuckyBlockObjects2= [];
gdjs.Level1Code.GDLuckyBlockObjects3= [];
gdjs.Level1Code.GDLuckyBlockObjects4= [];
gdjs.Level1Code.GDLuckyBlockObjects5= [];
gdjs.Level1Code.GDLuckyBlockObjects6= [];
gdjs.Level1Code.GDInvisibleLuckyBlockObjects1= [];
gdjs.Level1Code.GDInvisibleLuckyBlockObjects2= [];
gdjs.Level1Code.GDInvisibleLuckyBlockObjects3= [];
gdjs.Level1Code.GDInvisibleLuckyBlockObjects4= [];
gdjs.Level1Code.GDInvisibleLuckyBlockObjects5= [];
gdjs.Level1Code.GDInvisibleLuckyBlockObjects6= [];
gdjs.Level1Code.GDBrickObjects1= [];
gdjs.Level1Code.GDBrickObjects2= [];
gdjs.Level1Code.GDBrickObjects3= [];
gdjs.Level1Code.GDBrickObjects4= [];
gdjs.Level1Code.GDBrickObjects5= [];
gdjs.Level1Code.GDBrickObjects6= [];
gdjs.Level1Code.GDUndergroundBrickObjects1= [];
gdjs.Level1Code.GDUndergroundBrickObjects2= [];
gdjs.Level1Code.GDUndergroundBrickObjects3= [];
gdjs.Level1Code.GDUndergroundBrickObjects4= [];
gdjs.Level1Code.GDUndergroundBrickObjects5= [];
gdjs.Level1Code.GDUndergroundBrickObjects6= [];
gdjs.Level1Code.GDStoneObjects1= [];
gdjs.Level1Code.GDStoneObjects2= [];
gdjs.Level1Code.GDStoneObjects3= [];
gdjs.Level1Code.GDStoneObjects4= [];
gdjs.Level1Code.GDStoneObjects5= [];
gdjs.Level1Code.GDStoneObjects6= [];
gdjs.Level1Code.GDNicknameObjects1= [];
gdjs.Level1Code.GDNicknameObjects2= [];
gdjs.Level1Code.GDNicknameObjects3= [];
gdjs.Level1Code.GDNicknameObjects4= [];
gdjs.Level1Code.GDNicknameObjects5= [];
gdjs.Level1Code.GDNicknameObjects6= [];
gdjs.Level1Code.GDTimeObjects1= [];
gdjs.Level1Code.GDTimeObjects2= [];
gdjs.Level1Code.GDTimeObjects3= [];
gdjs.Level1Code.GDTimeObjects4= [];
gdjs.Level1Code.GDTimeObjects5= [];
gdjs.Level1Code.GDTimeObjects6= [];
gdjs.Level1Code.GDWorldObjects1= [];
gdjs.Level1Code.GDWorldObjects2= [];
gdjs.Level1Code.GDWorldObjects3= [];
gdjs.Level1Code.GDWorldObjects4= [];
gdjs.Level1Code.GDWorldObjects5= [];
gdjs.Level1Code.GDWorldObjects6= [];
gdjs.Level1Code.GDPointsObjects1= [];
gdjs.Level1Code.GDPointsObjects2= [];
gdjs.Level1Code.GDPointsObjects3= [];
gdjs.Level1Code.GDPointsObjects4= [];
gdjs.Level1Code.GDPointsObjects5= [];
gdjs.Level1Code.GDPointsObjects6= [];
gdjs.Level1Code.GDCoinAmmoutObjects1= [];
gdjs.Level1Code.GDCoinAmmoutObjects2= [];
gdjs.Level1Code.GDCoinAmmoutObjects3= [];
gdjs.Level1Code.GDCoinAmmoutObjects4= [];
gdjs.Level1Code.GDCoinAmmoutObjects5= [];
gdjs.Level1Code.GDCoinAmmoutObjects6= [];
gdjs.Level1Code.GDLivesAmmoutObjects1= [];
gdjs.Level1Code.GDLivesAmmoutObjects2= [];
gdjs.Level1Code.GDLivesAmmoutObjects3= [];
gdjs.Level1Code.GDLivesAmmoutObjects4= [];
gdjs.Level1Code.GDLivesAmmoutObjects5= [];
gdjs.Level1Code.GDLivesAmmoutObjects6= [];
gdjs.Level1Code.GDTimeLeftObjects1= [];
gdjs.Level1Code.GDTimeLeftObjects2= [];
gdjs.Level1Code.GDTimeLeftObjects3= [];
gdjs.Level1Code.GDTimeLeftObjects4= [];
gdjs.Level1Code.GDTimeLeftObjects5= [];
gdjs.Level1Code.GDTimeLeftObjects6= [];
gdjs.Level1Code.GDPolePointsObjects1= [];
gdjs.Level1Code.GDPolePointsObjects2= [];
gdjs.Level1Code.GDPolePointsObjects3= [];
gdjs.Level1Code.GDPolePointsObjects4= [];
gdjs.Level1Code.GDPolePointsObjects5= [];
gdjs.Level1Code.GDPolePointsObjects6= [];
gdjs.Level1Code.GDLevelObjects1= [];
gdjs.Level1Code.GDLevelObjects2= [];
gdjs.Level1Code.GDLevelObjects3= [];
gdjs.Level1Code.GDLevelObjects4= [];
gdjs.Level1Code.GDLevelObjects5= [];
gdjs.Level1Code.GDLevelObjects6= [];
gdjs.Level1Code.GDGameOverObjects1= [];
gdjs.Level1Code.GDGameOverObjects2= [];
gdjs.Level1Code.GDGameOverObjects3= [];
gdjs.Level1Code.GDGameOverObjects4= [];
gdjs.Level1Code.GDGameOverObjects5= [];
gdjs.Level1Code.GDGameOverObjects6= [];
gdjs.Level1Code.GDBackgroundImgObjects1= [];
gdjs.Level1Code.GDBackgroundImgObjects2= [];
gdjs.Level1Code.GDBackgroundImgObjects3= [];
gdjs.Level1Code.GDBackgroundImgObjects4= [];
gdjs.Level1Code.GDBackgroundImgObjects5= [];
gdjs.Level1Code.GDBackgroundImgObjects6= [];
gdjs.Level1Code.GDBorderObjects1= [];
gdjs.Level1Code.GDBorderObjects2= [];
gdjs.Level1Code.GDBorderObjects3= [];
gdjs.Level1Code.GDBorderObjects4= [];
gdjs.Level1Code.GDBorderObjects5= [];
gdjs.Level1Code.GDBorderObjects6= [];
gdjs.Level1Code.GDMushroom1Objects1= [];
gdjs.Level1Code.GDMushroom1Objects2= [];
gdjs.Level1Code.GDMushroom1Objects3= [];
gdjs.Level1Code.GDMushroom1Objects4= [];
gdjs.Level1Code.GDMushroom1Objects5= [];
gdjs.Level1Code.GDMushroom1Objects6= [];
gdjs.Level1Code.GDMushroom2Objects1= [];
gdjs.Level1Code.GDMushroom2Objects2= [];
gdjs.Level1Code.GDMushroom2Objects3= [];
gdjs.Level1Code.GDMushroom2Objects4= [];
gdjs.Level1Code.GDMushroom2Objects5= [];
gdjs.Level1Code.GDMushroom2Objects6= [];
gdjs.Level1Code.GDMushroom3Objects1= [];
gdjs.Level1Code.GDMushroom3Objects2= [];
gdjs.Level1Code.GDMushroom3Objects3= [];
gdjs.Level1Code.GDMushroom3Objects4= [];
gdjs.Level1Code.GDMushroom3Objects5= [];
gdjs.Level1Code.GDMushroom3Objects6= [];
gdjs.Level1Code.GDMushroom4Objects1= [];
gdjs.Level1Code.GDMushroom4Objects2= [];
gdjs.Level1Code.GDMushroom4Objects3= [];
gdjs.Level1Code.GDMushroom4Objects4= [];
gdjs.Level1Code.GDMushroom4Objects5= [];
gdjs.Level1Code.GDMushroom4Objects6= [];
gdjs.Level1Code.GDMushroom5Objects1= [];
gdjs.Level1Code.GDMushroom5Objects2= [];
gdjs.Level1Code.GDMushroom5Objects3= [];
gdjs.Level1Code.GDMushroom5Objects4= [];
gdjs.Level1Code.GDMushroom5Objects5= [];
gdjs.Level1Code.GDMushroom5Objects6= [];
gdjs.Level1Code.GDMushroom6Objects1= [];
gdjs.Level1Code.GDMushroom6Objects2= [];
gdjs.Level1Code.GDMushroom6Objects3= [];
gdjs.Level1Code.GDMushroom6Objects4= [];
gdjs.Level1Code.GDMushroom6Objects5= [];
gdjs.Level1Code.GDMushroom6Objects6= [];
gdjs.Level1Code.GDMushroom7Objects1= [];
gdjs.Level1Code.GDMushroom7Objects2= [];
gdjs.Level1Code.GDMushroom7Objects3= [];
gdjs.Level1Code.GDMushroom7Objects4= [];
gdjs.Level1Code.GDMushroom7Objects5= [];
gdjs.Level1Code.GDMushroom7Objects6= [];
gdjs.Level1Code.GDMushroom8Objects1= [];
gdjs.Level1Code.GDMushroom8Objects2= [];
gdjs.Level1Code.GDMushroom8Objects3= [];
gdjs.Level1Code.GDMushroom8Objects4= [];
gdjs.Level1Code.GDMushroom8Objects5= [];
gdjs.Level1Code.GDMushroom8Objects6= [];
gdjs.Level1Code.GDMushroom9Objects1= [];
gdjs.Level1Code.GDMushroom9Objects2= [];
gdjs.Level1Code.GDMushroom9Objects3= [];
gdjs.Level1Code.GDMushroom9Objects4= [];
gdjs.Level1Code.GDMushroom9Objects5= [];
gdjs.Level1Code.GDMushroom9Objects6= [];
gdjs.Level1Code.GDMushroom10Objects1= [];
gdjs.Level1Code.GDMushroom10Objects2= [];
gdjs.Level1Code.GDMushroom10Objects3= [];
gdjs.Level1Code.GDMushroom10Objects4= [];
gdjs.Level1Code.GDMushroom10Objects5= [];
gdjs.Level1Code.GDMushroom10Objects6= [];
gdjs.Level1Code.GDMushroom11Objects1= [];
gdjs.Level1Code.GDMushroom11Objects2= [];
gdjs.Level1Code.GDMushroom11Objects3= [];
gdjs.Level1Code.GDMushroom11Objects4= [];
gdjs.Level1Code.GDMushroom11Objects5= [];
gdjs.Level1Code.GDMushroom11Objects6= [];
gdjs.Level1Code.GDMushroom12Objects1= [];
gdjs.Level1Code.GDMushroom12Objects2= [];
gdjs.Level1Code.GDMushroom12Objects3= [];
gdjs.Level1Code.GDMushroom12Objects4= [];
gdjs.Level1Code.GDMushroom12Objects5= [];
gdjs.Level1Code.GDMushroom12Objects6= [];
gdjs.Level1Code.GDGoLeft1Objects1= [];
gdjs.Level1Code.GDGoLeft1Objects2= [];
gdjs.Level1Code.GDGoLeft1Objects3= [];
gdjs.Level1Code.GDGoLeft1Objects4= [];
gdjs.Level1Code.GDGoLeft1Objects5= [];
gdjs.Level1Code.GDGoLeft1Objects6= [];
gdjs.Level1Code.GDGoLeft2Objects1= [];
gdjs.Level1Code.GDGoLeft2Objects2= [];
gdjs.Level1Code.GDGoLeft2Objects3= [];
gdjs.Level1Code.GDGoLeft2Objects4= [];
gdjs.Level1Code.GDGoLeft2Objects5= [];
gdjs.Level1Code.GDGoLeft2Objects6= [];
gdjs.Level1Code.GDGoLeft3Objects1= [];
gdjs.Level1Code.GDGoLeft3Objects2= [];
gdjs.Level1Code.GDGoLeft3Objects3= [];
gdjs.Level1Code.GDGoLeft3Objects4= [];
gdjs.Level1Code.GDGoLeft3Objects5= [];
gdjs.Level1Code.GDGoLeft3Objects6= [];
gdjs.Level1Code.GDGoLeft4Objects1= [];
gdjs.Level1Code.GDGoLeft4Objects2= [];
gdjs.Level1Code.GDGoLeft4Objects3= [];
gdjs.Level1Code.GDGoLeft4Objects4= [];
gdjs.Level1Code.GDGoLeft4Objects5= [];
gdjs.Level1Code.GDGoLeft4Objects6= [];
gdjs.Level1Code.GDGoLeft5Objects1= [];
gdjs.Level1Code.GDGoLeft5Objects2= [];
gdjs.Level1Code.GDGoLeft5Objects3= [];
gdjs.Level1Code.GDGoLeft5Objects4= [];
gdjs.Level1Code.GDGoLeft5Objects5= [];
gdjs.Level1Code.GDGoLeft5Objects6= [];
gdjs.Level1Code.GDGoLeft6Objects1= [];
gdjs.Level1Code.GDGoLeft6Objects2= [];
gdjs.Level1Code.GDGoLeft6Objects3= [];
gdjs.Level1Code.GDGoLeft6Objects4= [];
gdjs.Level1Code.GDGoLeft6Objects5= [];
gdjs.Level1Code.GDGoLeft6Objects6= [];
gdjs.Level1Code.GDGoLeft7Objects1= [];
gdjs.Level1Code.GDGoLeft7Objects2= [];
gdjs.Level1Code.GDGoLeft7Objects3= [];
gdjs.Level1Code.GDGoLeft7Objects4= [];
gdjs.Level1Code.GDGoLeft7Objects5= [];
gdjs.Level1Code.GDGoLeft7Objects6= [];
gdjs.Level1Code.GDGoLeft8Objects1= [];
gdjs.Level1Code.GDGoLeft8Objects2= [];
gdjs.Level1Code.GDGoLeft8Objects3= [];
gdjs.Level1Code.GDGoLeft8Objects4= [];
gdjs.Level1Code.GDGoLeft8Objects5= [];
gdjs.Level1Code.GDGoLeft8Objects6= [];
gdjs.Level1Code.GDGoLeft9Objects1= [];
gdjs.Level1Code.GDGoLeft9Objects2= [];
gdjs.Level1Code.GDGoLeft9Objects3= [];
gdjs.Level1Code.GDGoLeft9Objects4= [];
gdjs.Level1Code.GDGoLeft9Objects5= [];
gdjs.Level1Code.GDGoLeft9Objects6= [];
gdjs.Level1Code.GDGoLeft10Objects1= [];
gdjs.Level1Code.GDGoLeft10Objects2= [];
gdjs.Level1Code.GDGoLeft10Objects3= [];
gdjs.Level1Code.GDGoLeft10Objects4= [];
gdjs.Level1Code.GDGoLeft10Objects5= [];
gdjs.Level1Code.GDGoLeft10Objects6= [];
gdjs.Level1Code.GDGoLeft11Objects1= [];
gdjs.Level1Code.GDGoLeft11Objects2= [];
gdjs.Level1Code.GDGoLeft11Objects3= [];
gdjs.Level1Code.GDGoLeft11Objects4= [];
gdjs.Level1Code.GDGoLeft11Objects5= [];
gdjs.Level1Code.GDGoLeft11Objects6= [];
gdjs.Level1Code.GDGoLeft12Objects1= [];
gdjs.Level1Code.GDGoLeft12Objects2= [];
gdjs.Level1Code.GDGoLeft12Objects3= [];
gdjs.Level1Code.GDGoLeft12Objects4= [];
gdjs.Level1Code.GDGoLeft12Objects5= [];
gdjs.Level1Code.GDGoLeft12Objects6= [];
gdjs.Level1Code.GDGoRight1Objects1= [];
gdjs.Level1Code.GDGoRight1Objects2= [];
gdjs.Level1Code.GDGoRight1Objects3= [];
gdjs.Level1Code.GDGoRight1Objects4= [];
gdjs.Level1Code.GDGoRight1Objects5= [];
gdjs.Level1Code.GDGoRight1Objects6= [];
gdjs.Level1Code.GDGoRight2Objects1= [];
gdjs.Level1Code.GDGoRight2Objects2= [];
gdjs.Level1Code.GDGoRight2Objects3= [];
gdjs.Level1Code.GDGoRight2Objects4= [];
gdjs.Level1Code.GDGoRight2Objects5= [];
gdjs.Level1Code.GDGoRight2Objects6= [];
gdjs.Level1Code.GDGoRight3Objects1= [];
gdjs.Level1Code.GDGoRight3Objects2= [];
gdjs.Level1Code.GDGoRight3Objects3= [];
gdjs.Level1Code.GDGoRight3Objects4= [];
gdjs.Level1Code.GDGoRight3Objects5= [];
gdjs.Level1Code.GDGoRight3Objects6= [];
gdjs.Level1Code.GDGoRight4Objects1= [];
gdjs.Level1Code.GDGoRight4Objects2= [];
gdjs.Level1Code.GDGoRight4Objects3= [];
gdjs.Level1Code.GDGoRight4Objects4= [];
gdjs.Level1Code.GDGoRight4Objects5= [];
gdjs.Level1Code.GDGoRight4Objects6= [];
gdjs.Level1Code.GDGoRight5Objects1= [];
gdjs.Level1Code.GDGoRight5Objects2= [];
gdjs.Level1Code.GDGoRight5Objects3= [];
gdjs.Level1Code.GDGoRight5Objects4= [];
gdjs.Level1Code.GDGoRight5Objects5= [];
gdjs.Level1Code.GDGoRight5Objects6= [];
gdjs.Level1Code.GDGoRight6Objects1= [];
gdjs.Level1Code.GDGoRight6Objects2= [];
gdjs.Level1Code.GDGoRight6Objects3= [];
gdjs.Level1Code.GDGoRight6Objects4= [];
gdjs.Level1Code.GDGoRight6Objects5= [];
gdjs.Level1Code.GDGoRight6Objects6= [];
gdjs.Level1Code.GDGoRight7Objects1= [];
gdjs.Level1Code.GDGoRight7Objects2= [];
gdjs.Level1Code.GDGoRight7Objects3= [];
gdjs.Level1Code.GDGoRight7Objects4= [];
gdjs.Level1Code.GDGoRight7Objects5= [];
gdjs.Level1Code.GDGoRight7Objects6= [];
gdjs.Level1Code.GDGoRight8Objects1= [];
gdjs.Level1Code.GDGoRight8Objects2= [];
gdjs.Level1Code.GDGoRight8Objects3= [];
gdjs.Level1Code.GDGoRight8Objects4= [];
gdjs.Level1Code.GDGoRight8Objects5= [];
gdjs.Level1Code.GDGoRight8Objects6= [];
gdjs.Level1Code.GDGoRight9Objects1= [];
gdjs.Level1Code.GDGoRight9Objects2= [];
gdjs.Level1Code.GDGoRight9Objects3= [];
gdjs.Level1Code.GDGoRight9Objects4= [];
gdjs.Level1Code.GDGoRight9Objects5= [];
gdjs.Level1Code.GDGoRight9Objects6= [];
gdjs.Level1Code.GDGoRight10Objects1= [];
gdjs.Level1Code.GDGoRight10Objects2= [];
gdjs.Level1Code.GDGoRight10Objects3= [];
gdjs.Level1Code.GDGoRight10Objects4= [];
gdjs.Level1Code.GDGoRight10Objects5= [];
gdjs.Level1Code.GDGoRight10Objects6= [];
gdjs.Level1Code.GDGoRight11Objects1= [];
gdjs.Level1Code.GDGoRight11Objects2= [];
gdjs.Level1Code.GDGoRight11Objects3= [];
gdjs.Level1Code.GDGoRight11Objects4= [];
gdjs.Level1Code.GDGoRight11Objects5= [];
gdjs.Level1Code.GDGoRight11Objects6= [];
gdjs.Level1Code.GDGoRight12Objects1= [];
gdjs.Level1Code.GDGoRight12Objects2= [];
gdjs.Level1Code.GDGoRight12Objects3= [];
gdjs.Level1Code.GDGoRight12Objects4= [];
gdjs.Level1Code.GDGoRight12Objects5= [];
gdjs.Level1Code.GDGoRight12Objects6= [];
gdjs.Level1Code.GDHeadDMG1Objects1= [];
gdjs.Level1Code.GDHeadDMG1Objects2= [];
gdjs.Level1Code.GDHeadDMG1Objects3= [];
gdjs.Level1Code.GDHeadDMG1Objects4= [];
gdjs.Level1Code.GDHeadDMG1Objects5= [];
gdjs.Level1Code.GDHeadDMG1Objects6= [];
gdjs.Level1Code.GDHeadDMG2Objects1= [];
gdjs.Level1Code.GDHeadDMG2Objects2= [];
gdjs.Level1Code.GDHeadDMG2Objects3= [];
gdjs.Level1Code.GDHeadDMG2Objects4= [];
gdjs.Level1Code.GDHeadDMG2Objects5= [];
gdjs.Level1Code.GDHeadDMG2Objects6= [];
gdjs.Level1Code.GDHeadDMG3Objects1= [];
gdjs.Level1Code.GDHeadDMG3Objects2= [];
gdjs.Level1Code.GDHeadDMG3Objects3= [];
gdjs.Level1Code.GDHeadDMG3Objects4= [];
gdjs.Level1Code.GDHeadDMG3Objects5= [];
gdjs.Level1Code.GDHeadDMG3Objects6= [];
gdjs.Level1Code.GDHeadDMG4Objects1= [];
gdjs.Level1Code.GDHeadDMG4Objects2= [];
gdjs.Level1Code.GDHeadDMG4Objects3= [];
gdjs.Level1Code.GDHeadDMG4Objects4= [];
gdjs.Level1Code.GDHeadDMG4Objects5= [];
gdjs.Level1Code.GDHeadDMG4Objects6= [];
gdjs.Level1Code.GDHeadDMG5Objects1= [];
gdjs.Level1Code.GDHeadDMG5Objects2= [];
gdjs.Level1Code.GDHeadDMG5Objects3= [];
gdjs.Level1Code.GDHeadDMG5Objects4= [];
gdjs.Level1Code.GDHeadDMG5Objects5= [];
gdjs.Level1Code.GDHeadDMG5Objects6= [];
gdjs.Level1Code.GDHeadDMG6Objects1= [];
gdjs.Level1Code.GDHeadDMG6Objects2= [];
gdjs.Level1Code.GDHeadDMG6Objects3= [];
gdjs.Level1Code.GDHeadDMG6Objects4= [];
gdjs.Level1Code.GDHeadDMG6Objects5= [];
gdjs.Level1Code.GDHeadDMG6Objects6= [];
gdjs.Level1Code.GDHeadDMG7Objects1= [];
gdjs.Level1Code.GDHeadDMG7Objects2= [];
gdjs.Level1Code.GDHeadDMG7Objects3= [];
gdjs.Level1Code.GDHeadDMG7Objects4= [];
gdjs.Level1Code.GDHeadDMG7Objects5= [];
gdjs.Level1Code.GDHeadDMG7Objects6= [];
gdjs.Level1Code.GDHeadDMG8Objects1= [];
gdjs.Level1Code.GDHeadDMG8Objects2= [];
gdjs.Level1Code.GDHeadDMG8Objects3= [];
gdjs.Level1Code.GDHeadDMG8Objects4= [];
gdjs.Level1Code.GDHeadDMG8Objects5= [];
gdjs.Level1Code.GDHeadDMG8Objects6= [];
gdjs.Level1Code.GDHeadDMG9Objects1= [];
gdjs.Level1Code.GDHeadDMG9Objects2= [];
gdjs.Level1Code.GDHeadDMG9Objects3= [];
gdjs.Level1Code.GDHeadDMG9Objects4= [];
gdjs.Level1Code.GDHeadDMG9Objects5= [];
gdjs.Level1Code.GDHeadDMG9Objects6= [];
gdjs.Level1Code.GDHeadDMG10Objects1= [];
gdjs.Level1Code.GDHeadDMG10Objects2= [];
gdjs.Level1Code.GDHeadDMG10Objects3= [];
gdjs.Level1Code.GDHeadDMG10Objects4= [];
gdjs.Level1Code.GDHeadDMG10Objects5= [];
gdjs.Level1Code.GDHeadDMG10Objects6= [];
gdjs.Level1Code.GDHeadDMG11Objects1= [];
gdjs.Level1Code.GDHeadDMG11Objects2= [];
gdjs.Level1Code.GDHeadDMG11Objects3= [];
gdjs.Level1Code.GDHeadDMG11Objects4= [];
gdjs.Level1Code.GDHeadDMG11Objects5= [];
gdjs.Level1Code.GDHeadDMG11Objects6= [];
gdjs.Level1Code.GDHeadDMG12Objects1= [];
gdjs.Level1Code.GDHeadDMG12Objects2= [];
gdjs.Level1Code.GDHeadDMG12Objects3= [];
gdjs.Level1Code.GDHeadDMG12Objects4= [];
gdjs.Level1Code.GDHeadDMG12Objects5= [];
gdjs.Level1Code.GDHeadDMG12Objects6= [];
gdjs.Level1Code.GDUndergroundBGObjects1= [];
gdjs.Level1Code.GDUndergroundBGObjects2= [];
gdjs.Level1Code.GDUndergroundBGObjects3= [];
gdjs.Level1Code.GDUndergroundBGObjects4= [];
gdjs.Level1Code.GDUndergroundBGObjects5= [];
gdjs.Level1Code.GDUndergroundBGObjects6= [];
gdjs.Level1Code.GDBlackFadeObjects1= [];
gdjs.Level1Code.GDBlackFadeObjects2= [];
gdjs.Level1Code.GDBlackFadeObjects3= [];
gdjs.Level1Code.GDBlackFadeObjects4= [];
gdjs.Level1Code.GDBlackFadeObjects5= [];
gdjs.Level1Code.GDBlackFadeObjects6= [];
gdjs.Level1Code.GDTeleport1Objects1= [];
gdjs.Level1Code.GDTeleport1Objects2= [];
gdjs.Level1Code.GDTeleport1Objects3= [];
gdjs.Level1Code.GDTeleport1Objects4= [];
gdjs.Level1Code.GDTeleport1Objects5= [];
gdjs.Level1Code.GDTeleport1Objects6= [];
gdjs.Level1Code.GDTeleport2Objects1= [];
gdjs.Level1Code.GDTeleport2Objects2= [];
gdjs.Level1Code.GDTeleport2Objects3= [];
gdjs.Level1Code.GDTeleport2Objects4= [];
gdjs.Level1Code.GDTeleport2Objects5= [];
gdjs.Level1Code.GDTeleport2Objects6= [];
gdjs.Level1Code.GDCoinObjects1= [];
gdjs.Level1Code.GDCoinObjects2= [];
gdjs.Level1Code.GDCoinObjects3= [];
gdjs.Level1Code.GDCoinObjects4= [];
gdjs.Level1Code.GDCoinObjects5= [];
gdjs.Level1Code.GDCoinObjects6= [];
gdjs.Level1Code.GDCoinUIObjects1= [];
gdjs.Level1Code.GDCoinUIObjects2= [];
gdjs.Level1Code.GDCoinUIObjects3= [];
gdjs.Level1Code.GDCoinUIObjects4= [];
gdjs.Level1Code.GDCoinUIObjects5= [];
gdjs.Level1Code.GDCoinUIObjects6= [];
gdjs.Level1Code.GDHiderObjects1= [];
gdjs.Level1Code.GDHiderObjects2= [];
gdjs.Level1Code.GDHiderObjects3= [];
gdjs.Level1Code.GDHiderObjects4= [];
gdjs.Level1Code.GDHiderObjects5= [];
gdjs.Level1Code.GDHiderObjects6= [];
gdjs.Level1Code.GDHider2Objects1= [];
gdjs.Level1Code.GDHider2Objects2= [];
gdjs.Level1Code.GDHider2Objects3= [];
gdjs.Level1Code.GDHider2Objects4= [];
gdjs.Level1Code.GDHider2Objects5= [];
gdjs.Level1Code.GDHider2Objects6= [];
gdjs.Level1Code.GDHider3Objects1= [];
gdjs.Level1Code.GDHider3Objects2= [];
gdjs.Level1Code.GDHider3Objects3= [];
gdjs.Level1Code.GDHider3Objects4= [];
gdjs.Level1Code.GDHider3Objects5= [];
gdjs.Level1Code.GDHider3Objects6= [];
gdjs.Level1Code.GDHider4Objects1= [];
gdjs.Level1Code.GDHider4Objects2= [];
gdjs.Level1Code.GDHider4Objects3= [];
gdjs.Level1Code.GDHider4Objects4= [];
gdjs.Level1Code.GDHider4Objects5= [];
gdjs.Level1Code.GDHider4Objects6= [];
gdjs.Level1Code.GDHider5Objects1= [];
gdjs.Level1Code.GDHider5Objects2= [];
gdjs.Level1Code.GDHider5Objects3= [];
gdjs.Level1Code.GDHider5Objects4= [];
gdjs.Level1Code.GDHider5Objects5= [];
gdjs.Level1Code.GDHider5Objects6= [];
gdjs.Level1Code.GDHider6Objects1= [];
gdjs.Level1Code.GDHider6Objects2= [];
gdjs.Level1Code.GDHider6Objects3= [];
gdjs.Level1Code.GDHider6Objects4= [];
gdjs.Level1Code.GDHider6Objects5= [];
gdjs.Level1Code.GDHider6Objects6= [];
gdjs.Level1Code.GDHiderCoinObjects1= [];
gdjs.Level1Code.GDHiderCoinObjects2= [];
gdjs.Level1Code.GDHiderCoinObjects3= [];
gdjs.Level1Code.GDHiderCoinObjects4= [];
gdjs.Level1Code.GDHiderCoinObjects5= [];
gdjs.Level1Code.GDHiderCoinObjects6= [];
gdjs.Level1Code.GDFlagTrajectoryObjects1= [];
gdjs.Level1Code.GDFlagTrajectoryObjects2= [];
gdjs.Level1Code.GDFlagTrajectoryObjects3= [];
gdjs.Level1Code.GDFlagTrajectoryObjects4= [];
gdjs.Level1Code.GDFlagTrajectoryObjects5= [];
gdjs.Level1Code.GDFlagTrajectoryObjects6= [];
gdjs.Level1Code.GDFlagPoleObjects1= [];
gdjs.Level1Code.GDFlagPoleObjects2= [];
gdjs.Level1Code.GDFlagPoleObjects3= [];
gdjs.Level1Code.GDFlagPoleObjects4= [];
gdjs.Level1Code.GDFlagPoleObjects5= [];
gdjs.Level1Code.GDFlagPoleObjects6= [];
gdjs.Level1Code.GDFlagBallObjects1= [];
gdjs.Level1Code.GDFlagBallObjects2= [];
gdjs.Level1Code.GDFlagBallObjects3= [];
gdjs.Level1Code.GDFlagBallObjects4= [];
gdjs.Level1Code.GDFlagBallObjects5= [];
gdjs.Level1Code.GDFlagBallObjects6= [];
gdjs.Level1Code.GDFlagObjects1= [];
gdjs.Level1Code.GDFlagObjects2= [];
gdjs.Level1Code.GDFlagObjects3= [];
gdjs.Level1Code.GDFlagObjects4= [];
gdjs.Level1Code.GDFlagObjects5= [];
gdjs.Level1Code.GDFlagObjects6= [];
gdjs.Level1Code.GDDoorObjects1= [];
gdjs.Level1Code.GDDoorObjects2= [];
gdjs.Level1Code.GDDoorObjects3= [];
gdjs.Level1Code.GDDoorObjects4= [];
gdjs.Level1Code.GDDoorObjects5= [];
gdjs.Level1Code.GDDoorObjects6= [];
gdjs.Level1Code.GDWallObjects1= [];
gdjs.Level1Code.GDWallObjects2= [];
gdjs.Level1Code.GDWallObjects3= [];
gdjs.Level1Code.GDWallObjects4= [];
gdjs.Level1Code.GDWallObjects5= [];
gdjs.Level1Code.GDWallObjects6= [];
gdjs.Level1Code.GDWindowObjects1= [];
gdjs.Level1Code.GDWindowObjects2= [];
gdjs.Level1Code.GDWindowObjects3= [];
gdjs.Level1Code.GDWindowObjects4= [];
gdjs.Level1Code.GDWindowObjects5= [];
gdjs.Level1Code.GDWindowObjects6= [];
gdjs.Level1Code.GDPoints100Objects1= [];
gdjs.Level1Code.GDPoints100Objects2= [];
gdjs.Level1Code.GDPoints100Objects3= [];
gdjs.Level1Code.GDPoints100Objects4= [];
gdjs.Level1Code.GDPoints100Objects5= [];
gdjs.Level1Code.GDPoints100Objects6= [];
gdjs.Level1Code.GDPoints400Objects1= [];
gdjs.Level1Code.GDPoints400Objects2= [];
gdjs.Level1Code.GDPoints400Objects3= [];
gdjs.Level1Code.GDPoints400Objects4= [];
gdjs.Level1Code.GDPoints400Objects5= [];
gdjs.Level1Code.GDPoints400Objects6= [];
gdjs.Level1Code.GDPoints800Objects1= [];
gdjs.Level1Code.GDPoints800Objects2= [];
gdjs.Level1Code.GDPoints800Objects3= [];
gdjs.Level1Code.GDPoints800Objects4= [];
gdjs.Level1Code.GDPoints800Objects5= [];
gdjs.Level1Code.GDPoints800Objects6= [];
gdjs.Level1Code.GDPoints2000Objects1= [];
gdjs.Level1Code.GDPoints2000Objects2= [];
gdjs.Level1Code.GDPoints2000Objects3= [];
gdjs.Level1Code.GDPoints2000Objects4= [];
gdjs.Level1Code.GDPoints2000Objects5= [];
gdjs.Level1Code.GDPoints2000Objects6= [];
gdjs.Level1Code.GDPoints4000Objects1= [];
gdjs.Level1Code.GDPoints4000Objects2= [];
gdjs.Level1Code.GDPoints4000Objects3= [];
gdjs.Level1Code.GDPoints4000Objects4= [];
gdjs.Level1Code.GDPoints4000Objects5= [];
gdjs.Level1Code.GDPoints4000Objects6= [];
gdjs.Level1Code.GDPoints5000Objects1= [];
gdjs.Level1Code.GDPoints5000Objects2= [];
gdjs.Level1Code.GDPoints5000Objects3= [];
gdjs.Level1Code.GDPoints5000Objects4= [];
gdjs.Level1Code.GDPoints5000Objects5= [];
gdjs.Level1Code.GDPoints5000Objects6= [];
gdjs.Level1Code.GDfallBorderObjects1= [];
gdjs.Level1Code.GDfallBorderObjects2= [];
gdjs.Level1Code.GDfallBorderObjects3= [];
gdjs.Level1Code.GDfallBorderObjects4= [];
gdjs.Level1Code.GDfallBorderObjects5= [];
gdjs.Level1Code.GDfallBorderObjects6= [];
gdjs.Level1Code.GDBucketObjects1= [];
gdjs.Level1Code.GDBucketObjects2= [];
gdjs.Level1Code.GDBucketObjects3= [];
gdjs.Level1Code.GDBucketObjects4= [];
gdjs.Level1Code.GDBucketObjects5= [];
gdjs.Level1Code.GDBucketObjects6= [];
gdjs.Level1Code.GDBucket2Objects1= [];
gdjs.Level1Code.GDBucket2Objects2= [];
gdjs.Level1Code.GDBucket2Objects3= [];
gdjs.Level1Code.GDBucket2Objects4= [];
gdjs.Level1Code.GDBucket2Objects5= [];
gdjs.Level1Code.GDBucket2Objects6= [];
gdjs.Level1Code.GDBucket3Objects1= [];
gdjs.Level1Code.GDBucket3Objects2= [];
gdjs.Level1Code.GDBucket3Objects3= [];
gdjs.Level1Code.GDBucket3Objects4= [];
gdjs.Level1Code.GDBucket3Objects5= [];
gdjs.Level1Code.GDBucket3Objects6= [];
gdjs.Level1Code.GDBucket4Objects1= [];
gdjs.Level1Code.GDBucket4Objects2= [];
gdjs.Level1Code.GDBucket4Objects3= [];
gdjs.Level1Code.GDBucket4Objects4= [];
gdjs.Level1Code.GDBucket4Objects5= [];
gdjs.Level1Code.GDBucket4Objects6= [];
gdjs.Level1Code.GDMarioObjects1= [];
gdjs.Level1Code.GDMarioObjects2= [];
gdjs.Level1Code.GDMarioObjects3= [];
gdjs.Level1Code.GDMarioObjects4= [];
gdjs.Level1Code.GDMarioObjects5= [];
gdjs.Level1Code.GDMarioObjects6= [];
gdjs.Level1Code.GDMarijuanaObjects1= [];
gdjs.Level1Code.GDMarijuanaObjects2= [];
gdjs.Level1Code.GDMarijuanaObjects3= [];
gdjs.Level1Code.GDMarijuanaObjects4= [];
gdjs.Level1Code.GDMarijuanaObjects5= [];
gdjs.Level1Code.GDMarijuanaObjects6= [];
gdjs.Level1Code.GDStonerObjects1= [];
gdjs.Level1Code.GDStonerObjects2= [];
gdjs.Level1Code.GDStonerObjects3= [];
gdjs.Level1Code.GDStonerObjects4= [];
gdjs.Level1Code.GDStonerObjects5= [];
gdjs.Level1Code.GDStonerObjects6= [];
gdjs.Level1Code.GDGameOverBGObjects1= [];
gdjs.Level1Code.GDGameOverBGObjects2= [];
gdjs.Level1Code.GDGameOverBGObjects3= [];
gdjs.Level1Code.GDGameOverBGObjects4= [];
gdjs.Level1Code.GDGameOverBGObjects5= [];
gdjs.Level1Code.GDGameOverBGObjects6= [];


gdjs.Level1Code.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Border"), gdjs.Level1Code.GDBorderObjects1);
gdjs.copyArray(runtimeScene.getObjects("Bucket"), gdjs.Level1Code.GDBucketObjects1);
gdjs.copyArray(runtimeScene.getObjects("Bucket2"), gdjs.Level1Code.GDBucket2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Bucket3"), gdjs.Level1Code.GDBucket3Objects1);
gdjs.copyArray(runtimeScene.getObjects("Bucket4"), gdjs.Level1Code.GDBucket4Objects1);
gdjs.copyArray(runtimeScene.getObjects("FlagTrajectory"), gdjs.Level1Code.GDFlagTrajectoryObjects1);
gdjs.copyArray(runtimeScene.getObjects("GameOver"), gdjs.Level1Code.GDGameOverObjects1);
gdjs.copyArray(runtimeScene.getObjects("GameOverBG"), gdjs.Level1Code.GDGameOverBGObjects1);
gdjs.copyArray(runtimeScene.getObjects("Hider"), gdjs.Level1Code.GDHiderObjects1);
gdjs.copyArray(runtimeScene.getObjects("Hider2"), gdjs.Level1Code.GDHider2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Hider3"), gdjs.Level1Code.GDHider3Objects1);
gdjs.copyArray(runtimeScene.getObjects("Hider4"), gdjs.Level1Code.GDHider4Objects1);
gdjs.copyArray(runtimeScene.getObjects("Hider5"), gdjs.Level1Code.GDHider5Objects1);
gdjs.copyArray(runtimeScene.getObjects("Hider6"), gdjs.Level1Code.GDHider6Objects1);
gdjs.copyArray(runtimeScene.getObjects("HiderCoin"), gdjs.Level1Code.GDHiderCoinObjects1);
gdjs.copyArray(runtimeScene.getObjects("InvisibleLuckyBlock"), gdjs.Level1Code.GDInvisibleLuckyBlockObjects1);
gdjs.copyArray(runtimeScene.getObjects("Marijuana"), gdjs.Level1Code.GDMarijuanaObjects1);
gdjs.copyArray(runtimeScene.getObjects("Points100"), gdjs.Level1Code.GDPoints100Objects1);
gdjs.copyArray(runtimeScene.getObjects("Points2000"), gdjs.Level1Code.GDPoints2000Objects1);
gdjs.copyArray(runtimeScene.getObjects("Points400"), gdjs.Level1Code.GDPoints400Objects1);
gdjs.copyArray(runtimeScene.getObjects("Points4000"), gdjs.Level1Code.GDPoints4000Objects1);
gdjs.copyArray(runtimeScene.getObjects("Points5000"), gdjs.Level1Code.GDPoints5000Objects1);
gdjs.copyArray(runtimeScene.getObjects("Points800"), gdjs.Level1Code.GDPoints800Objects1);
gdjs.copyArray(runtimeScene.getObjects("Stoner"), gdjs.Level1Code.GDStonerObjects1);
gdjs.copyArray(runtimeScene.getObjects("Teleport1"), gdjs.Level1Code.GDTeleport1Objects1);
gdjs.copyArray(runtimeScene.getObjects("Teleport2"), gdjs.Level1Code.GDTeleport2Objects1);
gdjs.copyArray(runtimeScene.getObjects("fallBorder"), gdjs.Level1Code.GDfallBorderObjects1);
{gdjs.evtTools.window.setFullScreen(runtimeScene, true, true);
}{gdjs.playerAuthentication.displayAuthenticationBanner(runtimeScene);
}{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "marioThemeSong.mp3", 1, false, 50, 1);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "TimeLeft");
}{for(var i = 0, len = gdjs.Level1Code.GDBorderObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDBorderObjects1[i].setOpacity(0);
}
}{for(var i = 0, len = gdjs.Level1Code.GDInvisibleLuckyBlockObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDInvisibleLuckyBlockObjects1[i].setOpacity(0);
}
}{for(var i = 0, len = gdjs.Level1Code.GDTeleport1Objects1.length ;i < len;++i) {
    gdjs.Level1Code.GDTeleport1Objects1[i].setOpacity(0);
}
}{for(var i = 0, len = gdjs.Level1Code.GDTeleport2Objects1.length ;i < len;++i) {
    gdjs.Level1Code.GDTeleport2Objects1[i].setOpacity(0);
}
}{for(var i = 0, len = gdjs.Level1Code.GDHiderObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDHiderObjects1[i].setOpacity(0);
}
}{for(var i = 0, len = gdjs.Level1Code.GDFlagTrajectoryObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDFlagTrajectoryObjects1[i].setOpacity(0);
}
}{for(var i = 0, len = gdjs.Level1Code.GDPoints100Objects1.length ;i < len;++i) {
    gdjs.Level1Code.GDPoints100Objects1[i].setOpacity(0);
}
}{for(var i = 0, len = gdjs.Level1Code.GDPoints400Objects1.length ;i < len;++i) {
    gdjs.Level1Code.GDPoints400Objects1[i].setOpacity(0);
}
}{for(var i = 0, len = gdjs.Level1Code.GDPoints800Objects1.length ;i < len;++i) {
    gdjs.Level1Code.GDPoints800Objects1[i].setOpacity(0);
}
}{for(var i = 0, len = gdjs.Level1Code.GDPoints2000Objects1.length ;i < len;++i) {
    gdjs.Level1Code.GDPoints2000Objects1[i].setOpacity(0);
}
}{for(var i = 0, len = gdjs.Level1Code.GDPoints4000Objects1.length ;i < len;++i) {
    gdjs.Level1Code.GDPoints4000Objects1[i].setOpacity(0);
}
}{for(var i = 0, len = gdjs.Level1Code.GDPoints5000Objects1.length ;i < len;++i) {
    gdjs.Level1Code.GDPoints5000Objects1[i].setOpacity(0);
}
}{for(var i = 0, len = gdjs.Level1Code.GDfallBorderObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDfallBorderObjects1[i].setOpacity(0);
}
}{for(var i = 0, len = gdjs.Level1Code.GDBucketObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDBucketObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Level1Code.GDBucket2Objects1.length ;i < len;++i) {
    gdjs.Level1Code.GDBucket2Objects1[i].hide();
}
}{for(var i = 0, len = gdjs.Level1Code.GDBucket3Objects1.length ;i < len;++i) {
    gdjs.Level1Code.GDBucket3Objects1[i].hide();
}
}{for(var i = 0, len = gdjs.Level1Code.GDBucket4Objects1.length ;i < len;++i) {
    gdjs.Level1Code.GDBucket4Objects1[i].hide();
}
}{for(var i = 0, len = gdjs.Level1Code.GDHider2Objects1.length ;i < len;++i) {
    gdjs.Level1Code.GDHider2Objects1[i].hide();
}
}{for(var i = 0, len = gdjs.Level1Code.GDHider3Objects1.length ;i < len;++i) {
    gdjs.Level1Code.GDHider3Objects1[i].hide();
}
}{for(var i = 0, len = gdjs.Level1Code.GDHider4Objects1.length ;i < len;++i) {
    gdjs.Level1Code.GDHider4Objects1[i].hide();
}
}{for(var i = 0, len = gdjs.Level1Code.GDHider5Objects1.length ;i < len;++i) {
    gdjs.Level1Code.GDHider5Objects1[i].hide();
}
}{for(var i = 0, len = gdjs.Level1Code.GDHider6Objects1.length ;i < len;++i) {
    gdjs.Level1Code.GDHider6Objects1[i].hide();
}
}{for(var i = 0, len = gdjs.Level1Code.GDHiderCoinObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDHiderCoinObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Level1Code.GDStonerObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDStonerObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Level1Code.GDMarijuanaObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDMarijuanaObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Level1Code.GDStonerObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDStonerObjects1[i].setOpacity(50);
}
}{for(var i = 0, len = gdjs.Level1Code.GDGameOverBGObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDGameOverBGObjects1[i].setOpacity(0);
}
}{for(var i = 0, len = gdjs.Level1Code.GDGameOverObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDGameOverObjects1[i].setOpacity(0);
}
}}

}


};gdjs.Level1Code.eventsList1 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Escape");
if (isConditionTrue_0) {
{gdjs.evtTools.window.setFullScreen(runtimeScene, false, true);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "TimeLeft") >= 1;
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(1).sub(1);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "TimeLeft");
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("BackgroundImg"), gdjs.Level1Code.GDBackgroundImgObjects2);
gdjs.copyArray(runtimeScene.getObjects("CoinAmmout"), gdjs.Level1Code.GDCoinAmmoutObjects2);
gdjs.copyArray(runtimeScene.getObjects("LivesAmmout"), gdjs.Level1Code.GDLivesAmmoutObjects2);
gdjs.copyArray(runtimeScene.getObjects("Points"), gdjs.Level1Code.GDPointsObjects2);
gdjs.copyArray(runtimeScene.getObjects("TimeLeft"), gdjs.Level1Code.GDTimeLeftObjects2);
{for(var i = 0, len = gdjs.Level1Code.GDPointsObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDPointsObjects2[i].setBBText(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0))));
}
}{for(var i = 0, len = gdjs.Level1Code.GDTimeLeftObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDTimeLeftObjects2[i].setBBText(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1))));
}
}{for(var i = 0, len = gdjs.Level1Code.GDBackgroundImgObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDBackgroundImgObjects2[i].setXOffset(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0));
}
}{for(var i = 0, len = gdjs.Level1Code.GDCoinAmmoutObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDCoinAmmoutObjects2[i].setBBText("x " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2))));
}
}{for(var i = 0, len = gdjs.Level1Code.GDLivesAmmoutObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDLivesAmmoutObjects2[i].setBBText("x " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(4))));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("BlackFade"), gdjs.Level1Code.GDBlackFadeObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDBlackFadeObjects2.length;i<l;++i) {
    if ( gdjs.Level1Code.GDBlackFadeObjects2[i].getOpacity() > 0 ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDBlackFadeObjects2[k] = gdjs.Level1Code.GDBlackFadeObjects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDBlackFadeObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDBlackFadeObjects2 */
{for(var i = 0, len = gdjs.Level1Code.GDBlackFadeObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDBlackFadeObjects2[i].setOpacity(gdjs.Level1Code.GDBlackFadeObjects2[i].getOpacity() - (3));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(4)) == -(1);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "MainMenu", false);
}}

}


};gdjs.Level1Code.asyncCallback17014556 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "MainMenu", false);
}}
gdjs.Level1Code.eventsList2 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(6), (runtimeScene) => (gdjs.Level1Code.asyncCallback17014556(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level1Code.asyncCallback17014772 = function (runtimeScene, asyncObjectsList) {
{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(0);
}{gdjs.evtTools.sound.playSound(runtimeScene, "SUPER MARIO - game over - sound effect.mp3", false, 50, 1);
}
{ //Subevents
gdjs.Level1Code.eventsList2(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Level1Code.eventsList3 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(4), (runtimeScene) => (gdjs.Level1Code.asyncCallback17014772(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level1Code.eventsList4 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17014164);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects2);
{gdjs.evtTools.sound.stopSoundOnChannel(runtimeScene, 1);
}{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects2[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.Level1Code.eventsList3(runtimeScene);} //End of subevents
}

}


};gdjs.Level1Code.asyncCallback17019276 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "MainMenu", false);
}}
gdjs.Level1Code.eventsList5 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(6), (runtimeScene) => (gdjs.Level1Code.asyncCallback17019276(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level1Code.asyncCallback17018332 = function (runtimeScene, asyncObjectsList) {
{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(0);
}{gdjs.evtTools.sound.playSound(runtimeScene, "SUPER MARIO - game over - sound effect.mp3", false, 50, 1);
}
{ //Subevents
gdjs.Level1Code.eventsList5(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Level1Code.eventsList6 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(4), (runtimeScene) => (gdjs.Level1Code.asyncCallback17018332(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level1Code.eventsList7 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(8), false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("GameOver"), gdjs.Level1Code.GDGameOverObjects3);
gdjs.copyArray(runtimeScene.getObjects("GameOverBG"), gdjs.Level1Code.GDGameOverBGObjects3);
{for(var i = 0, len = gdjs.Level1Code.GDGameOverObjects3.length ;i < len;++i) {
    gdjs.Level1Code.GDGameOverObjects3[i].setOpacity(gdjs.Level1Code.GDGameOverObjects3[i].getOpacity() + (4));
}
}{for(var i = 0, len = gdjs.Level1Code.GDGameOverBGObjects3.length ;i < len;++i) {
    gdjs.Level1Code.GDGameOverBGObjects3[i].setOpacity(gdjs.Level1Code.GDGameOverBGObjects3[i].getOpacity() + (4));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(8), false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17017924);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects2);
{gdjs.evtTools.sound.stopSoundOnChannel(runtimeScene, 1);
}{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects2[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.Level1Code.eventsList6(runtimeScene);} //End of subevents
}

}


};gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDfallBorderObjects2Objects = Hashtable.newFrom({"fallBorder": gdjs.Level1Code.GDfallBorderObjects2});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level1Code.GDPlayerObjects2});
gdjs.Level1Code.eventsList8 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(6), true);
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.Level1Code.GDPlayerObjects2, gdjs.Level1Code.GDPlayerObjects3);

{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects3[i].getBehavior("PlatformerObject").setCanJump();
}
}{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects3[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(6), false);
if (isConditionTrue_0) {
{gdjs.evtTools.variable.toggleVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(5));
}}

}


};gdjs.Level1Code.eventsList9 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17025876);
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Mario jump sound effect (download).mp3", false, 30, 1);
}}

}


};gdjs.Level1Code.eventsList10 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(4)) > 0;
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "marioThemeSong.mp3", 1, false, 50, 1);
}}

}


};gdjs.Level1Code.asyncCallback17032932 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects3);

{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects3[i].setPosition(0,960);
}
}{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects3[i].hide(false);
}
}{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects3[i].getBehavior("PlatformerObject").ignoreDefaultControls(false);
}
}
{ //Subevents
gdjs.Level1Code.eventsList10(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Level1Code.eventsList11 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.Level1Code.GDPlayerObjects2) asyncObjectsList.addObject("Player", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(2), (runtimeScene) => (gdjs.Level1Code.asyncCallback17032932(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level1Code.asyncCallback17031732 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects2);

{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects2[i].hide();
}
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(5), false);
}{gdjs.evtTools.sound.playSound(runtimeScene, "Mario Death - Sound Effect (HD).mp3", false, 50, 1);
}
{ //Subevents
gdjs.Level1Code.eventsList11(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Level1Code.eventsList12 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Level1Code.GDPlayerObjects1) asyncObjectsList.addObject("Player", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.Level1Code.asyncCallback17031732(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level1Code.eventsList13 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(4)) == 0;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("GameOver"), gdjs.Level1Code.GDGameOverObjects2);
gdjs.copyArray(runtimeScene.getObjects("GameOverBG"), gdjs.Level1Code.GDGameOverBGObjects2);
{for(var i = 0, len = gdjs.Level1Code.GDGameOverBGObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDGameOverBGObjects2[i].setOpacity(gdjs.Level1Code.GDGameOverBGObjects2[i].getOpacity() + (4));
}
}{for(var i = 0, len = gdjs.Level1Code.GDGameOverObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDGameOverObjects2[i].setOpacity(gdjs.Level1Code.GDGameOverObjects2[i].getOpacity() + (4));
}
}
{ //Subevents
gdjs.Level1Code.eventsList4(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1)) == 0;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.pauseTimer(runtimeScene, "TimeLeft");
}
{ //Subevents
gdjs.Level1Code.eventsList7(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level1Code.GDPlayerObjects2[i].getScaleY() == 0.8 ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDPlayerObjects2[k] = gdjs.Level1Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDPlayerObjects2.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(7), true);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("fallBorder"), gdjs.Level1Code.GDfallBorderObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDfallBorderObjects2Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17020500);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Level1Code.eventsList8(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDPlayerObjects2.length;i<l;++i) {
    if ( !(gdjs.Level1Code.GDPlayerObjects2[i].getBehavior("PlatformerObject").isJumping()) ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDPlayerObjects2[k] = gdjs.Level1Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDPlayerObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level1Code.GDPlayerObjects2[i].getBehavior("PlatformerObject").isMovingEvenALittle() ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDPlayerObjects2[k] = gdjs.Level1Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDPlayerObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects2[i].setAnimationName("run");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level1Code.GDPlayerObjects2[i].getBehavior("PlatformerObject").isJumping() ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDPlayerObjects2[k] = gdjs.Level1Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDPlayerObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects2[i].setAnimationName("jump");
}
}
{ //Subevents
gdjs.Level1Code.eventsList9(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDPlayerObjects2.length;i<l;++i) {
    if ( !(gdjs.Level1Code.GDPlayerObjects2[i].getBehavior("PlatformerObject").isMovingEvenALittle()) ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDPlayerObjects2[k] = gdjs.Level1Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDPlayerObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects2[i].setAnimationName("idle");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects2);
{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects2[i].flipX(true);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects2);
{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects2[i].flipX(false);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(5), true);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(6), false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17029532);
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects1);
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(7), false);
}{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects1[i].setScale(0.6);
}
}{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects1[i].getBehavior("PlatformerObject").ignoreDefaultControls(true);
}
}{runtimeScene.getScene().getVariables().getFromIndex(4).sub(1);
}{gdjs.evtTools.sound.stopSoundOnChannel(runtimeScene, 1);
}{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects1[i].getBehavior("SmoothCamera").WaitAndCatchUp(4, -(10), 1, 0, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.Level1Code.eventsList12(runtimeScene);} //End of subevents
}

}


};gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDTeleport1Objects2Objects = Hashtable.newFrom({"Teleport1": gdjs.Level1Code.GDTeleport1Objects2});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level1Code.GDPlayerObjects2});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDTeleport2Objects1Objects = Hashtable.newFrom({"Teleport2": gdjs.Level1Code.GDTeleport2Objects1});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Level1Code.GDPlayerObjects1});
gdjs.Level1Code.eventsList14 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Teleport1"), gdjs.Level1Code.GDTeleport1Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDTeleport1Objects2Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Down");
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects2[i].setPosition(5834,1898);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("Teleport2"), gdjs.Level1Code.GDTeleport2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDTeleport2Objects1Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects1[i].setPosition(6250,910);
}
}}

}


};gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDCoinObjects2Objects = Hashtable.newFrom({"Coin": gdjs.Level1Code.GDCoinObjects2});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level1Code.GDPlayerObjects2});
gdjs.Level1Code.eventsList15 = function(runtimeScene) {

};gdjs.Level1Code.eventsList16 = function(runtimeScene) {

{

/* Reuse gdjs.Level1Code.GDCoinObjects2 */

for (gdjs.Level1Code.forEachIndex3 = 0;gdjs.Level1Code.forEachIndex3 < gdjs.Level1Code.GDCoinObjects2.length;++gdjs.Level1Code.forEachIndex3) {
gdjs.Level1Code.GDCoinObjects3.length = 0;


gdjs.Level1Code.forEachTemporary3 = gdjs.Level1Code.GDCoinObjects2[gdjs.Level1Code.forEachIndex3];
gdjs.Level1Code.GDCoinObjects3.push(gdjs.Level1Code.forEachTemporary3);
let isConditionTrue_0 = false;
if (true) {
{for(var i = 0, len = gdjs.Level1Code.GDCoinObjects3.length ;i < len;++i) {
    gdjs.Level1Code.GDCoinObjects3[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getScene().getVariables().getFromIndex(2).add(1);
}{runtimeScene.getScene().getVariables().getFromIndex(0).add(200);
}{gdjs.evtTools.sound.playSound(runtimeScene, "Mario Coin Sound - Sound Effect (HD).mp3", false, 50, 1);
}}
}

}


};gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDHiderCoinObjects2Objects = Hashtable.newFrom({"HiderCoin": gdjs.Level1Code.GDHiderCoinObjects2});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDCoinObjects2Objects = Hashtable.newFrom({"Coin": gdjs.Level1Code.GDCoinObjects2});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDHider5Objects1Objects = Hashtable.newFrom({"Hider5": gdjs.Level1Code.GDHider5Objects1});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Level1Code.GDPlayerObjects1});
gdjs.Level1Code.eventsList17 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Coin"), gdjs.Level1Code.GDCoinObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDCoinObjects2Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDCoinObjects2.length;i<l;++i) {
    if ( gdjs.Level1Code.GDCoinObjects2[i].getOpacity() != 0 ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDCoinObjects2[k] = gdjs.Level1Code.GDCoinObjects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDCoinObjects2.length = k;
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Level1Code.eventsList16(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Coin"), gdjs.Level1Code.GDCoinObjects2);
gdjs.copyArray(runtimeScene.getObjects("HiderCoin"), gdjs.Level1Code.GDHiderCoinObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDHiderCoinObjects2Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDCoinObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17038692);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDCoinObjects2 */
{for(var i = 0, len = gdjs.Level1Code.GDCoinObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDCoinObjects2[i].setOpacity(0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Hider5"), gdjs.Level1Code.GDHider5Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDHider5Objects1Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Coin"), gdjs.Level1Code.GDCoinObjects1);
{for(var i = 0, len = gdjs.Level1Code.GDCoinObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDCoinObjects1[i].setOpacity(255);
}
}}

}


};gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDFlagPoleObjects2Objects = Hashtable.newFrom({"FlagPole": gdjs.Level1Code.GDFlagPoleObjects2});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level1Code.GDPlayerObjects2});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDFlagObjects2Objects = Hashtable.newFrom({"Flag": gdjs.Level1Code.GDFlagObjects2});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level1Code.GDPlayerObjects2});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDFlagObjects2Objects = Hashtable.newFrom({"Flag": gdjs.Level1Code.GDFlagObjects2});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDStoneObjects2Objects = Hashtable.newFrom({"Stone": gdjs.Level1Code.GDStoneObjects2});
gdjs.Level1Code.eventsList18 = function(runtimeScene) {

{

/* Reuse gdjs.Level1Code.GDFlagObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Stone"), gdjs.Level1Code.GDStoneObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDFlagObjects2Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDStoneObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDFlagObjects2 */
{for(var i = 0, len = gdjs.Level1Code.GDFlagObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDFlagObjects2[i].clearForces();
}
}}

}


};gdjs.Level1Code.eventsList19 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17043260);
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Stage Win (Super Mario) - Sound Effect HD.mp3", false, 50, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Flag"), gdjs.Level1Code.GDFlagObjects2);
/* Reuse gdjs.Level1Code.GDPlayerObjects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDFlagObjects2Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDFlagObjects2 */
gdjs.copyArray(runtimeScene.getObjects("FlagTrajectory"), gdjs.Level1Code.GDFlagTrajectoryObjects2);
/* Reuse gdjs.Level1Code.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.Level1Code.GDFlagObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDFlagObjects2[i].addForceTowardObject((gdjs.Level1Code.GDFlagTrajectoryObjects2.length !== 0 ? gdjs.Level1Code.GDFlagTrajectoryObjects2[0] : null), 90, 0);
}
}{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects2[i].getBehavior("PlatformerObject").setCurrentFallSpeed(80);
}
}
{ //Subevents
gdjs.Level1Code.eventsList18(runtimeScene);} //End of subevents
}

}


};gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDFlagPoleObjects2Objects = Hashtable.newFrom({"FlagPole": gdjs.Level1Code.GDFlagPoleObjects2});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level1Code.GDPlayerObjects2});
gdjs.Level1Code.eventsList20 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1)) > 0;
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(1).sub(1);
}{runtimeScene.getScene().getVariables().getFromIndex(0).add(50);
}}

}


};gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDFlagPoleObjects2Objects = Hashtable.newFrom({"FlagPole": gdjs.Level1Code.GDFlagPoleObjects2});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level1Code.GDPlayerObjects2});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDStoneObjects2Objects = Hashtable.newFrom({"Stone": gdjs.Level1Code.GDStoneObjects2});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level1Code.GDPlayerObjects2});
gdjs.Level1Code.asyncCallback17051540 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects3);

{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects3[i].setPosition(7405,(gdjs.Level1Code.GDPlayerObjects3[i].getPointY("")));
}
}{gdjs.evtTools.variable.toggleVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(3));
}}
gdjs.Level1Code.eventsList21 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Level1Code.GDPlayerObjects2) asyncObjectsList.addObject("Player", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.3), (runtimeScene) => (gdjs.Level1Code.asyncCallback17051540(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDDoorObjects2Objects = Hashtable.newFrom({"Door": gdjs.Level1Code.GDDoorObjects2});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level1Code.GDPlayerObjects2});
gdjs.Level1Code.eventsList22 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) > gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0));
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)));
}{gdjs.evtTools.storage.writeNumberInJSONFile("MarioCopy", "Score", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)));
}}

}


};gdjs.Level1Code.asyncCallback17054708 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "MainMenu", false);
}
{ //Subevents
gdjs.Level1Code.eventsList22(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Level1Code.eventsList23 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(4), (runtimeScene) => (gdjs.Level1Code.asyncCallback17054708(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPoints5000Objects2Objects = Hashtable.newFrom({"Points5000": gdjs.Level1Code.GDPoints5000Objects2});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level1Code.GDPlayerObjects2});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPoints4000Objects2Objects = Hashtable.newFrom({"Points4000": gdjs.Level1Code.GDPoints4000Objects2});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level1Code.GDPlayerObjects2});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPoints2000Objects2Objects = Hashtable.newFrom({"Points2000": gdjs.Level1Code.GDPoints2000Objects2});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level1Code.GDPlayerObjects2});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPoints800Objects2Objects = Hashtable.newFrom({"Points800": gdjs.Level1Code.GDPoints800Objects2});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level1Code.GDPlayerObjects2});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPoints400Objects2Objects = Hashtable.newFrom({"Points400": gdjs.Level1Code.GDPoints400Objects2});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level1Code.GDPlayerObjects2});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPoints100Objects1Objects = Hashtable.newFrom({"Points100": gdjs.Level1Code.GDPoints100Objects1});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Level1Code.GDPlayerObjects1});
gdjs.Level1Code.eventsList24 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("FlagPole"), gdjs.Level1Code.GDFlagPoleObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDFlagPoleObjects2Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDPlayerObjects2 */
{gdjs.evtTools.sound.stopSoundOnChannel(runtimeScene, 1);
}{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects2[i].setAnimationName("jump");
}
}{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects2[i].getBehavior("PlatformerObject").setCurrentSpeed(0);
}
}{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects2[i].getBehavior("PlatformerObject").simulateRightKey();
}
}{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects2[i].getBehavior("PlatformerObject").simulateLeftKey();
}
}{gdjs.evtTools.runtimeScene.pauseTimer(runtimeScene, "TimeLeft");
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(8), true);
}
{ //Subevents
gdjs.Level1Code.eventsList19(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("FlagPole"), gdjs.Level1Code.GDFlagPoleObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDFlagPoleObjects2Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects2[i].setAnimationName("jump");
}
}{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects2[i].getBehavior("PlatformerObject").setCurrentSpeed(0);
}
}{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects2[i].getBehavior("PlatformerObject").abortJump();
}
}{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects2[i].getBehavior("PlatformerObject").setCurrentFallSpeed(80);
}
}{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects2[i].getBehavior("PlatformerObject").setMaxFallingSpeed(80, false);
}
}{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects2[i].getBehavior("PlatformerObject").simulateRightKey();
}
}{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects2[i].getBehavior("PlatformerObject").simulateLeftKey();
}
}
{ //Subevents
gdjs.Level1Code.eventsList20(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("FlagPole"), gdjs.Level1Code.GDFlagPoleObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Stone"), gdjs.Level1Code.GDStoneObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDFlagPoleObjects2Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDStoneObjects2Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17051340);
}
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Level1Code.eventsList21(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(3), true);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Brick"), gdjs.Level1Code.GDBrickObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects2);
{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects2[i].getBehavior("PlatformerObject").simulateRightKey();
}
}{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects2[i].getBehavior("SmoothCamera").WaitAndCatchUp(999, 0, 0, 999, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Level1Code.GDBrickObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDBrickObjects2[i].getBehavior("Platform").changePlatformType("Jumpthru");
}
}{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects2[i].getBehavior("PlatformerObject").setJumpSpeed(0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Door"), gdjs.Level1Code.GDDoorObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDDoorObjects2Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects2[i].hide();
}
}
{ //Subevents
gdjs.Level1Code.eventsList23(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Points5000"), gdjs.Level1Code.GDPoints5000Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPoints5000Objects2Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17056892);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Points100"), gdjs.Level1Code.GDPoints100Objects2);
gdjs.copyArray(runtimeScene.getObjects("Points2000"), gdjs.Level1Code.GDPoints2000Objects2);
gdjs.copyArray(runtimeScene.getObjects("Points400"), gdjs.Level1Code.GDPoints400Objects2);
gdjs.copyArray(runtimeScene.getObjects("Points4000"), gdjs.Level1Code.GDPoints4000Objects2);
gdjs.copyArray(runtimeScene.getObjects("Points800"), gdjs.Level1Code.GDPoints800Objects2);
gdjs.copyArray(runtimeScene.getObjects("PolePoints"), gdjs.Level1Code.GDPolePointsObjects2);
{for(var i = 0, len = gdjs.Level1Code.GDPolePointsObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDPolePointsObjects2[i].setBBText("5000");
}
}{for(var i = 0, len = gdjs.Level1Code.GDPoints100Objects2.length ;i < len;++i) {
    gdjs.Level1Code.GDPoints100Objects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDPoints400Objects2.length ;i < len;++i) {
    gdjs.Level1Code.GDPoints400Objects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDPoints800Objects2.length ;i < len;++i) {
    gdjs.Level1Code.GDPoints800Objects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDPoints2000Objects2.length ;i < len;++i) {
    gdjs.Level1Code.GDPoints2000Objects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDPoints4000Objects2.length ;i < len;++i) {
    gdjs.Level1Code.GDPoints4000Objects2[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getScene().getVariables().getFromIndex(0).add(5000);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Points4000"), gdjs.Level1Code.GDPoints4000Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPoints4000Objects2Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17058604);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Points100"), gdjs.Level1Code.GDPoints100Objects2);
gdjs.copyArray(runtimeScene.getObjects("Points2000"), gdjs.Level1Code.GDPoints2000Objects2);
gdjs.copyArray(runtimeScene.getObjects("Points400"), gdjs.Level1Code.GDPoints400Objects2);
gdjs.copyArray(runtimeScene.getObjects("Points800"), gdjs.Level1Code.GDPoints800Objects2);
gdjs.copyArray(runtimeScene.getObjects("PolePoints"), gdjs.Level1Code.GDPolePointsObjects2);
{for(var i = 0, len = gdjs.Level1Code.GDPolePointsObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDPolePointsObjects2[i].setBBText("4000");
}
}{for(var i = 0, len = gdjs.Level1Code.GDPoints100Objects2.length ;i < len;++i) {
    gdjs.Level1Code.GDPoints100Objects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDPoints400Objects2.length ;i < len;++i) {
    gdjs.Level1Code.GDPoints400Objects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDPoints800Objects2.length ;i < len;++i) {
    gdjs.Level1Code.GDPoints800Objects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDPoints2000Objects2.length ;i < len;++i) {
    gdjs.Level1Code.GDPoints2000Objects2[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getScene().getVariables().getFromIndex(0).add(4000);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Points2000"), gdjs.Level1Code.GDPoints2000Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPoints2000Objects2Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17060196);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Points100"), gdjs.Level1Code.GDPoints100Objects2);
gdjs.copyArray(runtimeScene.getObjects("Points400"), gdjs.Level1Code.GDPoints400Objects2);
gdjs.copyArray(runtimeScene.getObjects("Points800"), gdjs.Level1Code.GDPoints800Objects2);
gdjs.copyArray(runtimeScene.getObjects("PolePoints"), gdjs.Level1Code.GDPolePointsObjects2);
{for(var i = 0, len = gdjs.Level1Code.GDPolePointsObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDPolePointsObjects2[i].setBBText("2000");
}
}{for(var i = 0, len = gdjs.Level1Code.GDPoints100Objects2.length ;i < len;++i) {
    gdjs.Level1Code.GDPoints100Objects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDPoints400Objects2.length ;i < len;++i) {
    gdjs.Level1Code.GDPoints400Objects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDPoints800Objects2.length ;i < len;++i) {
    gdjs.Level1Code.GDPoints800Objects2[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getScene().getVariables().getFromIndex(0).add(2000);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Points800"), gdjs.Level1Code.GDPoints800Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPoints800Objects2Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17061756);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Points100"), gdjs.Level1Code.GDPoints100Objects2);
gdjs.copyArray(runtimeScene.getObjects("Points400"), gdjs.Level1Code.GDPoints400Objects2);
gdjs.copyArray(runtimeScene.getObjects("PolePoints"), gdjs.Level1Code.GDPolePointsObjects2);
{for(var i = 0, len = gdjs.Level1Code.GDPolePointsObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDPolePointsObjects2[i].setBBText("800");
}
}{for(var i = 0, len = gdjs.Level1Code.GDPoints100Objects2.length ;i < len;++i) {
    gdjs.Level1Code.GDPoints100Objects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDPoints400Objects2.length ;i < len;++i) {
    gdjs.Level1Code.GDPoints400Objects2[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getScene().getVariables().getFromIndex(0).add(800);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Points400"), gdjs.Level1Code.GDPoints400Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPoints400Objects2Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17063276);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Points100"), gdjs.Level1Code.GDPoints100Objects2);
gdjs.copyArray(runtimeScene.getObjects("PolePoints"), gdjs.Level1Code.GDPolePointsObjects2);
{for(var i = 0, len = gdjs.Level1Code.GDPolePointsObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDPolePointsObjects2[i].setBBText("400");
}
}{for(var i = 0, len = gdjs.Level1Code.GDPoints100Objects2.length ;i < len;++i) {
    gdjs.Level1Code.GDPoints100Objects2[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getScene().getVariables().getFromIndex(0).add(400);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("Points100"), gdjs.Level1Code.GDPoints100Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPoints100Objects1Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17064420);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("PolePoints"), gdjs.Level1Code.GDPolePointsObjects1);
{for(var i = 0, len = gdjs.Level1Code.GDPolePointsObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDPolePointsObjects1[i].setBBText("100");
}
}{runtimeScene.getScene().getVariables().getFromIndex(0).add(100);
}}

}


};gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom1Objects3Objects = Hashtable.newFrom({"Mushroom1": gdjs.Level1Code.GDMushroom1Objects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDGoLeft1Objects3Objects = Hashtable.newFrom({"GoLeft1": gdjs.Level1Code.GDGoLeft1Objects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom1Objects3Objects = Hashtable.newFrom({"Mushroom1": gdjs.Level1Code.GDMushroom1Objects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDGoRight1Objects3Objects = Hashtable.newFrom({"GoRight1": gdjs.Level1Code.GDGoRight1Objects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDHeadDMG1Objects3Objects = Hashtable.newFrom({"HeadDMG1": gdjs.Level1Code.GDHeadDMG1Objects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Level1Code.GDPlayerObjects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom1Objects3Objects = Hashtable.newFrom({"Mushroom1": gdjs.Level1Code.GDMushroom1Objects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Level1Code.GDPlayerObjects3});
gdjs.Level1Code.asyncCallback17071964 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects6);

{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects6.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects6[i].setOpacity(255);
}
}}
gdjs.Level1Code.eventsList25 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.Level1Code.GDPlayerObjects5) asyncObjectsList.addObject("Player", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Level1Code.asyncCallback17071964(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level1Code.asyncCallback17071684 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects5);

{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects5.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects5[i].setOpacity(100);
}
}
{ //Subevents
gdjs.Level1Code.eventsList25(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Level1Code.eventsList26 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.Level1Code.GDPlayerObjects4) asyncObjectsList.addObject("Player", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Level1Code.asyncCallback17071684(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level1Code.asyncCallback17071388 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects4);

{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects4[i].setOpacity(255);
}
}
{ //Subevents
gdjs.Level1Code.eventsList26(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Level1Code.eventsList27 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Level1Code.GDPlayerObjects3) asyncObjectsList.addObject("Player", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Level1Code.asyncCallback17071388(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level1Code.eventsList28 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("GoLeft1"), gdjs.Level1Code.GDGoLeft1Objects3);
gdjs.copyArray(runtimeScene.getObjects("GoRight1"), gdjs.Level1Code.GDGoRight1Objects3);
gdjs.copyArray(runtimeScene.getObjects("HeadDMG1"), gdjs.Level1Code.GDHeadDMG1Objects3);
{for(var i = 0, len = gdjs.Level1Code.GDGoLeft1Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDGoLeft1Objects3[i].setOpacity(0);
}
}{for(var i = 0, len = gdjs.Level1Code.GDGoRight1Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDGoRight1Objects3[i].setOpacity(0);
}
}{for(var i = 0, len = gdjs.Level1Code.GDHeadDMG1Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDHeadDMG1Objects3[i].setOpacity(0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("GoLeft1"), gdjs.Level1Code.GDGoLeft1Objects3);
gdjs.copyArray(runtimeScene.getObjects("Mushroom1"), gdjs.Level1Code.GDMushroom1Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom1Objects3Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDGoLeft1Objects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDMushroom1Objects3 */
{for(var i = 0, len = gdjs.Level1Code.GDMushroom1Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDMushroom1Objects3[i].returnVariable(gdjs.Level1Code.GDMushroom1Objects3[i].getVariables().getFromIndex(0)).setNumber(0);
}
}{for(var i = 0, len = gdjs.Level1Code.GDMushroom1Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDMushroom1Objects3[i].flipX(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("GoRight1"), gdjs.Level1Code.GDGoRight1Objects3);
gdjs.copyArray(runtimeScene.getObjects("Mushroom1"), gdjs.Level1Code.GDMushroom1Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom1Objects3Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDGoRight1Objects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDMushroom1Objects3 */
{for(var i = 0, len = gdjs.Level1Code.GDMushroom1Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDMushroom1Objects3[i].returnVariable(gdjs.Level1Code.GDMushroom1Objects3[i].getVariables().getFromIndex(0)).setNumber(1);
}
}{for(var i = 0, len = gdjs.Level1Code.GDMushroom1Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDMushroom1Objects3[i].flipX(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Mushroom1"), gdjs.Level1Code.GDMushroom1Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDMushroom1Objects3.length;i<l;++i) {
    if ( gdjs.Level1Code.GDMushroom1Objects3[i].getVariableNumber(gdjs.Level1Code.GDMushroom1Objects3[i].getVariables().getFromIndex(0)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDMushroom1Objects3[k] = gdjs.Level1Code.GDMushroom1Objects3[i];
        ++k;
    }
}
gdjs.Level1Code.GDMushroom1Objects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("GoRight1"), gdjs.Level1Code.GDGoRight1Objects3);
/* Reuse gdjs.Level1Code.GDMushroom1Objects3 */
{for(var i = 0, len = gdjs.Level1Code.GDMushroom1Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDMushroom1Objects3[i].addForceTowardObject((gdjs.Level1Code.GDGoRight1Objects3.length !== 0 ? gdjs.Level1Code.GDGoRight1Objects3[0] : null), 100, 0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Mushroom1"), gdjs.Level1Code.GDMushroom1Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDMushroom1Objects3.length;i<l;++i) {
    if ( gdjs.Level1Code.GDMushroom1Objects3[i].getVariableNumber(gdjs.Level1Code.GDMushroom1Objects3[i].getVariables().getFromIndex(0)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDMushroom1Objects3[k] = gdjs.Level1Code.GDMushroom1Objects3[i];
        ++k;
    }
}
gdjs.Level1Code.GDMushroom1Objects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("GoLeft1"), gdjs.Level1Code.GDGoLeft1Objects3);
/* Reuse gdjs.Level1Code.GDMushroom1Objects3 */
{for(var i = 0, len = gdjs.Level1Code.GDMushroom1Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDMushroom1Objects3[i].addForceTowardObject((gdjs.Level1Code.GDGoLeft1Objects3.length !== 0 ? gdjs.Level1Code.GDGoLeft1Objects3[0] : null), 100, 0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("HeadDMG1"), gdjs.Level1Code.GDHeadDMG1Objects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDHeadDMG1Objects3Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDHeadDMG1Objects3 */
gdjs.copyArray(runtimeScene.getObjects("Mushroom1"), gdjs.Level1Code.GDMushroom1Objects3);
/* Reuse gdjs.Level1Code.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.Level1Code.GDHeadDMG1Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDHeadDMG1Objects3[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDMushroom1Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDMushroom1Objects3[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getScene().getVariables().getFromIndex(0).add(100);
}{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects3[i].getBehavior("PlatformerObject").setCanJump();
}
}{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects3[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Mushroom1"), gdjs.Level1Code.GDMushroom1Objects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom1Objects3Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17071108);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects3[i].setOpacity(100);
}
}
{ //Subevents
gdjs.Level1Code.eventsList27(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("HeadDMG1"), gdjs.Level1Code.GDHeadDMG1Objects2);
gdjs.copyArray(runtimeScene.getObjects("Mushroom1"), gdjs.Level1Code.GDMushroom1Objects2);
{for(var i = 0, len = gdjs.Level1Code.GDHeadDMG1Objects2.length ;i < len;++i) {
    gdjs.Level1Code.GDHeadDMG1Objects2[i].setPosition((( gdjs.Level1Code.GDMushroom1Objects2.length === 0 ) ? 0 :gdjs.Level1Code.GDMushroom1Objects2[0].getPointX("")),(( gdjs.Level1Code.GDMushroom1Objects2.length === 0 ) ? 0 :gdjs.Level1Code.GDMushroom1Objects2[0].getPointY("")) - 5);
}
}}

}


};gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom2Objects3Objects = Hashtable.newFrom({"Mushroom2": gdjs.Level1Code.GDMushroom2Objects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDGoLeft2Objects3Objects = Hashtable.newFrom({"GoLeft2": gdjs.Level1Code.GDGoLeft2Objects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom2Objects3Objects = Hashtable.newFrom({"Mushroom2": gdjs.Level1Code.GDMushroom2Objects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDGoRight2Objects3Objects = Hashtable.newFrom({"GoRight2": gdjs.Level1Code.GDGoRight2Objects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDHeadDMG2Objects3Objects = Hashtable.newFrom({"HeadDMG2": gdjs.Level1Code.GDHeadDMG2Objects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Level1Code.GDPlayerObjects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom2Objects3Objects = Hashtable.newFrom({"Mushroom2": gdjs.Level1Code.GDMushroom2Objects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Level1Code.GDPlayerObjects3});
gdjs.Level1Code.asyncCallback17080004 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects6);

{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects6.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects6[i].setOpacity(255);
}
}}
gdjs.Level1Code.eventsList29 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.Level1Code.GDPlayerObjects5) asyncObjectsList.addObject("Player", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Level1Code.asyncCallback17080004(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level1Code.asyncCallback17079724 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects5);

{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects5.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects5[i].setOpacity(100);
}
}
{ //Subevents
gdjs.Level1Code.eventsList29(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Level1Code.eventsList30 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.Level1Code.GDPlayerObjects4) asyncObjectsList.addObject("Player", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Level1Code.asyncCallback17079724(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level1Code.asyncCallback17079428 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects4);

{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects4[i].setOpacity(255);
}
}
{ //Subevents
gdjs.Level1Code.eventsList30(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Level1Code.eventsList31 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Level1Code.GDPlayerObjects3) asyncObjectsList.addObject("Player", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Level1Code.asyncCallback17079428(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level1Code.eventsList32 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("GoLeft2"), gdjs.Level1Code.GDGoLeft2Objects3);
gdjs.copyArray(runtimeScene.getObjects("GoRight2"), gdjs.Level1Code.GDGoRight2Objects3);
gdjs.copyArray(runtimeScene.getObjects("HeadDMG2"), gdjs.Level1Code.GDHeadDMG2Objects3);
{for(var i = 0, len = gdjs.Level1Code.GDGoLeft2Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDGoLeft2Objects3[i].setOpacity(0);
}
}{for(var i = 0, len = gdjs.Level1Code.GDGoRight2Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDGoRight2Objects3[i].setOpacity(0);
}
}{for(var i = 0, len = gdjs.Level1Code.GDHeadDMG2Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDHeadDMG2Objects3[i].setOpacity(0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("GoLeft2"), gdjs.Level1Code.GDGoLeft2Objects3);
gdjs.copyArray(runtimeScene.getObjects("Mushroom2"), gdjs.Level1Code.GDMushroom2Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom2Objects3Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDGoLeft2Objects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17074252);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDMushroom2Objects3 */
{for(var i = 0, len = gdjs.Level1Code.GDMushroom2Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDMushroom2Objects3[i].returnVariable(gdjs.Level1Code.GDMushroom2Objects3[i].getVariables().getFromIndex(0)).setNumber(0);
}
}{for(var i = 0, len = gdjs.Level1Code.GDMushroom2Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDMushroom2Objects3[i].flipX(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("GoRight2"), gdjs.Level1Code.GDGoRight2Objects3);
gdjs.copyArray(runtimeScene.getObjects("Mushroom2"), gdjs.Level1Code.GDMushroom2Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom2Objects3Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDGoRight2Objects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17075252);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDMushroom2Objects3 */
{for(var i = 0, len = gdjs.Level1Code.GDMushroom2Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDMushroom2Objects3[i].returnVariable(gdjs.Level1Code.GDMushroom2Objects3[i].getVariables().getFromIndex(0)).setNumber(1);
}
}{for(var i = 0, len = gdjs.Level1Code.GDMushroom2Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDMushroom2Objects3[i].flipX(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Mushroom2"), gdjs.Level1Code.GDMushroom2Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDMushroom2Objects3.length;i<l;++i) {
    if ( gdjs.Level1Code.GDMushroom2Objects3[i].getVariableNumber(gdjs.Level1Code.GDMushroom2Objects3[i].getVariables().getFromIndex(0)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDMushroom2Objects3[k] = gdjs.Level1Code.GDMushroom2Objects3[i];
        ++k;
    }
}
gdjs.Level1Code.GDMushroom2Objects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("GoRight2"), gdjs.Level1Code.GDGoRight2Objects3);
/* Reuse gdjs.Level1Code.GDMushroom2Objects3 */
{for(var i = 0, len = gdjs.Level1Code.GDMushroom2Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDMushroom2Objects3[i].addForceTowardObject((gdjs.Level1Code.GDGoRight2Objects3.length !== 0 ? gdjs.Level1Code.GDGoRight2Objects3[0] : null), 100, 0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Mushroom2"), gdjs.Level1Code.GDMushroom2Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDMushroom2Objects3.length;i<l;++i) {
    if ( gdjs.Level1Code.GDMushroom2Objects3[i].getVariableNumber(gdjs.Level1Code.GDMushroom2Objects3[i].getVariables().getFromIndex(0)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDMushroom2Objects3[k] = gdjs.Level1Code.GDMushroom2Objects3[i];
        ++k;
    }
}
gdjs.Level1Code.GDMushroom2Objects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("GoLeft2"), gdjs.Level1Code.GDGoLeft2Objects3);
/* Reuse gdjs.Level1Code.GDMushroom2Objects3 */
{for(var i = 0, len = gdjs.Level1Code.GDMushroom2Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDMushroom2Objects3[i].addForceTowardObject((gdjs.Level1Code.GDGoLeft2Objects3.length !== 0 ? gdjs.Level1Code.GDGoLeft2Objects3[0] : null), 100, 0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("HeadDMG2"), gdjs.Level1Code.GDHeadDMG2Objects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDHeadDMG2Objects3Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDHeadDMG2Objects3 */
gdjs.copyArray(runtimeScene.getObjects("Mushroom2"), gdjs.Level1Code.GDMushroom2Objects3);
/* Reuse gdjs.Level1Code.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.Level1Code.GDHeadDMG2Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDHeadDMG2Objects3[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDMushroom2Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDMushroom2Objects3[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getScene().getVariables().getFromIndex(0).add(100);
}{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects3[i].getBehavior("PlatformerObject").setCanJump();
}
}{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects3[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Mushroom2"), gdjs.Level1Code.GDMushroom2Objects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom2Objects3Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17079148);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects3[i].setOpacity(100);
}
}
{ //Subevents
gdjs.Level1Code.eventsList31(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("HeadDMG2"), gdjs.Level1Code.GDHeadDMG2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Mushroom2"), gdjs.Level1Code.GDMushroom2Objects2);
{for(var i = 0, len = gdjs.Level1Code.GDHeadDMG2Objects2.length ;i < len;++i) {
    gdjs.Level1Code.GDHeadDMG2Objects2[i].setPosition((( gdjs.Level1Code.GDMushroom2Objects2.length === 0 ) ? 0 :gdjs.Level1Code.GDMushroom2Objects2[0].getPointX("")),(( gdjs.Level1Code.GDMushroom2Objects2.length === 0 ) ? 0 :gdjs.Level1Code.GDMushroom2Objects2[0].getPointY("")) - 5);
}
}}

}


};gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom3Objects3Objects = Hashtable.newFrom({"Mushroom3": gdjs.Level1Code.GDMushroom3Objects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDGoLeft3Objects3Objects = Hashtable.newFrom({"GoLeft3": gdjs.Level1Code.GDGoLeft3Objects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom3Objects3Objects = Hashtable.newFrom({"Mushroom3": gdjs.Level1Code.GDMushroom3Objects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDGoRight3Objects3Objects = Hashtable.newFrom({"GoRight3": gdjs.Level1Code.GDGoRight3Objects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDHeadDMG3Objects3Objects = Hashtable.newFrom({"HeadDMG3": gdjs.Level1Code.GDHeadDMG3Objects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Level1Code.GDPlayerObjects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom3Objects3Objects = Hashtable.newFrom({"Mushroom3": gdjs.Level1Code.GDMushroom3Objects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Level1Code.GDPlayerObjects3});
gdjs.Level1Code.asyncCallback17088068 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects6);

{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects6.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects6[i].setOpacity(255);
}
}}
gdjs.Level1Code.eventsList33 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.Level1Code.GDPlayerObjects5) asyncObjectsList.addObject("Player", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Level1Code.asyncCallback17088068(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level1Code.asyncCallback17087788 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects5);

{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects5.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects5[i].setOpacity(100);
}
}
{ //Subevents
gdjs.Level1Code.eventsList33(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Level1Code.eventsList34 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.Level1Code.GDPlayerObjects4) asyncObjectsList.addObject("Player", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Level1Code.asyncCallback17087788(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level1Code.asyncCallback17087492 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects4);

{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects4[i].setOpacity(255);
}
}
{ //Subevents
gdjs.Level1Code.eventsList34(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Level1Code.eventsList35 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Level1Code.GDPlayerObjects3) asyncObjectsList.addObject("Player", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Level1Code.asyncCallback17087492(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level1Code.eventsList36 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("GoLeft3"), gdjs.Level1Code.GDGoLeft3Objects3);
gdjs.copyArray(runtimeScene.getObjects("GoRight3"), gdjs.Level1Code.GDGoRight3Objects3);
gdjs.copyArray(runtimeScene.getObjects("HeadDMG3"), gdjs.Level1Code.GDHeadDMG3Objects3);
{for(var i = 0, len = gdjs.Level1Code.GDGoLeft3Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDGoLeft3Objects3[i].setOpacity(0);
}
}{for(var i = 0, len = gdjs.Level1Code.GDGoRight3Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDGoRight3Objects3[i].setOpacity(0);
}
}{for(var i = 0, len = gdjs.Level1Code.GDHeadDMG3Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDHeadDMG3Objects3[i].setOpacity(0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("GoLeft3"), gdjs.Level1Code.GDGoLeft3Objects3);
gdjs.copyArray(runtimeScene.getObjects("Mushroom3"), gdjs.Level1Code.GDMushroom3Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom3Objects3Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDGoLeft3Objects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17082316);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDMushroom3Objects3 */
{for(var i = 0, len = gdjs.Level1Code.GDMushroom3Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDMushroom3Objects3[i].returnVariable(gdjs.Level1Code.GDMushroom3Objects3[i].getVariables().getFromIndex(0)).setNumber(0);
}
}{for(var i = 0, len = gdjs.Level1Code.GDMushroom3Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDMushroom3Objects3[i].flipX(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("GoRight3"), gdjs.Level1Code.GDGoRight3Objects3);
gdjs.copyArray(runtimeScene.getObjects("Mushroom3"), gdjs.Level1Code.GDMushroom3Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom3Objects3Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDGoRight3Objects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17083316);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDMushroom3Objects3 */
{for(var i = 0, len = gdjs.Level1Code.GDMushroom3Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDMushroom3Objects3[i].returnVariable(gdjs.Level1Code.GDMushroom3Objects3[i].getVariables().getFromIndex(0)).setNumber(1);
}
}{for(var i = 0, len = gdjs.Level1Code.GDMushroom3Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDMushroom3Objects3[i].flipX(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Mushroom3"), gdjs.Level1Code.GDMushroom3Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDMushroom3Objects3.length;i<l;++i) {
    if ( gdjs.Level1Code.GDMushroom3Objects3[i].getVariableNumber(gdjs.Level1Code.GDMushroom3Objects3[i].getVariables().getFromIndex(0)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDMushroom3Objects3[k] = gdjs.Level1Code.GDMushroom3Objects3[i];
        ++k;
    }
}
gdjs.Level1Code.GDMushroom3Objects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("GoRight3"), gdjs.Level1Code.GDGoRight3Objects3);
/* Reuse gdjs.Level1Code.GDMushroom3Objects3 */
{for(var i = 0, len = gdjs.Level1Code.GDMushroom3Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDMushroom3Objects3[i].addForceTowardObject((gdjs.Level1Code.GDGoRight3Objects3.length !== 0 ? gdjs.Level1Code.GDGoRight3Objects3[0] : null), 100, 0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Mushroom3"), gdjs.Level1Code.GDMushroom3Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDMushroom3Objects3.length;i<l;++i) {
    if ( gdjs.Level1Code.GDMushroom3Objects3[i].getVariableNumber(gdjs.Level1Code.GDMushroom3Objects3[i].getVariables().getFromIndex(0)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDMushroom3Objects3[k] = gdjs.Level1Code.GDMushroom3Objects3[i];
        ++k;
    }
}
gdjs.Level1Code.GDMushroom3Objects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("GoLeft3"), gdjs.Level1Code.GDGoLeft3Objects3);
/* Reuse gdjs.Level1Code.GDMushroom3Objects3 */
{for(var i = 0, len = gdjs.Level1Code.GDMushroom3Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDMushroom3Objects3[i].addForceTowardObject((gdjs.Level1Code.GDGoLeft3Objects3.length !== 0 ? gdjs.Level1Code.GDGoLeft3Objects3[0] : null), 100, 0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("HeadDMG3"), gdjs.Level1Code.GDHeadDMG3Objects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDHeadDMG3Objects3Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDHeadDMG3Objects3 */
gdjs.copyArray(runtimeScene.getObjects("Mushroom3"), gdjs.Level1Code.GDMushroom3Objects3);
/* Reuse gdjs.Level1Code.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.Level1Code.GDHeadDMG3Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDHeadDMG3Objects3[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDMushroom3Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDMushroom3Objects3[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getScene().getVariables().getFromIndex(0).add(100);
}{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects3[i].getBehavior("PlatformerObject").setCanJump();
}
}{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects3[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Mushroom3"), gdjs.Level1Code.GDMushroom3Objects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom3Objects3Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17087212);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects3[i].setOpacity(100);
}
}
{ //Subevents
gdjs.Level1Code.eventsList35(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("HeadDMG3"), gdjs.Level1Code.GDHeadDMG3Objects2);
gdjs.copyArray(runtimeScene.getObjects("Mushroom3"), gdjs.Level1Code.GDMushroom3Objects2);
{for(var i = 0, len = gdjs.Level1Code.GDHeadDMG3Objects2.length ;i < len;++i) {
    gdjs.Level1Code.GDHeadDMG3Objects2[i].setPosition((( gdjs.Level1Code.GDMushroom3Objects2.length === 0 ) ? 0 :gdjs.Level1Code.GDMushroom3Objects2[0].getPointX("")),(( gdjs.Level1Code.GDMushroom3Objects2.length === 0 ) ? 0 :gdjs.Level1Code.GDMushroom3Objects2[0].getPointY("")) - 5);
}
}}

}


};gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom4Objects3Objects = Hashtable.newFrom({"Mushroom4": gdjs.Level1Code.GDMushroom4Objects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDGoLeft4Objects3Objects = Hashtable.newFrom({"GoLeft4": gdjs.Level1Code.GDGoLeft4Objects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom4Objects3Objects = Hashtable.newFrom({"Mushroom4": gdjs.Level1Code.GDMushroom4Objects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDGoRight4Objects3Objects = Hashtable.newFrom({"GoRight4": gdjs.Level1Code.GDGoRight4Objects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDHeadDMG4Objects3Objects = Hashtable.newFrom({"HeadDMG4": gdjs.Level1Code.GDHeadDMG4Objects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Level1Code.GDPlayerObjects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom4Objects3Objects = Hashtable.newFrom({"Mushroom4": gdjs.Level1Code.GDMushroom4Objects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Level1Code.GDPlayerObjects3});
gdjs.Level1Code.asyncCallback17096124 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects6);

{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects6.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects6[i].setOpacity(255);
}
}}
gdjs.Level1Code.eventsList37 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.Level1Code.GDPlayerObjects5) asyncObjectsList.addObject("Player", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Level1Code.asyncCallback17096124(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level1Code.asyncCallback17095844 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects5);

{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects5.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects5[i].setOpacity(100);
}
}
{ //Subevents
gdjs.Level1Code.eventsList37(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Level1Code.eventsList38 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.Level1Code.GDPlayerObjects4) asyncObjectsList.addObject("Player", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Level1Code.asyncCallback17095844(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level1Code.asyncCallback17095548 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects4);

{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects4[i].setOpacity(255);
}
}
{ //Subevents
gdjs.Level1Code.eventsList38(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Level1Code.eventsList39 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Level1Code.GDPlayerObjects3) asyncObjectsList.addObject("Player", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Level1Code.asyncCallback17095548(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level1Code.eventsList40 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("GoLeft4"), gdjs.Level1Code.GDGoLeft4Objects3);
gdjs.copyArray(runtimeScene.getObjects("GoRight4"), gdjs.Level1Code.GDGoRight4Objects3);
gdjs.copyArray(runtimeScene.getObjects("HeadDMG4"), gdjs.Level1Code.GDHeadDMG4Objects3);
{for(var i = 0, len = gdjs.Level1Code.GDGoLeft4Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDGoLeft4Objects3[i].setOpacity(0);
}
}{for(var i = 0, len = gdjs.Level1Code.GDGoRight4Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDGoRight4Objects3[i].setOpacity(0);
}
}{for(var i = 0, len = gdjs.Level1Code.GDHeadDMG4Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDHeadDMG4Objects3[i].setOpacity(0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("GoLeft4"), gdjs.Level1Code.GDGoLeft4Objects3);
gdjs.copyArray(runtimeScene.getObjects("Mushroom4"), gdjs.Level1Code.GDMushroom4Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom4Objects3Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDGoLeft4Objects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17090372);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDMushroom4Objects3 */
{for(var i = 0, len = gdjs.Level1Code.GDMushroom4Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDMushroom4Objects3[i].returnVariable(gdjs.Level1Code.GDMushroom4Objects3[i].getVariables().getFromIndex(0)).setNumber(0);
}
}{for(var i = 0, len = gdjs.Level1Code.GDMushroom4Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDMushroom4Objects3[i].flipX(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("GoRight4"), gdjs.Level1Code.GDGoRight4Objects3);
gdjs.copyArray(runtimeScene.getObjects("Mushroom4"), gdjs.Level1Code.GDMushroom4Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom4Objects3Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDGoRight4Objects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17091372);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDMushroom4Objects3 */
{for(var i = 0, len = gdjs.Level1Code.GDMushroom4Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDMushroom4Objects3[i].returnVariable(gdjs.Level1Code.GDMushroom4Objects3[i].getVariables().getFromIndex(0)).setNumber(1);
}
}{for(var i = 0, len = gdjs.Level1Code.GDMushroom4Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDMushroom4Objects3[i].flipX(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Mushroom4"), gdjs.Level1Code.GDMushroom4Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDMushroom4Objects3.length;i<l;++i) {
    if ( gdjs.Level1Code.GDMushroom4Objects3[i].getVariableNumber(gdjs.Level1Code.GDMushroom4Objects3[i].getVariables().getFromIndex(0)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDMushroom4Objects3[k] = gdjs.Level1Code.GDMushroom4Objects3[i];
        ++k;
    }
}
gdjs.Level1Code.GDMushroom4Objects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("GoRight4"), gdjs.Level1Code.GDGoRight4Objects3);
/* Reuse gdjs.Level1Code.GDMushroom4Objects3 */
{for(var i = 0, len = gdjs.Level1Code.GDMushroom4Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDMushroom4Objects3[i].addForceTowardObject((gdjs.Level1Code.GDGoRight4Objects3.length !== 0 ? gdjs.Level1Code.GDGoRight4Objects3[0] : null), 100, 0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Mushroom4"), gdjs.Level1Code.GDMushroom4Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDMushroom4Objects3.length;i<l;++i) {
    if ( gdjs.Level1Code.GDMushroom4Objects3[i].getVariableNumber(gdjs.Level1Code.GDMushroom4Objects3[i].getVariables().getFromIndex(0)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDMushroom4Objects3[k] = gdjs.Level1Code.GDMushroom4Objects3[i];
        ++k;
    }
}
gdjs.Level1Code.GDMushroom4Objects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("GoLeft4"), gdjs.Level1Code.GDGoLeft4Objects3);
/* Reuse gdjs.Level1Code.GDMushroom4Objects3 */
{for(var i = 0, len = gdjs.Level1Code.GDMushroom4Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDMushroom4Objects3[i].addForceTowardObject((gdjs.Level1Code.GDGoLeft4Objects3.length !== 0 ? gdjs.Level1Code.GDGoLeft4Objects3[0] : null), 100, 0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("HeadDMG4"), gdjs.Level1Code.GDHeadDMG4Objects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDHeadDMG4Objects3Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDHeadDMG4Objects3 */
gdjs.copyArray(runtimeScene.getObjects("Mushroom4"), gdjs.Level1Code.GDMushroom4Objects3);
/* Reuse gdjs.Level1Code.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.Level1Code.GDHeadDMG4Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDHeadDMG4Objects3[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDMushroom4Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDMushroom4Objects3[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getScene().getVariables().getFromIndex(0).add(100);
}{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects3[i].getBehavior("PlatformerObject").setCanJump();
}
}{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects3[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Mushroom4"), gdjs.Level1Code.GDMushroom4Objects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom4Objects3Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17095268);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects3[i].setOpacity(100);
}
}
{ //Subevents
gdjs.Level1Code.eventsList39(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("HeadDMG4"), gdjs.Level1Code.GDHeadDMG4Objects2);
gdjs.copyArray(runtimeScene.getObjects("Mushroom4"), gdjs.Level1Code.GDMushroom4Objects2);
{for(var i = 0, len = gdjs.Level1Code.GDHeadDMG4Objects2.length ;i < len;++i) {
    gdjs.Level1Code.GDHeadDMG4Objects2[i].setPosition((( gdjs.Level1Code.GDMushroom4Objects2.length === 0 ) ? 0 :gdjs.Level1Code.GDMushroom4Objects2[0].getPointX("")),(( gdjs.Level1Code.GDMushroom4Objects2.length === 0 ) ? 0 :gdjs.Level1Code.GDMushroom4Objects2[0].getPointY("")) - 5);
}
}}

}


};gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom5Objects3Objects = Hashtable.newFrom({"Mushroom5": gdjs.Level1Code.GDMushroom5Objects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDGoLeft5Objects3Objects = Hashtable.newFrom({"GoLeft5": gdjs.Level1Code.GDGoLeft5Objects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom5Objects3Objects = Hashtable.newFrom({"Mushroom5": gdjs.Level1Code.GDMushroom5Objects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDGoRight5Objects3Objects = Hashtable.newFrom({"GoRight5": gdjs.Level1Code.GDGoRight5Objects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDHeadDMG5Objects3Objects = Hashtable.newFrom({"HeadDMG5": gdjs.Level1Code.GDHeadDMG5Objects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Level1Code.GDPlayerObjects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom5Objects3Objects = Hashtable.newFrom({"Mushroom5": gdjs.Level1Code.GDMushroom5Objects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Level1Code.GDPlayerObjects3});
gdjs.Level1Code.asyncCallback17104164 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects6);

{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects6.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects6[i].setOpacity(255);
}
}}
gdjs.Level1Code.eventsList41 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.Level1Code.GDPlayerObjects5) asyncObjectsList.addObject("Player", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Level1Code.asyncCallback17104164(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level1Code.asyncCallback17103884 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects5);

{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects5.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects5[i].setOpacity(100);
}
}
{ //Subevents
gdjs.Level1Code.eventsList41(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Level1Code.eventsList42 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.Level1Code.GDPlayerObjects4) asyncObjectsList.addObject("Player", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Level1Code.asyncCallback17103884(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level1Code.asyncCallback17103588 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects4);

{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects4[i].setOpacity(255);
}
}
{ //Subevents
gdjs.Level1Code.eventsList42(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Level1Code.eventsList43 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Level1Code.GDPlayerObjects3) asyncObjectsList.addObject("Player", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Level1Code.asyncCallback17103588(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level1Code.eventsList44 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("GoLeft5"), gdjs.Level1Code.GDGoLeft5Objects3);
gdjs.copyArray(runtimeScene.getObjects("GoRight5"), gdjs.Level1Code.GDGoRight5Objects3);
gdjs.copyArray(runtimeScene.getObjects("HeadDMG5"), gdjs.Level1Code.GDHeadDMG5Objects3);
{for(var i = 0, len = gdjs.Level1Code.GDGoLeft5Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDGoLeft5Objects3[i].setOpacity(0);
}
}{for(var i = 0, len = gdjs.Level1Code.GDGoRight5Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDGoRight5Objects3[i].setOpacity(0);
}
}{for(var i = 0, len = gdjs.Level1Code.GDHeadDMG5Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDHeadDMG5Objects3[i].setOpacity(0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("GoLeft5"), gdjs.Level1Code.GDGoLeft5Objects3);
gdjs.copyArray(runtimeScene.getObjects("Mushroom5"), gdjs.Level1Code.GDMushroom5Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom5Objects3Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDGoLeft5Objects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17098412);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDMushroom5Objects3 */
{for(var i = 0, len = gdjs.Level1Code.GDMushroom5Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDMushroom5Objects3[i].returnVariable(gdjs.Level1Code.GDMushroom5Objects3[i].getVariables().getFromIndex(0)).setNumber(0);
}
}{for(var i = 0, len = gdjs.Level1Code.GDMushroom5Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDMushroom5Objects3[i].flipX(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("GoRight5"), gdjs.Level1Code.GDGoRight5Objects3);
gdjs.copyArray(runtimeScene.getObjects("Mushroom5"), gdjs.Level1Code.GDMushroom5Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom5Objects3Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDGoRight5Objects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17099412);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDMushroom5Objects3 */
{for(var i = 0, len = gdjs.Level1Code.GDMushroom5Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDMushroom5Objects3[i].returnVariable(gdjs.Level1Code.GDMushroom5Objects3[i].getVariables().getFromIndex(0)).setNumber(1);
}
}{for(var i = 0, len = gdjs.Level1Code.GDMushroom5Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDMushroom5Objects3[i].flipX(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Mushroom5"), gdjs.Level1Code.GDMushroom5Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDMushroom5Objects3.length;i<l;++i) {
    if ( gdjs.Level1Code.GDMushroom5Objects3[i].getVariableNumber(gdjs.Level1Code.GDMushroom5Objects3[i].getVariables().getFromIndex(0)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDMushroom5Objects3[k] = gdjs.Level1Code.GDMushroom5Objects3[i];
        ++k;
    }
}
gdjs.Level1Code.GDMushroom5Objects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("GoRight5"), gdjs.Level1Code.GDGoRight5Objects3);
/* Reuse gdjs.Level1Code.GDMushroom5Objects3 */
{for(var i = 0, len = gdjs.Level1Code.GDMushroom5Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDMushroom5Objects3[i].addForceTowardObject((gdjs.Level1Code.GDGoRight5Objects3.length !== 0 ? gdjs.Level1Code.GDGoRight5Objects3[0] : null), 100, 0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Mushroom5"), gdjs.Level1Code.GDMushroom5Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDMushroom5Objects3.length;i<l;++i) {
    if ( gdjs.Level1Code.GDMushroom5Objects3[i].getVariableNumber(gdjs.Level1Code.GDMushroom5Objects3[i].getVariables().getFromIndex(0)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDMushroom5Objects3[k] = gdjs.Level1Code.GDMushroom5Objects3[i];
        ++k;
    }
}
gdjs.Level1Code.GDMushroom5Objects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("GoLeft5"), gdjs.Level1Code.GDGoLeft5Objects3);
/* Reuse gdjs.Level1Code.GDMushroom5Objects3 */
{for(var i = 0, len = gdjs.Level1Code.GDMushroom5Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDMushroom5Objects3[i].addForceTowardObject((gdjs.Level1Code.GDGoLeft5Objects3.length !== 0 ? gdjs.Level1Code.GDGoLeft5Objects3[0] : null), 100, 0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("HeadDMG5"), gdjs.Level1Code.GDHeadDMG5Objects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDHeadDMG5Objects3Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDHeadDMG5Objects3 */
gdjs.copyArray(runtimeScene.getObjects("Mushroom5"), gdjs.Level1Code.GDMushroom5Objects3);
/* Reuse gdjs.Level1Code.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.Level1Code.GDHeadDMG5Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDHeadDMG5Objects3[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDMushroom5Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDMushroom5Objects3[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getScene().getVariables().getFromIndex(0).add(100);
}{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects3[i].getBehavior("PlatformerObject").setCanJump();
}
}{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects3[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Mushroom5"), gdjs.Level1Code.GDMushroom5Objects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom5Objects3Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17103308);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects3[i].setOpacity(100);
}
}
{ //Subevents
gdjs.Level1Code.eventsList43(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("HeadDMG5"), gdjs.Level1Code.GDHeadDMG5Objects2);
gdjs.copyArray(runtimeScene.getObjects("Mushroom5"), gdjs.Level1Code.GDMushroom5Objects2);
{for(var i = 0, len = gdjs.Level1Code.GDHeadDMG5Objects2.length ;i < len;++i) {
    gdjs.Level1Code.GDHeadDMG5Objects2[i].setPosition((( gdjs.Level1Code.GDMushroom5Objects2.length === 0 ) ? 0 :gdjs.Level1Code.GDMushroom5Objects2[0].getPointX("")),(( gdjs.Level1Code.GDMushroom5Objects2.length === 0 ) ? 0 :gdjs.Level1Code.GDMushroom5Objects2[0].getPointY("")) - 5);
}
}}

}


};gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom6Objects3Objects = Hashtable.newFrom({"Mushroom6": gdjs.Level1Code.GDMushroom6Objects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDGoLeft6Objects3Objects = Hashtable.newFrom({"GoLeft6": gdjs.Level1Code.GDGoLeft6Objects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom6Objects3Objects = Hashtable.newFrom({"Mushroom6": gdjs.Level1Code.GDMushroom6Objects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDGoRight6Objects3Objects = Hashtable.newFrom({"GoRight6": gdjs.Level1Code.GDGoRight6Objects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDHeadDMG6Objects3Objects = Hashtable.newFrom({"HeadDMG6": gdjs.Level1Code.GDHeadDMG6Objects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Level1Code.GDPlayerObjects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom6Objects3Objects = Hashtable.newFrom({"Mushroom6": gdjs.Level1Code.GDMushroom6Objects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Level1Code.GDPlayerObjects3});
gdjs.Level1Code.asyncCallback17112236 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects6);

{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects6.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects6[i].setOpacity(255);
}
}}
gdjs.Level1Code.eventsList45 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.Level1Code.GDPlayerObjects5) asyncObjectsList.addObject("Player", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Level1Code.asyncCallback17112236(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level1Code.asyncCallback17111956 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects5);

{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects5.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects5[i].setOpacity(100);
}
}
{ //Subevents
gdjs.Level1Code.eventsList45(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Level1Code.eventsList46 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.Level1Code.GDPlayerObjects4) asyncObjectsList.addObject("Player", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Level1Code.asyncCallback17111956(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level1Code.asyncCallback17111660 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects4);

{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects4[i].setOpacity(255);
}
}
{ //Subevents
gdjs.Level1Code.eventsList46(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Level1Code.eventsList47 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Level1Code.GDPlayerObjects3) asyncObjectsList.addObject("Player", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Level1Code.asyncCallback17111660(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level1Code.eventsList48 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("GoLeft6"), gdjs.Level1Code.GDGoLeft6Objects3);
gdjs.copyArray(runtimeScene.getObjects("GoRight6"), gdjs.Level1Code.GDGoRight6Objects3);
gdjs.copyArray(runtimeScene.getObjects("HeadDMG6"), gdjs.Level1Code.GDHeadDMG6Objects3);
{for(var i = 0, len = gdjs.Level1Code.GDGoLeft6Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDGoLeft6Objects3[i].setOpacity(0);
}
}{for(var i = 0, len = gdjs.Level1Code.GDGoRight6Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDGoRight6Objects3[i].setOpacity(0);
}
}{for(var i = 0, len = gdjs.Level1Code.GDHeadDMG6Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDHeadDMG6Objects3[i].setOpacity(0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("GoLeft6"), gdjs.Level1Code.GDGoLeft6Objects3);
gdjs.copyArray(runtimeScene.getObjects("Mushroom6"), gdjs.Level1Code.GDMushroom6Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom6Objects3Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDGoLeft6Objects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17106484);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDMushroom6Objects3 */
{for(var i = 0, len = gdjs.Level1Code.GDMushroom6Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDMushroom6Objects3[i].returnVariable(gdjs.Level1Code.GDMushroom6Objects3[i].getVariables().getFromIndex(0)).setNumber(0);
}
}{for(var i = 0, len = gdjs.Level1Code.GDMushroom6Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDMushroom6Objects3[i].flipX(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("GoRight6"), gdjs.Level1Code.GDGoRight6Objects3);
gdjs.copyArray(runtimeScene.getObjects("Mushroom6"), gdjs.Level1Code.GDMushroom6Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom6Objects3Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDGoRight6Objects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17107484);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDMushroom6Objects3 */
{for(var i = 0, len = gdjs.Level1Code.GDMushroom6Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDMushroom6Objects3[i].returnVariable(gdjs.Level1Code.GDMushroom6Objects3[i].getVariables().getFromIndex(0)).setNumber(1);
}
}{for(var i = 0, len = gdjs.Level1Code.GDMushroom6Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDMushroom6Objects3[i].flipX(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Mushroom6"), gdjs.Level1Code.GDMushroom6Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDMushroom6Objects3.length;i<l;++i) {
    if ( gdjs.Level1Code.GDMushroom6Objects3[i].getVariableNumber(gdjs.Level1Code.GDMushroom6Objects3[i].getVariables().getFromIndex(0)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDMushroom6Objects3[k] = gdjs.Level1Code.GDMushroom6Objects3[i];
        ++k;
    }
}
gdjs.Level1Code.GDMushroom6Objects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("GoRight6"), gdjs.Level1Code.GDGoRight6Objects3);
/* Reuse gdjs.Level1Code.GDMushroom6Objects3 */
{for(var i = 0, len = gdjs.Level1Code.GDMushroom6Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDMushroom6Objects3[i].addForceTowardObject((gdjs.Level1Code.GDGoRight6Objects3.length !== 0 ? gdjs.Level1Code.GDGoRight6Objects3[0] : null), 100, 0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Mushroom6"), gdjs.Level1Code.GDMushroom6Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDMushroom6Objects3.length;i<l;++i) {
    if ( gdjs.Level1Code.GDMushroom6Objects3[i].getVariableNumber(gdjs.Level1Code.GDMushroom6Objects3[i].getVariables().getFromIndex(0)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDMushroom6Objects3[k] = gdjs.Level1Code.GDMushroom6Objects3[i];
        ++k;
    }
}
gdjs.Level1Code.GDMushroom6Objects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("GoLeft6"), gdjs.Level1Code.GDGoLeft6Objects3);
/* Reuse gdjs.Level1Code.GDMushroom6Objects3 */
{for(var i = 0, len = gdjs.Level1Code.GDMushroom6Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDMushroom6Objects3[i].addForceTowardObject((gdjs.Level1Code.GDGoLeft6Objects3.length !== 0 ? gdjs.Level1Code.GDGoLeft6Objects3[0] : null), 100, 0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("HeadDMG6"), gdjs.Level1Code.GDHeadDMG6Objects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDHeadDMG6Objects3Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDHeadDMG6Objects3 */
gdjs.copyArray(runtimeScene.getObjects("Mushroom6"), gdjs.Level1Code.GDMushroom6Objects3);
/* Reuse gdjs.Level1Code.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.Level1Code.GDHeadDMG6Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDHeadDMG6Objects3[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDMushroom6Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDMushroom6Objects3[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getScene().getVariables().getFromIndex(0).add(100);
}{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects3[i].getBehavior("PlatformerObject").setCanJump();
}
}{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects3[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Mushroom6"), gdjs.Level1Code.GDMushroom6Objects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom6Objects3Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17111380);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects3[i].setOpacity(100);
}
}
{ //Subevents
gdjs.Level1Code.eventsList47(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("HeadDMG6"), gdjs.Level1Code.GDHeadDMG6Objects2);
gdjs.copyArray(runtimeScene.getObjects("Mushroom6"), gdjs.Level1Code.GDMushroom6Objects2);
{for(var i = 0, len = gdjs.Level1Code.GDHeadDMG6Objects2.length ;i < len;++i) {
    gdjs.Level1Code.GDHeadDMG6Objects2[i].setPosition((( gdjs.Level1Code.GDMushroom6Objects2.length === 0 ) ? 0 :gdjs.Level1Code.GDMushroom6Objects2[0].getPointX("")),(( gdjs.Level1Code.GDMushroom6Objects2.length === 0 ) ? 0 :gdjs.Level1Code.GDMushroom6Objects2[0].getPointY("")) - 5);
}
}}

}


};gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom7Objects3Objects = Hashtable.newFrom({"Mushroom7": gdjs.Level1Code.GDMushroom7Objects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDGoLeft7Objects3Objects = Hashtable.newFrom({"GoLeft7": gdjs.Level1Code.GDGoLeft7Objects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom7Objects3Objects = Hashtable.newFrom({"Mushroom7": gdjs.Level1Code.GDMushroom7Objects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDGoRight7Objects3Objects = Hashtable.newFrom({"GoRight7": gdjs.Level1Code.GDGoRight7Objects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDHeadDMG7Objects3Objects = Hashtable.newFrom({"HeadDMG7": gdjs.Level1Code.GDHeadDMG7Objects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Level1Code.GDPlayerObjects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom7Objects3Objects = Hashtable.newFrom({"Mushroom7": gdjs.Level1Code.GDMushroom7Objects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Level1Code.GDPlayerObjects3});
gdjs.Level1Code.asyncCallback17120276 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects6);

{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects6.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects6[i].setOpacity(255);
}
}}
gdjs.Level1Code.eventsList49 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.Level1Code.GDPlayerObjects5) asyncObjectsList.addObject("Player", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Level1Code.asyncCallback17120276(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level1Code.asyncCallback17119996 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects5);

{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects5.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects5[i].setOpacity(100);
}
}
{ //Subevents
gdjs.Level1Code.eventsList49(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Level1Code.eventsList50 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.Level1Code.GDPlayerObjects4) asyncObjectsList.addObject("Player", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Level1Code.asyncCallback17119996(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level1Code.asyncCallback17119700 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects4);

{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects4[i].setOpacity(255);
}
}
{ //Subevents
gdjs.Level1Code.eventsList50(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Level1Code.eventsList51 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Level1Code.GDPlayerObjects3) asyncObjectsList.addObject("Player", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Level1Code.asyncCallback17119700(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level1Code.eventsList52 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("GoLeft7"), gdjs.Level1Code.GDGoLeft7Objects3);
gdjs.copyArray(runtimeScene.getObjects("GoRight7"), gdjs.Level1Code.GDGoRight7Objects3);
gdjs.copyArray(runtimeScene.getObjects("HeadDMG7"), gdjs.Level1Code.GDHeadDMG7Objects3);
{for(var i = 0, len = gdjs.Level1Code.GDGoLeft7Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDGoLeft7Objects3[i].setOpacity(0);
}
}{for(var i = 0, len = gdjs.Level1Code.GDGoRight7Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDGoRight7Objects3[i].setOpacity(0);
}
}{for(var i = 0, len = gdjs.Level1Code.GDHeadDMG7Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDHeadDMG7Objects3[i].setOpacity(0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("GoLeft7"), gdjs.Level1Code.GDGoLeft7Objects3);
gdjs.copyArray(runtimeScene.getObjects("Mushroom7"), gdjs.Level1Code.GDMushroom7Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom7Objects3Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDGoLeft7Objects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17114524);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDMushroom7Objects3 */
{for(var i = 0, len = gdjs.Level1Code.GDMushroom7Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDMushroom7Objects3[i].returnVariable(gdjs.Level1Code.GDMushroom7Objects3[i].getVariables().getFromIndex(0)).setNumber(0);
}
}{for(var i = 0, len = gdjs.Level1Code.GDMushroom7Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDMushroom7Objects3[i].flipX(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("GoRight7"), gdjs.Level1Code.GDGoRight7Objects3);
gdjs.copyArray(runtimeScene.getObjects("Mushroom7"), gdjs.Level1Code.GDMushroom7Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom7Objects3Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDGoRight7Objects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17115524);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDMushroom7Objects3 */
{for(var i = 0, len = gdjs.Level1Code.GDMushroom7Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDMushroom7Objects3[i].returnVariable(gdjs.Level1Code.GDMushroom7Objects3[i].getVariables().getFromIndex(0)).setNumber(1);
}
}{for(var i = 0, len = gdjs.Level1Code.GDMushroom7Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDMushroom7Objects3[i].flipX(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Mushroom7"), gdjs.Level1Code.GDMushroom7Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDMushroom7Objects3.length;i<l;++i) {
    if ( gdjs.Level1Code.GDMushroom7Objects3[i].getVariableNumber(gdjs.Level1Code.GDMushroom7Objects3[i].getVariables().getFromIndex(0)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDMushroom7Objects3[k] = gdjs.Level1Code.GDMushroom7Objects3[i];
        ++k;
    }
}
gdjs.Level1Code.GDMushroom7Objects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("GoRight7"), gdjs.Level1Code.GDGoRight7Objects3);
/* Reuse gdjs.Level1Code.GDMushroom7Objects3 */
{for(var i = 0, len = gdjs.Level1Code.GDMushroom7Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDMushroom7Objects3[i].addForceTowardObject((gdjs.Level1Code.GDGoRight7Objects3.length !== 0 ? gdjs.Level1Code.GDGoRight7Objects3[0] : null), 100, 0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Mushroom7"), gdjs.Level1Code.GDMushroom7Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDMushroom7Objects3.length;i<l;++i) {
    if ( gdjs.Level1Code.GDMushroom7Objects3[i].getVariableNumber(gdjs.Level1Code.GDMushroom7Objects3[i].getVariables().getFromIndex(0)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDMushroom7Objects3[k] = gdjs.Level1Code.GDMushroom7Objects3[i];
        ++k;
    }
}
gdjs.Level1Code.GDMushroom7Objects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("GoLeft7"), gdjs.Level1Code.GDGoLeft7Objects3);
/* Reuse gdjs.Level1Code.GDMushroom7Objects3 */
{for(var i = 0, len = gdjs.Level1Code.GDMushroom7Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDMushroom7Objects3[i].addForceTowardObject((gdjs.Level1Code.GDGoLeft7Objects3.length !== 0 ? gdjs.Level1Code.GDGoLeft7Objects3[0] : null), 100, 0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("HeadDMG7"), gdjs.Level1Code.GDHeadDMG7Objects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDHeadDMG7Objects3Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDHeadDMG7Objects3 */
gdjs.copyArray(runtimeScene.getObjects("Mushroom7"), gdjs.Level1Code.GDMushroom7Objects3);
/* Reuse gdjs.Level1Code.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.Level1Code.GDHeadDMG7Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDHeadDMG7Objects3[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDMushroom7Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDMushroom7Objects3[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getScene().getVariables().getFromIndex(0).add(100);
}{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects3[i].getBehavior("PlatformerObject").setCanJump();
}
}{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects3[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Mushroom7"), gdjs.Level1Code.GDMushroom7Objects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom7Objects3Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17119420);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects3[i].setOpacity(100);
}
}
{ //Subevents
gdjs.Level1Code.eventsList51(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("HeadDMG7"), gdjs.Level1Code.GDHeadDMG7Objects2);
gdjs.copyArray(runtimeScene.getObjects("Mushroom7"), gdjs.Level1Code.GDMushroom7Objects2);
{for(var i = 0, len = gdjs.Level1Code.GDHeadDMG7Objects2.length ;i < len;++i) {
    gdjs.Level1Code.GDHeadDMG7Objects2[i].setPosition((( gdjs.Level1Code.GDMushroom7Objects2.length === 0 ) ? 0 :gdjs.Level1Code.GDMushroom7Objects2[0].getPointX("")),(( gdjs.Level1Code.GDMushroom7Objects2.length === 0 ) ? 0 :gdjs.Level1Code.GDMushroom7Objects2[0].getPointY("")) - 5);
}
}}

}


};gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom8Objects3Objects = Hashtable.newFrom({"Mushroom8": gdjs.Level1Code.GDMushroom8Objects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDGoLeft8Objects3Objects = Hashtable.newFrom({"GoLeft8": gdjs.Level1Code.GDGoLeft8Objects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom8Objects3Objects = Hashtable.newFrom({"Mushroom8": gdjs.Level1Code.GDMushroom8Objects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDGoRight8Objects3Objects = Hashtable.newFrom({"GoRight8": gdjs.Level1Code.GDGoRight8Objects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDHeadDMG8Objects3Objects = Hashtable.newFrom({"HeadDMG8": gdjs.Level1Code.GDHeadDMG8Objects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Level1Code.GDPlayerObjects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom8Objects3Objects = Hashtable.newFrom({"Mushroom8": gdjs.Level1Code.GDMushroom8Objects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Level1Code.GDPlayerObjects3});
gdjs.Level1Code.asyncCallback17128492 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects6);

{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects6.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects6[i].setOpacity(255);
}
}}
gdjs.Level1Code.eventsList53 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.Level1Code.GDPlayerObjects5) asyncObjectsList.addObject("Player", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Level1Code.asyncCallback17128492(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level1Code.asyncCallback17128212 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects5);

{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects5.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects5[i].setOpacity(100);
}
}
{ //Subevents
gdjs.Level1Code.eventsList53(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Level1Code.eventsList54 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.Level1Code.GDPlayerObjects4) asyncObjectsList.addObject("Player", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Level1Code.asyncCallback17128212(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level1Code.asyncCallback17127916 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects4);

{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects4[i].setOpacity(255);
}
}
{ //Subevents
gdjs.Level1Code.eventsList54(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Level1Code.eventsList55 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Level1Code.GDPlayerObjects3) asyncObjectsList.addObject("Player", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Level1Code.asyncCallback17127916(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level1Code.eventsList56 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("GoLeft8"), gdjs.Level1Code.GDGoLeft8Objects3);
gdjs.copyArray(runtimeScene.getObjects("GoRight8"), gdjs.Level1Code.GDGoRight8Objects3);
gdjs.copyArray(runtimeScene.getObjects("HeadDMG8"), gdjs.Level1Code.GDHeadDMG8Objects3);
{for(var i = 0, len = gdjs.Level1Code.GDGoLeft8Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDGoLeft8Objects3[i].setOpacity(0);
}
}{for(var i = 0, len = gdjs.Level1Code.GDGoRight8Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDGoRight8Objects3[i].setOpacity(0);
}
}{for(var i = 0, len = gdjs.Level1Code.GDHeadDMG8Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDHeadDMG8Objects3[i].setOpacity(0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("GoLeft8"), gdjs.Level1Code.GDGoLeft8Objects3);
gdjs.copyArray(runtimeScene.getObjects("Mushroom8"), gdjs.Level1Code.GDMushroom8Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom8Objects3Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDGoLeft8Objects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17122564);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDMushroom8Objects3 */
{for(var i = 0, len = gdjs.Level1Code.GDMushroom8Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDMushroom8Objects3[i].returnVariable(gdjs.Level1Code.GDMushroom8Objects3[i].getVariables().getFromIndex(0)).setNumber(0);
}
}{for(var i = 0, len = gdjs.Level1Code.GDMushroom8Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDMushroom8Objects3[i].flipX(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("GoRight8"), gdjs.Level1Code.GDGoRight8Objects3);
gdjs.copyArray(runtimeScene.getObjects("Mushroom8"), gdjs.Level1Code.GDMushroom8Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom8Objects3Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDGoRight8Objects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17123564);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDMushroom8Objects3 */
{for(var i = 0, len = gdjs.Level1Code.GDMushroom8Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDMushroom8Objects3[i].returnVariable(gdjs.Level1Code.GDMushroom8Objects3[i].getVariables().getFromIndex(0)).setNumber(1);
}
}{for(var i = 0, len = gdjs.Level1Code.GDMushroom8Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDMushroom8Objects3[i].flipX(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Mushroom8"), gdjs.Level1Code.GDMushroom8Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDMushroom8Objects3.length;i<l;++i) {
    if ( gdjs.Level1Code.GDMushroom8Objects3[i].getVariableNumber(gdjs.Level1Code.GDMushroom8Objects3[i].getVariables().getFromIndex(0)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDMushroom8Objects3[k] = gdjs.Level1Code.GDMushroom8Objects3[i];
        ++k;
    }
}
gdjs.Level1Code.GDMushroom8Objects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("GoRight8"), gdjs.Level1Code.GDGoRight8Objects3);
/* Reuse gdjs.Level1Code.GDMushroom8Objects3 */
{for(var i = 0, len = gdjs.Level1Code.GDMushroom8Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDMushroom8Objects3[i].addForceTowardObject((gdjs.Level1Code.GDGoRight8Objects3.length !== 0 ? gdjs.Level1Code.GDGoRight8Objects3[0] : null), 100, 0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Mushroom8"), gdjs.Level1Code.GDMushroom8Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDMushroom8Objects3.length;i<l;++i) {
    if ( gdjs.Level1Code.GDMushroom8Objects3[i].getVariableNumber(gdjs.Level1Code.GDMushroom8Objects3[i].getVariables().getFromIndex(0)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDMushroom8Objects3[k] = gdjs.Level1Code.GDMushroom8Objects3[i];
        ++k;
    }
}
gdjs.Level1Code.GDMushroom8Objects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("GoLeft8"), gdjs.Level1Code.GDGoLeft8Objects3);
/* Reuse gdjs.Level1Code.GDMushroom8Objects3 */
{for(var i = 0, len = gdjs.Level1Code.GDMushroom8Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDMushroom8Objects3[i].addForceTowardObject((gdjs.Level1Code.GDGoLeft8Objects3.length !== 0 ? gdjs.Level1Code.GDGoLeft8Objects3[0] : null), 100, 0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("HeadDMG8"), gdjs.Level1Code.GDHeadDMG8Objects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDHeadDMG8Objects3Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDHeadDMG8Objects3 */
gdjs.copyArray(runtimeScene.getObjects("Mushroom8"), gdjs.Level1Code.GDMushroom8Objects3);
/* Reuse gdjs.Level1Code.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.Level1Code.GDHeadDMG8Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDHeadDMG8Objects3[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDMushroom8Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDMushroom8Objects3[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getScene().getVariables().getFromIndex(0).add(100);
}{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects3[i].getBehavior("PlatformerObject").setCanJump();
}
}{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects3[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Mushroom8"), gdjs.Level1Code.GDMushroom8Objects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom8Objects3Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17127636);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects3[i].setOpacity(100);
}
}
{ //Subevents
gdjs.Level1Code.eventsList55(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("HeadDMG8"), gdjs.Level1Code.GDHeadDMG8Objects2);
gdjs.copyArray(runtimeScene.getObjects("Mushroom8"), gdjs.Level1Code.GDMushroom8Objects2);
{for(var i = 0, len = gdjs.Level1Code.GDHeadDMG8Objects2.length ;i < len;++i) {
    gdjs.Level1Code.GDHeadDMG8Objects2[i].setPosition((( gdjs.Level1Code.GDMushroom8Objects2.length === 0 ) ? 0 :gdjs.Level1Code.GDMushroom8Objects2[0].getPointX("")),(( gdjs.Level1Code.GDMushroom8Objects2.length === 0 ) ? 0 :gdjs.Level1Code.GDMushroom8Objects2[0].getPointY("")) - 5);
}
}}

}


};gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom9Objects3Objects = Hashtable.newFrom({"Mushroom9": gdjs.Level1Code.GDMushroom9Objects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDGoLeft9Objects3Objects = Hashtable.newFrom({"GoLeft9": gdjs.Level1Code.GDGoLeft9Objects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom9Objects3Objects = Hashtable.newFrom({"Mushroom9": gdjs.Level1Code.GDMushroom9Objects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDGoRight9Objects3Objects = Hashtable.newFrom({"GoRight9": gdjs.Level1Code.GDGoRight9Objects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDHeadDMG9Objects3Objects = Hashtable.newFrom({"HeadDMG9": gdjs.Level1Code.GDHeadDMG9Objects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Level1Code.GDPlayerObjects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom9Objects3Objects = Hashtable.newFrom({"Mushroom9": gdjs.Level1Code.GDMushroom9Objects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Level1Code.GDPlayerObjects3});
gdjs.Level1Code.asyncCallback17136708 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects6);

{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects6.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects6[i].setOpacity(255);
}
}}
gdjs.Level1Code.eventsList57 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.Level1Code.GDPlayerObjects5) asyncObjectsList.addObject("Player", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Level1Code.asyncCallback17136708(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level1Code.asyncCallback17136428 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects5);

{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects5.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects5[i].setOpacity(100);
}
}
{ //Subevents
gdjs.Level1Code.eventsList57(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Level1Code.eventsList58 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.Level1Code.GDPlayerObjects4) asyncObjectsList.addObject("Player", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Level1Code.asyncCallback17136428(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level1Code.asyncCallback17136132 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects4);

{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects4[i].setOpacity(255);
}
}
{ //Subevents
gdjs.Level1Code.eventsList58(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Level1Code.eventsList59 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Level1Code.GDPlayerObjects3) asyncObjectsList.addObject("Player", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Level1Code.asyncCallback17136132(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level1Code.eventsList60 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("GoLeft9"), gdjs.Level1Code.GDGoLeft9Objects3);
gdjs.copyArray(runtimeScene.getObjects("GoRight9"), gdjs.Level1Code.GDGoRight9Objects3);
gdjs.copyArray(runtimeScene.getObjects("HeadDMG9"), gdjs.Level1Code.GDHeadDMG9Objects3);
{for(var i = 0, len = gdjs.Level1Code.GDGoLeft9Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDGoLeft9Objects3[i].setOpacity(0);
}
}{for(var i = 0, len = gdjs.Level1Code.GDGoRight9Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDGoRight9Objects3[i].setOpacity(0);
}
}{for(var i = 0, len = gdjs.Level1Code.GDHeadDMG9Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDHeadDMG9Objects3[i].setOpacity(0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("GoLeft9"), gdjs.Level1Code.GDGoLeft9Objects3);
gdjs.copyArray(runtimeScene.getObjects("Mushroom9"), gdjs.Level1Code.GDMushroom9Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom9Objects3Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDGoLeft9Objects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17130780);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDMushroom9Objects3 */
{for(var i = 0, len = gdjs.Level1Code.GDMushroom9Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDMushroom9Objects3[i].returnVariable(gdjs.Level1Code.GDMushroom9Objects3[i].getVariables().getFromIndex(0)).setNumber(0);
}
}{for(var i = 0, len = gdjs.Level1Code.GDMushroom9Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDMushroom9Objects3[i].flipX(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("GoRight9"), gdjs.Level1Code.GDGoRight9Objects3);
gdjs.copyArray(runtimeScene.getObjects("Mushroom9"), gdjs.Level1Code.GDMushroom9Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom9Objects3Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDGoRight9Objects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17131780);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDMushroom9Objects3 */
{for(var i = 0, len = gdjs.Level1Code.GDMushroom9Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDMushroom9Objects3[i].returnVariable(gdjs.Level1Code.GDMushroom9Objects3[i].getVariables().getFromIndex(0)).setNumber(1);
}
}{for(var i = 0, len = gdjs.Level1Code.GDMushroom9Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDMushroom9Objects3[i].flipX(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Mushroom9"), gdjs.Level1Code.GDMushroom9Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDMushroom9Objects3.length;i<l;++i) {
    if ( gdjs.Level1Code.GDMushroom9Objects3[i].getVariableNumber(gdjs.Level1Code.GDMushroom9Objects3[i].getVariables().getFromIndex(0)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDMushroom9Objects3[k] = gdjs.Level1Code.GDMushroom9Objects3[i];
        ++k;
    }
}
gdjs.Level1Code.GDMushroom9Objects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("GoRight9"), gdjs.Level1Code.GDGoRight9Objects3);
/* Reuse gdjs.Level1Code.GDMushroom9Objects3 */
{for(var i = 0, len = gdjs.Level1Code.GDMushroom9Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDMushroom9Objects3[i].addForceTowardObject((gdjs.Level1Code.GDGoRight9Objects3.length !== 0 ? gdjs.Level1Code.GDGoRight9Objects3[0] : null), 100, 0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Mushroom9"), gdjs.Level1Code.GDMushroom9Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDMushroom9Objects3.length;i<l;++i) {
    if ( gdjs.Level1Code.GDMushroom9Objects3[i].getVariableNumber(gdjs.Level1Code.GDMushroom9Objects3[i].getVariables().getFromIndex(0)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDMushroom9Objects3[k] = gdjs.Level1Code.GDMushroom9Objects3[i];
        ++k;
    }
}
gdjs.Level1Code.GDMushroom9Objects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("GoLeft9"), gdjs.Level1Code.GDGoLeft9Objects3);
/* Reuse gdjs.Level1Code.GDMushroom9Objects3 */
{for(var i = 0, len = gdjs.Level1Code.GDMushroom9Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDMushroom9Objects3[i].addForceTowardObject((gdjs.Level1Code.GDGoLeft9Objects3.length !== 0 ? gdjs.Level1Code.GDGoLeft9Objects3[0] : null), 100, 0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("HeadDMG9"), gdjs.Level1Code.GDHeadDMG9Objects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDHeadDMG9Objects3Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDHeadDMG9Objects3 */
gdjs.copyArray(runtimeScene.getObjects("Mushroom9"), gdjs.Level1Code.GDMushroom9Objects3);
/* Reuse gdjs.Level1Code.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.Level1Code.GDHeadDMG9Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDHeadDMG9Objects3[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDMushroom9Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDMushroom9Objects3[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getScene().getVariables().getFromIndex(0).add(100);
}{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects3[i].getBehavior("PlatformerObject").setCanJump();
}
}{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects3[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Mushroom9"), gdjs.Level1Code.GDMushroom9Objects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom9Objects3Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17135852);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects3[i].setOpacity(100);
}
}
{ //Subevents
gdjs.Level1Code.eventsList59(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("HeadDMG9"), gdjs.Level1Code.GDHeadDMG9Objects2);
gdjs.copyArray(runtimeScene.getObjects("Mushroom9"), gdjs.Level1Code.GDMushroom9Objects2);
{for(var i = 0, len = gdjs.Level1Code.GDHeadDMG9Objects2.length ;i < len;++i) {
    gdjs.Level1Code.GDHeadDMG9Objects2[i].setPosition((( gdjs.Level1Code.GDMushroom9Objects2.length === 0 ) ? 0 :gdjs.Level1Code.GDMushroom9Objects2[0].getPointX("")),(( gdjs.Level1Code.GDMushroom9Objects2.length === 0 ) ? 0 :gdjs.Level1Code.GDMushroom9Objects2[0].getPointY("")) - 5);
}
}}

}


};gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom10Objects3Objects = Hashtable.newFrom({"Mushroom10": gdjs.Level1Code.GDMushroom10Objects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDGoLeft10Objects3Objects = Hashtable.newFrom({"GoLeft10": gdjs.Level1Code.GDGoLeft10Objects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom10Objects3Objects = Hashtable.newFrom({"Mushroom10": gdjs.Level1Code.GDMushroom10Objects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDGoRight10Objects3Objects = Hashtable.newFrom({"GoRight10": gdjs.Level1Code.GDGoRight10Objects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDHeadDMG10Objects3Objects = Hashtable.newFrom({"HeadDMG10": gdjs.Level1Code.GDHeadDMG10Objects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Level1Code.GDPlayerObjects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom10Objects3Objects = Hashtable.newFrom({"Mushroom10": gdjs.Level1Code.GDMushroom10Objects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Level1Code.GDPlayerObjects3});
gdjs.Level1Code.asyncCallback17144988 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects6);

{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects6.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects6[i].setOpacity(255);
}
}}
gdjs.Level1Code.eventsList61 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.Level1Code.GDPlayerObjects5) asyncObjectsList.addObject("Player", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Level1Code.asyncCallback17144988(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level1Code.asyncCallback17144708 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects5);

{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects5.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects5[i].setOpacity(100);
}
}
{ //Subevents
gdjs.Level1Code.eventsList61(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Level1Code.eventsList62 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.Level1Code.GDPlayerObjects4) asyncObjectsList.addObject("Player", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Level1Code.asyncCallback17144708(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level1Code.asyncCallback17144412 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects4);

{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects4[i].setOpacity(255);
}
}
{ //Subevents
gdjs.Level1Code.eventsList62(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Level1Code.eventsList63 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Level1Code.GDPlayerObjects3) asyncObjectsList.addObject("Player", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Level1Code.asyncCallback17144412(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level1Code.eventsList64 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("GoLeft10"), gdjs.Level1Code.GDGoLeft10Objects3);
gdjs.copyArray(runtimeScene.getObjects("GoRight10"), gdjs.Level1Code.GDGoRight10Objects3);
gdjs.copyArray(runtimeScene.getObjects("HeadDMG10"), gdjs.Level1Code.GDHeadDMG10Objects3);
{for(var i = 0, len = gdjs.Level1Code.GDGoLeft10Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDGoLeft10Objects3[i].setOpacity(0);
}
}{for(var i = 0, len = gdjs.Level1Code.GDGoRight10Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDGoRight10Objects3[i].setOpacity(0);
}
}{for(var i = 0, len = gdjs.Level1Code.GDHeadDMG10Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDHeadDMG10Objects3[i].setOpacity(0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("GoLeft10"), gdjs.Level1Code.GDGoLeft10Objects3);
gdjs.copyArray(runtimeScene.getObjects("Mushroom10"), gdjs.Level1Code.GDMushroom10Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom10Objects3Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDGoLeft10Objects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17139060);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDMushroom10Objects3 */
{for(var i = 0, len = gdjs.Level1Code.GDMushroom10Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDMushroom10Objects3[i].returnVariable(gdjs.Level1Code.GDMushroom10Objects3[i].getVariables().getFromIndex(0)).setNumber(0);
}
}{for(var i = 0, len = gdjs.Level1Code.GDMushroom10Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDMushroom10Objects3[i].flipX(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("GoRight10"), gdjs.Level1Code.GDGoRight10Objects3);
gdjs.copyArray(runtimeScene.getObjects("Mushroom10"), gdjs.Level1Code.GDMushroom10Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom10Objects3Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDGoRight10Objects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17140060);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDMushroom10Objects3 */
{for(var i = 0, len = gdjs.Level1Code.GDMushroom10Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDMushroom10Objects3[i].returnVariable(gdjs.Level1Code.GDMushroom10Objects3[i].getVariables().getFromIndex(0)).setNumber(1);
}
}{for(var i = 0, len = gdjs.Level1Code.GDMushroom10Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDMushroom10Objects3[i].flipX(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Mushroom10"), gdjs.Level1Code.GDMushroom10Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDMushroom10Objects3.length;i<l;++i) {
    if ( gdjs.Level1Code.GDMushroom10Objects3[i].getVariableNumber(gdjs.Level1Code.GDMushroom10Objects3[i].getVariables().getFromIndex(0)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDMushroom10Objects3[k] = gdjs.Level1Code.GDMushroom10Objects3[i];
        ++k;
    }
}
gdjs.Level1Code.GDMushroom10Objects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("GoRight10"), gdjs.Level1Code.GDGoRight10Objects3);
/* Reuse gdjs.Level1Code.GDMushroom10Objects3 */
{for(var i = 0, len = gdjs.Level1Code.GDMushroom10Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDMushroom10Objects3[i].addForceTowardObject((gdjs.Level1Code.GDGoRight10Objects3.length !== 0 ? gdjs.Level1Code.GDGoRight10Objects3[0] : null), 100, 0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Mushroom10"), gdjs.Level1Code.GDMushroom10Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDMushroom10Objects3.length;i<l;++i) {
    if ( gdjs.Level1Code.GDMushroom10Objects3[i].getVariableNumber(gdjs.Level1Code.GDMushroom10Objects3[i].getVariables().getFromIndex(0)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDMushroom10Objects3[k] = gdjs.Level1Code.GDMushroom10Objects3[i];
        ++k;
    }
}
gdjs.Level1Code.GDMushroom10Objects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("GoLeft10"), gdjs.Level1Code.GDGoLeft10Objects3);
/* Reuse gdjs.Level1Code.GDMushroom10Objects3 */
{for(var i = 0, len = gdjs.Level1Code.GDMushroom10Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDMushroom10Objects3[i].addForceTowardObject((gdjs.Level1Code.GDGoLeft10Objects3.length !== 0 ? gdjs.Level1Code.GDGoLeft10Objects3[0] : null), 100, 0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("HeadDMG10"), gdjs.Level1Code.GDHeadDMG10Objects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDHeadDMG10Objects3Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDHeadDMG10Objects3 */
gdjs.copyArray(runtimeScene.getObjects("Mushroom10"), gdjs.Level1Code.GDMushroom10Objects3);
/* Reuse gdjs.Level1Code.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.Level1Code.GDHeadDMG10Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDHeadDMG10Objects3[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDMushroom10Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDMushroom10Objects3[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getScene().getVariables().getFromIndex(0).add(100);
}{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects3[i].getBehavior("PlatformerObject").setCanJump();
}
}{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects3[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Mushroom10"), gdjs.Level1Code.GDMushroom10Objects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom10Objects3Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17144132);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects3[i].setOpacity(100);
}
}
{ //Subevents
gdjs.Level1Code.eventsList63(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("HeadDMG10"), gdjs.Level1Code.GDHeadDMG10Objects2);
gdjs.copyArray(runtimeScene.getObjects("Mushroom10"), gdjs.Level1Code.GDMushroom10Objects2);
{for(var i = 0, len = gdjs.Level1Code.GDHeadDMG10Objects2.length ;i < len;++i) {
    gdjs.Level1Code.GDHeadDMG10Objects2[i].setPosition((( gdjs.Level1Code.GDMushroom10Objects2.length === 0 ) ? 0 :gdjs.Level1Code.GDMushroom10Objects2[0].getPointX("")),(( gdjs.Level1Code.GDMushroom10Objects2.length === 0 ) ? 0 :gdjs.Level1Code.GDMushroom10Objects2[0].getPointY("")) - 5);
}
}}

}


};gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom11Objects3Objects = Hashtable.newFrom({"Mushroom11": gdjs.Level1Code.GDMushroom11Objects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDGoLeft11Objects3Objects = Hashtable.newFrom({"GoLeft11": gdjs.Level1Code.GDGoLeft11Objects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom11Objects3Objects = Hashtable.newFrom({"Mushroom11": gdjs.Level1Code.GDMushroom11Objects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDGoRight11Objects3Objects = Hashtable.newFrom({"GoRight11": gdjs.Level1Code.GDGoRight11Objects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDHeadDMG11Objects3Objects = Hashtable.newFrom({"HeadDMG11": gdjs.Level1Code.GDHeadDMG11Objects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Level1Code.GDPlayerObjects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom11Objects3Objects = Hashtable.newFrom({"Mushroom11": gdjs.Level1Code.GDMushroom11Objects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Level1Code.GDPlayerObjects3});
gdjs.Level1Code.asyncCallback17153308 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects6);

{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects6.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects6[i].setOpacity(255);
}
}}
gdjs.Level1Code.eventsList65 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.Level1Code.GDPlayerObjects5) asyncObjectsList.addObject("Player", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Level1Code.asyncCallback17153308(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level1Code.asyncCallback17153028 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects5);

{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects5.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects5[i].setOpacity(100);
}
}
{ //Subevents
gdjs.Level1Code.eventsList65(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Level1Code.eventsList66 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.Level1Code.GDPlayerObjects4) asyncObjectsList.addObject("Player", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Level1Code.asyncCallback17153028(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level1Code.asyncCallback17152732 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects4);

{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects4[i].setOpacity(255);
}
}
{ //Subevents
gdjs.Level1Code.eventsList66(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Level1Code.eventsList67 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Level1Code.GDPlayerObjects3) asyncObjectsList.addObject("Player", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Level1Code.asyncCallback17152732(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level1Code.eventsList68 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("GoLeft11"), gdjs.Level1Code.GDGoLeft11Objects3);
gdjs.copyArray(runtimeScene.getObjects("GoRight11"), gdjs.Level1Code.GDGoRight11Objects3);
gdjs.copyArray(runtimeScene.getObjects("HeadDMG11"), gdjs.Level1Code.GDHeadDMG11Objects3);
{for(var i = 0, len = gdjs.Level1Code.GDGoLeft11Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDGoLeft11Objects3[i].setOpacity(0);
}
}{for(var i = 0, len = gdjs.Level1Code.GDGoRight11Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDGoRight11Objects3[i].setOpacity(0);
}
}{for(var i = 0, len = gdjs.Level1Code.GDHeadDMG11Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDHeadDMG11Objects3[i].setOpacity(0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("GoLeft11"), gdjs.Level1Code.GDGoLeft11Objects3);
gdjs.copyArray(runtimeScene.getObjects("Mushroom11"), gdjs.Level1Code.GDMushroom11Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom11Objects3Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDGoLeft11Objects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17147380);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDMushroom11Objects3 */
{for(var i = 0, len = gdjs.Level1Code.GDMushroom11Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDMushroom11Objects3[i].returnVariable(gdjs.Level1Code.GDMushroom11Objects3[i].getVariables().getFromIndex(0)).setNumber(0);
}
}{for(var i = 0, len = gdjs.Level1Code.GDMushroom11Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDMushroom11Objects3[i].flipX(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("GoRight11"), gdjs.Level1Code.GDGoRight11Objects3);
gdjs.copyArray(runtimeScene.getObjects("Mushroom11"), gdjs.Level1Code.GDMushroom11Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom11Objects3Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDGoRight11Objects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17148380);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDMushroom11Objects3 */
{for(var i = 0, len = gdjs.Level1Code.GDMushroom11Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDMushroom11Objects3[i].returnVariable(gdjs.Level1Code.GDMushroom11Objects3[i].getVariables().getFromIndex(0)).setNumber(1);
}
}{for(var i = 0, len = gdjs.Level1Code.GDMushroom11Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDMushroom11Objects3[i].flipX(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Mushroom11"), gdjs.Level1Code.GDMushroom11Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDMushroom11Objects3.length;i<l;++i) {
    if ( gdjs.Level1Code.GDMushroom11Objects3[i].getVariableNumber(gdjs.Level1Code.GDMushroom11Objects3[i].getVariables().getFromIndex(0)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDMushroom11Objects3[k] = gdjs.Level1Code.GDMushroom11Objects3[i];
        ++k;
    }
}
gdjs.Level1Code.GDMushroom11Objects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("GoRight11"), gdjs.Level1Code.GDGoRight11Objects3);
/* Reuse gdjs.Level1Code.GDMushroom11Objects3 */
{for(var i = 0, len = gdjs.Level1Code.GDMushroom11Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDMushroom11Objects3[i].addForceTowardObject((gdjs.Level1Code.GDGoRight11Objects3.length !== 0 ? gdjs.Level1Code.GDGoRight11Objects3[0] : null), 100, 0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Mushroom11"), gdjs.Level1Code.GDMushroom11Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDMushroom11Objects3.length;i<l;++i) {
    if ( gdjs.Level1Code.GDMushroom11Objects3[i].getVariableNumber(gdjs.Level1Code.GDMushroom11Objects3[i].getVariables().getFromIndex(0)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDMushroom11Objects3[k] = gdjs.Level1Code.GDMushroom11Objects3[i];
        ++k;
    }
}
gdjs.Level1Code.GDMushroom11Objects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("GoLeft11"), gdjs.Level1Code.GDGoLeft11Objects3);
/* Reuse gdjs.Level1Code.GDMushroom11Objects3 */
{for(var i = 0, len = gdjs.Level1Code.GDMushroom11Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDMushroom11Objects3[i].addForceTowardObject((gdjs.Level1Code.GDGoLeft11Objects3.length !== 0 ? gdjs.Level1Code.GDGoLeft11Objects3[0] : null), 100, 0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("HeadDMG11"), gdjs.Level1Code.GDHeadDMG11Objects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDHeadDMG11Objects3Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDHeadDMG11Objects3 */
gdjs.copyArray(runtimeScene.getObjects("Mushroom11"), gdjs.Level1Code.GDMushroom11Objects3);
/* Reuse gdjs.Level1Code.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.Level1Code.GDHeadDMG11Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDHeadDMG11Objects3[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDMushroom11Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDMushroom11Objects3[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getScene().getVariables().getFromIndex(0).add(100);
}{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects3[i].getBehavior("PlatformerObject").setCanJump();
}
}{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects3[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Mushroom11"), gdjs.Level1Code.GDMushroom11Objects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom11Objects3Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17152452);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects3[i].setOpacity(100);
}
}
{ //Subevents
gdjs.Level1Code.eventsList67(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("HeadDMG11"), gdjs.Level1Code.GDHeadDMG11Objects2);
gdjs.copyArray(runtimeScene.getObjects("Mushroom11"), gdjs.Level1Code.GDMushroom11Objects2);
{for(var i = 0, len = gdjs.Level1Code.GDHeadDMG11Objects2.length ;i < len;++i) {
    gdjs.Level1Code.GDHeadDMG11Objects2[i].setPosition((( gdjs.Level1Code.GDMushroom11Objects2.length === 0 ) ? 0 :gdjs.Level1Code.GDMushroom11Objects2[0].getPointX("")),(( gdjs.Level1Code.GDMushroom11Objects2.length === 0 ) ? 0 :gdjs.Level1Code.GDMushroom11Objects2[0].getPointY("")) - 5);
}
}}

}


};gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom12Objects3Objects = Hashtable.newFrom({"Mushroom12": gdjs.Level1Code.GDMushroom12Objects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDGoLeft12Objects3Objects = Hashtable.newFrom({"GoLeft12": gdjs.Level1Code.GDGoLeft12Objects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom12Objects3Objects = Hashtable.newFrom({"Mushroom12": gdjs.Level1Code.GDMushroom12Objects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDGoRight12Objects3Objects = Hashtable.newFrom({"GoRight12": gdjs.Level1Code.GDGoRight12Objects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDHeadDMG12Objects3Objects = Hashtable.newFrom({"HeadDMG12": gdjs.Level1Code.GDHeadDMG12Objects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Level1Code.GDPlayerObjects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom12Objects3Objects = Hashtable.newFrom({"Mushroom12": gdjs.Level1Code.GDMushroom12Objects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Level1Code.GDPlayerObjects3});
gdjs.Level1Code.asyncCallback17161628 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects6);

{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects6.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects6[i].setOpacity(255);
}
}}
gdjs.Level1Code.eventsList69 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.Level1Code.GDPlayerObjects5) asyncObjectsList.addObject("Player", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Level1Code.asyncCallback17161628(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level1Code.asyncCallback17161348 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects5);

{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects5.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects5[i].setOpacity(100);
}
}
{ //Subevents
gdjs.Level1Code.eventsList69(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Level1Code.eventsList70 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.Level1Code.GDPlayerObjects4) asyncObjectsList.addObject("Player", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Level1Code.asyncCallback17161348(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level1Code.asyncCallback17161052 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects4);

{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects4[i].setOpacity(255);
}
}
{ //Subevents
gdjs.Level1Code.eventsList70(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Level1Code.eventsList71 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Level1Code.GDPlayerObjects3) asyncObjectsList.addObject("Player", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Level1Code.asyncCallback17161052(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level1Code.eventsList72 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("GoLeft12"), gdjs.Level1Code.GDGoLeft12Objects3);
gdjs.copyArray(runtimeScene.getObjects("GoRight12"), gdjs.Level1Code.GDGoRight12Objects3);
gdjs.copyArray(runtimeScene.getObjects("HeadDMG12"), gdjs.Level1Code.GDHeadDMG12Objects3);
{for(var i = 0, len = gdjs.Level1Code.GDGoLeft12Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDGoLeft12Objects3[i].setOpacity(0);
}
}{for(var i = 0, len = gdjs.Level1Code.GDGoRight12Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDGoRight12Objects3[i].setOpacity(0);
}
}{for(var i = 0, len = gdjs.Level1Code.GDHeadDMG12Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDHeadDMG12Objects3[i].setOpacity(0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("GoLeft12"), gdjs.Level1Code.GDGoLeft12Objects3);
gdjs.copyArray(runtimeScene.getObjects("Mushroom12"), gdjs.Level1Code.GDMushroom12Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom12Objects3Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDGoLeft12Objects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17155700);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDMushroom12Objects3 */
{for(var i = 0, len = gdjs.Level1Code.GDMushroom12Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDMushroom12Objects3[i].returnVariable(gdjs.Level1Code.GDMushroom12Objects3[i].getVariables().getFromIndex(0)).setNumber(0);
}
}{for(var i = 0, len = gdjs.Level1Code.GDMushroom12Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDMushroom12Objects3[i].flipX(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("GoRight12"), gdjs.Level1Code.GDGoRight12Objects3);
gdjs.copyArray(runtimeScene.getObjects("Mushroom12"), gdjs.Level1Code.GDMushroom12Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom12Objects3Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDGoRight12Objects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17156700);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDMushroom12Objects3 */
{for(var i = 0, len = gdjs.Level1Code.GDMushroom12Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDMushroom12Objects3[i].returnVariable(gdjs.Level1Code.GDMushroom12Objects3[i].getVariables().getFromIndex(0)).setNumber(1);
}
}{for(var i = 0, len = gdjs.Level1Code.GDMushroom12Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDMushroom12Objects3[i].flipX(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Mushroom12"), gdjs.Level1Code.GDMushroom12Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDMushroom12Objects3.length;i<l;++i) {
    if ( gdjs.Level1Code.GDMushroom12Objects3[i].getVariableNumber(gdjs.Level1Code.GDMushroom12Objects3[i].getVariables().getFromIndex(0)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDMushroom12Objects3[k] = gdjs.Level1Code.GDMushroom12Objects3[i];
        ++k;
    }
}
gdjs.Level1Code.GDMushroom12Objects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("GoRight12"), gdjs.Level1Code.GDGoRight12Objects3);
/* Reuse gdjs.Level1Code.GDMushroom12Objects3 */
{for(var i = 0, len = gdjs.Level1Code.GDMushroom12Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDMushroom12Objects3[i].addForceTowardObject((gdjs.Level1Code.GDGoRight12Objects3.length !== 0 ? gdjs.Level1Code.GDGoRight12Objects3[0] : null), 100, 0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Mushroom12"), gdjs.Level1Code.GDMushroom12Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDMushroom12Objects3.length;i<l;++i) {
    if ( gdjs.Level1Code.GDMushroom12Objects3[i].getVariableNumber(gdjs.Level1Code.GDMushroom12Objects3[i].getVariables().getFromIndex(0)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDMushroom12Objects3[k] = gdjs.Level1Code.GDMushroom12Objects3[i];
        ++k;
    }
}
gdjs.Level1Code.GDMushroom12Objects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("GoLeft12"), gdjs.Level1Code.GDGoLeft12Objects3);
/* Reuse gdjs.Level1Code.GDMushroom12Objects3 */
{for(var i = 0, len = gdjs.Level1Code.GDMushroom12Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDMushroom12Objects3[i].addForceTowardObject((gdjs.Level1Code.GDGoLeft12Objects3.length !== 0 ? gdjs.Level1Code.GDGoLeft12Objects3[0] : null), 100, 0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("HeadDMG12"), gdjs.Level1Code.GDHeadDMG12Objects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDHeadDMG12Objects3Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDHeadDMG12Objects3 */
gdjs.copyArray(runtimeScene.getObjects("Mushroom12"), gdjs.Level1Code.GDMushroom12Objects3);
/* Reuse gdjs.Level1Code.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.Level1Code.GDHeadDMG12Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDHeadDMG12Objects3[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDMushroom12Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDMushroom12Objects3[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getScene().getVariables().getFromIndex(0).add(100);
}{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects3[i].getBehavior("PlatformerObject").setCanJump();
}
}{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects3[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Mushroom12"), gdjs.Level1Code.GDMushroom12Objects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom12Objects3Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17160772);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects3[i].setOpacity(100);
}
}
{ //Subevents
gdjs.Level1Code.eventsList71(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("HeadDMG12"), gdjs.Level1Code.GDHeadDMG12Objects2);
gdjs.copyArray(runtimeScene.getObjects("Mushroom12"), gdjs.Level1Code.GDMushroom12Objects2);
{for(var i = 0, len = gdjs.Level1Code.GDHeadDMG12Objects2.length ;i < len;++i) {
    gdjs.Level1Code.GDHeadDMG12Objects2[i].setPosition((( gdjs.Level1Code.GDMushroom12Objects2.length === 0 ) ? 0 :gdjs.Level1Code.GDMushroom12Objects2[0].getPointX("")),(( gdjs.Level1Code.GDMushroom12Objects2.length === 0 ) ? 0 :gdjs.Level1Code.GDMushroom12Objects2[0].getPointY("")) - 5);
}
}}

}


};gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level1Code.GDPlayerObjects2});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom1Objects2Objects = Hashtable.newFrom({"Mushroom1": gdjs.Level1Code.GDMushroom1Objects2});
gdjs.Level1Code.asyncCallback17164356 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(7), false);
}}
gdjs.Level1Code.eventsList73 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(3), (runtimeScene) => (gdjs.Level1Code.asyncCallback17164356(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level1Code.eventsList74 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Level1Code.GDPlayerObjects2, gdjs.Level1Code.GDPlayerObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.Level1Code.GDPlayerObjects3[i].getScaleY() == 0.8 ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDPlayerObjects3[k] = gdjs.Level1Code.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Level1Code.GDPlayerObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17163964);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects3[i].setScale(0.6);
}
}
{ //Subevents
gdjs.Level1Code.eventsList73(runtimeScene);} //End of subevents
}

}


{

/* Reuse gdjs.Level1Code.GDPlayerObjects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level1Code.GDPlayerObjects2[i].getScaleY() < 0.8 ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDPlayerObjects2[k] = gdjs.Level1Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDPlayerObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(7), false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17165492);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(5), false);
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.variable.toggleVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(5));
}}

}


};gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level1Code.GDPlayerObjects2});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom2Objects2Objects = Hashtable.newFrom({"Mushroom2": gdjs.Level1Code.GDMushroom2Objects2});
gdjs.Level1Code.asyncCallback17167660 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(7), false);
}}
gdjs.Level1Code.eventsList75 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(3), (runtimeScene) => (gdjs.Level1Code.asyncCallback17167660(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level1Code.eventsList76 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Level1Code.GDPlayerObjects2, gdjs.Level1Code.GDPlayerObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.Level1Code.GDPlayerObjects3[i].getScaleY() == 0.8 ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDPlayerObjects3[k] = gdjs.Level1Code.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Level1Code.GDPlayerObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17167268);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects3[i].setScale(0.6);
}
}
{ //Subevents
gdjs.Level1Code.eventsList75(runtimeScene);} //End of subevents
}

}


{

/* Reuse gdjs.Level1Code.GDPlayerObjects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level1Code.GDPlayerObjects2[i].getScaleY() < 0.8 ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDPlayerObjects2[k] = gdjs.Level1Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDPlayerObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(7), false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(5), false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17168596);
}
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.variable.toggleVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(5));
}}

}


};gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level1Code.GDPlayerObjects2});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom3Objects2Objects = Hashtable.newFrom({"Mushroom3": gdjs.Level1Code.GDMushroom3Objects2});
gdjs.Level1Code.asyncCallback17170852 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(7), false);
}}
gdjs.Level1Code.eventsList77 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(3), (runtimeScene) => (gdjs.Level1Code.asyncCallback17170852(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level1Code.eventsList78 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Level1Code.GDPlayerObjects2, gdjs.Level1Code.GDPlayerObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.Level1Code.GDPlayerObjects3[i].getScaleY() == 0.8 ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDPlayerObjects3[k] = gdjs.Level1Code.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Level1Code.GDPlayerObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17170460);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects3[i].setScale(0.6);
}
}
{ //Subevents
gdjs.Level1Code.eventsList77(runtimeScene);} //End of subevents
}

}


{

/* Reuse gdjs.Level1Code.GDPlayerObjects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level1Code.GDPlayerObjects2[i].getScaleY() < 0.8 ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDPlayerObjects2[k] = gdjs.Level1Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDPlayerObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(7), false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17171988);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(5), false);
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.variable.toggleVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(5));
}}

}


};gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level1Code.GDPlayerObjects2});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom4Objects2Objects = Hashtable.newFrom({"Mushroom4": gdjs.Level1Code.GDMushroom4Objects2});
gdjs.Level1Code.asyncCallback17174092 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(7), false);
}}
gdjs.Level1Code.eventsList79 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(3), (runtimeScene) => (gdjs.Level1Code.asyncCallback17174092(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level1Code.eventsList80 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Level1Code.GDPlayerObjects2, gdjs.Level1Code.GDPlayerObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.Level1Code.GDPlayerObjects3[i].getScaleY() == 0.8 ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDPlayerObjects3[k] = gdjs.Level1Code.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Level1Code.GDPlayerObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17173700);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects3[i].setScale(0.6);
}
}
{ //Subevents
gdjs.Level1Code.eventsList79(runtimeScene);} //End of subevents
}

}


{

/* Reuse gdjs.Level1Code.GDPlayerObjects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level1Code.GDPlayerObjects2[i].getScaleY() < 0.8 ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDPlayerObjects2[k] = gdjs.Level1Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDPlayerObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(7), false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17175228);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(5), false);
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.variable.toggleVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(5));
}}

}


};gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level1Code.GDPlayerObjects2});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom5Objects2Objects = Hashtable.newFrom({"Mushroom5": gdjs.Level1Code.GDMushroom5Objects2});
gdjs.Level1Code.asyncCallback17177396 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(7), false);
}}
gdjs.Level1Code.eventsList81 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(3), (runtimeScene) => (gdjs.Level1Code.asyncCallback17177396(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level1Code.eventsList82 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Level1Code.GDPlayerObjects2, gdjs.Level1Code.GDPlayerObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.Level1Code.GDPlayerObjects3[i].getScaleY() == 0.8 ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDPlayerObjects3[k] = gdjs.Level1Code.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Level1Code.GDPlayerObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17177004);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects3[i].setScale(0.6);
}
}
{ //Subevents
gdjs.Level1Code.eventsList81(runtimeScene);} //End of subevents
}

}


{

/* Reuse gdjs.Level1Code.GDPlayerObjects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level1Code.GDPlayerObjects2[i].getScaleY() < 0.8 ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDPlayerObjects2[k] = gdjs.Level1Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDPlayerObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(7), false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17178532);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(5), false);
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.variable.toggleVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(5));
}}

}


};gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level1Code.GDPlayerObjects2});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom6Objects2Objects = Hashtable.newFrom({"Mushroom6": gdjs.Level1Code.GDMushroom6Objects2});
gdjs.Level1Code.asyncCallback17180644 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(7), false);
}}
gdjs.Level1Code.eventsList83 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(3), (runtimeScene) => (gdjs.Level1Code.asyncCallback17180644(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level1Code.eventsList84 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Level1Code.GDPlayerObjects2, gdjs.Level1Code.GDPlayerObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.Level1Code.GDPlayerObjects3[i].getScaleY() == 0.8 ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDPlayerObjects3[k] = gdjs.Level1Code.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Level1Code.GDPlayerObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17180252);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects3[i].setScale(0.6);
}
}
{ //Subevents
gdjs.Level1Code.eventsList83(runtimeScene);} //End of subevents
}

}


{

/* Reuse gdjs.Level1Code.GDPlayerObjects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level1Code.GDPlayerObjects2[i].getScaleY() < 0.8 ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDPlayerObjects2[k] = gdjs.Level1Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDPlayerObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(7), false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17181780);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(5), false);
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.variable.toggleVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(5));
}}

}


};gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level1Code.GDPlayerObjects2});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom7Objects2Objects = Hashtable.newFrom({"Mushroom7": gdjs.Level1Code.GDMushroom7Objects2});
gdjs.Level1Code.asyncCallback17183948 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(7), false);
}}
gdjs.Level1Code.eventsList85 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(3), (runtimeScene) => (gdjs.Level1Code.asyncCallback17183948(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level1Code.eventsList86 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Level1Code.GDPlayerObjects2, gdjs.Level1Code.GDPlayerObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.Level1Code.GDPlayerObjects3[i].getScaleY() == 0.8 ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDPlayerObjects3[k] = gdjs.Level1Code.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Level1Code.GDPlayerObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17183556);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects3[i].setScale(0.6);
}
}
{ //Subevents
gdjs.Level1Code.eventsList85(runtimeScene);} //End of subevents
}

}


{

/* Reuse gdjs.Level1Code.GDPlayerObjects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level1Code.GDPlayerObjects2[i].getScaleY() < 0.8 ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDPlayerObjects2[k] = gdjs.Level1Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDPlayerObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(7), false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17185084);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(5), false);
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.variable.toggleVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(5));
}}

}


};gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level1Code.GDPlayerObjects2});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom8Objects2Objects = Hashtable.newFrom({"Mushroom8": gdjs.Level1Code.GDMushroom8Objects2});
gdjs.Level1Code.asyncCallback17187252 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(7), false);
}}
gdjs.Level1Code.eventsList87 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(3), (runtimeScene) => (gdjs.Level1Code.asyncCallback17187252(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level1Code.eventsList88 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Level1Code.GDPlayerObjects2, gdjs.Level1Code.GDPlayerObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.Level1Code.GDPlayerObjects3[i].getScaleY() == 0.8 ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDPlayerObjects3[k] = gdjs.Level1Code.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Level1Code.GDPlayerObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17186860);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects3[i].setScale(0.6);
}
}
{ //Subevents
gdjs.Level1Code.eventsList87(runtimeScene);} //End of subevents
}

}


{

/* Reuse gdjs.Level1Code.GDPlayerObjects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level1Code.GDPlayerObjects2[i].getScaleY() < 0.8 ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDPlayerObjects2[k] = gdjs.Level1Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDPlayerObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(7), false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17188388);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(5), false);
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.variable.toggleVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(5));
}}

}


};gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level1Code.GDPlayerObjects2});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom9Objects2Objects = Hashtable.newFrom({"Mushroom9": gdjs.Level1Code.GDMushroom9Objects2});
gdjs.Level1Code.asyncCallback17190556 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(7), false);
}}
gdjs.Level1Code.eventsList89 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(3), (runtimeScene) => (gdjs.Level1Code.asyncCallback17190556(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level1Code.eventsList90 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Level1Code.GDPlayerObjects2, gdjs.Level1Code.GDPlayerObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.Level1Code.GDPlayerObjects3[i].getScaleY() == 0.8 ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDPlayerObjects3[k] = gdjs.Level1Code.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Level1Code.GDPlayerObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17190164);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects3[i].setScale(0.6);
}
}
{ //Subevents
gdjs.Level1Code.eventsList89(runtimeScene);} //End of subevents
}

}


{

/* Reuse gdjs.Level1Code.GDPlayerObjects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level1Code.GDPlayerObjects2[i].getScaleY() < 0.8 ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDPlayerObjects2[k] = gdjs.Level1Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDPlayerObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(7), false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17191692);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(5), false);
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.variable.toggleVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(5));
}}

}


};gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level1Code.GDPlayerObjects2});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom10Objects2Objects = Hashtable.newFrom({"Mushroom10": gdjs.Level1Code.GDMushroom10Objects2});
gdjs.Level1Code.asyncCallback17193924 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(7), false);
}}
gdjs.Level1Code.eventsList91 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(3), (runtimeScene) => (gdjs.Level1Code.asyncCallback17193924(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level1Code.eventsList92 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Level1Code.GDPlayerObjects2, gdjs.Level1Code.GDPlayerObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.Level1Code.GDPlayerObjects3[i].getScaleY() == 0.8 ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDPlayerObjects3[k] = gdjs.Level1Code.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Level1Code.GDPlayerObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17193532);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects3[i].setScale(0.6);
}
}
{ //Subevents
gdjs.Level1Code.eventsList91(runtimeScene);} //End of subevents
}

}


{

/* Reuse gdjs.Level1Code.GDPlayerObjects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level1Code.GDPlayerObjects2[i].getScaleY() < 0.8 ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDPlayerObjects2[k] = gdjs.Level1Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDPlayerObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(7), false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17195060);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(5), false);
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.variable.toggleVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(5));
}}

}


};gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level1Code.GDPlayerObjects2});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom11Objects2Objects = Hashtable.newFrom({"Mushroom11": gdjs.Level1Code.GDMushroom11Objects2});
gdjs.Level1Code.asyncCallback17197228 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(7), false);
}}
gdjs.Level1Code.eventsList93 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(3), (runtimeScene) => (gdjs.Level1Code.asyncCallback17197228(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level1Code.eventsList94 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Level1Code.GDPlayerObjects2, gdjs.Level1Code.GDPlayerObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.Level1Code.GDPlayerObjects3[i].getScaleY() == 0.8 ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDPlayerObjects3[k] = gdjs.Level1Code.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Level1Code.GDPlayerObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17196836);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects3[i].setScale(0.6);
}
}
{ //Subevents
gdjs.Level1Code.eventsList93(runtimeScene);} //End of subevents
}

}


{

/* Reuse gdjs.Level1Code.GDPlayerObjects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level1Code.GDPlayerObjects2[i].getScaleY() < 0.8 ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDPlayerObjects2[k] = gdjs.Level1Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDPlayerObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(7), false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17198364);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(5), false);
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.variable.toggleVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(5));
}}

}


};gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Level1Code.GDPlayerObjects1});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom12Objects1Objects = Hashtable.newFrom({"Mushroom12": gdjs.Level1Code.GDMushroom12Objects1});
gdjs.Level1Code.asyncCallback17200532 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(7), false);
}}
gdjs.Level1Code.eventsList95 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(3), (runtimeScene) => (gdjs.Level1Code.asyncCallback17200532(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level1Code.eventsList96 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Level1Code.GDPlayerObjects1, gdjs.Level1Code.GDPlayerObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level1Code.GDPlayerObjects2[i].getScaleY() == 0.8 ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDPlayerObjects2[k] = gdjs.Level1Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDPlayerObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17200140);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects2[i].setScale(0.6);
}
}
{ //Subevents
gdjs.Level1Code.eventsList95(runtimeScene);} //End of subevents
}

}


{

/* Reuse gdjs.Level1Code.GDPlayerObjects1 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.Level1Code.GDPlayerObjects1[i].getScaleY() < 0.8 ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDPlayerObjects1[k] = gdjs.Level1Code.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.Level1Code.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(7), false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17201668);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(5), false);
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.variable.toggleVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(5));
}}

}


};gdjs.Level1Code.eventsList97 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Mushroom1"), gdjs.Level1Code.GDMushroom1Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects2Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom1Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(6), false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17163468);
}
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Level1Code.eventsList74(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Mushroom2"), gdjs.Level1Code.GDMushroom2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects2Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom2Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(6), false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17166772);
}
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Level1Code.eventsList76(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Mushroom3"), gdjs.Level1Code.GDMushroom3Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects2Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom3Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(6), false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17169964);
}
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Level1Code.eventsList78(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Mushroom4"), gdjs.Level1Code.GDMushroom4Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects2Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom4Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(6), false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17173260);
}
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Level1Code.eventsList80(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Mushroom5"), gdjs.Level1Code.GDMushroom5Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects2Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom5Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(6), false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17176508);
}
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Level1Code.eventsList82(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Mushroom6"), gdjs.Level1Code.GDMushroom6Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects2Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom6Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(6), false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17179476);
}
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Level1Code.eventsList84(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Mushroom7"), gdjs.Level1Code.GDMushroom7Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects2Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom7Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(6), false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17183060);
}
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Level1Code.eventsList86(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Mushroom8"), gdjs.Level1Code.GDMushroom8Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects2Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom8Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(6), false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17186364);
}
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Level1Code.eventsList88(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Mushroom9"), gdjs.Level1Code.GDMushroom9Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects2Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom9Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(6), false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17189668);
}
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Level1Code.eventsList90(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Mushroom10"), gdjs.Level1Code.GDMushroom10Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects2Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom10Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(6), false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17193036);
}
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Level1Code.eventsList92(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Mushroom11"), gdjs.Level1Code.GDMushroom11Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects2Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom11Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(6), false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17196340);
}
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Level1Code.eventsList94(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Mushroom12"), gdjs.Level1Code.GDMushroom12Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects1Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMushroom12Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(6), false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17199644);
}
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Level1Code.eventsList96(runtimeScene);} //End of subevents
}

}


};gdjs.Level1Code.eventsList98 = function(runtimeScene) {

{


gdjs.Level1Code.eventsList28(runtimeScene);
}


{


gdjs.Level1Code.eventsList32(runtimeScene);
}


{


gdjs.Level1Code.eventsList36(runtimeScene);
}


{


gdjs.Level1Code.eventsList40(runtimeScene);
}


{


gdjs.Level1Code.eventsList44(runtimeScene);
}


{


gdjs.Level1Code.eventsList48(runtimeScene);
}


{


gdjs.Level1Code.eventsList52(runtimeScene);
}


{


gdjs.Level1Code.eventsList56(runtimeScene);
}


{


gdjs.Level1Code.eventsList60(runtimeScene);
}


{


gdjs.Level1Code.eventsList64(runtimeScene);
}


{


gdjs.Level1Code.eventsList68(runtimeScene);
}


{


gdjs.Level1Code.eventsList72(runtimeScene);
}


{


gdjs.Level1Code.eventsList97(runtimeScene);
}


};gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDHiderObjects3Objects = Hashtable.newFrom({"Hider": gdjs.Level1Code.GDHiderObjects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Level1Code.GDPlayerObjects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDBucketObjects2Objects = Hashtable.newFrom({"Bucket": gdjs.Level1Code.GDBucketObjects2});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level1Code.GDPlayerObjects2});
gdjs.Level1Code.eventsList99 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Hider"), gdjs.Level1Code.GDHiderObjects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDHiderObjects3Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Bucket"), gdjs.Level1Code.GDBucketObjects3);
{for(var i = 0, len = gdjs.Level1Code.GDBucketObjects3.length ;i < len;++i) {
    gdjs.Level1Code.GDBucketObjects3[i].hide(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bucket"), gdjs.Level1Code.GDBucketObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDBucketObjects2Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDBucketObjects2.length;i<l;++i) {
    if ( gdjs.Level1Code.GDBucketObjects2[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDBucketObjects2[k] = gdjs.Level1Code.GDBucketObjects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDBucketObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDBucketObjects2 */
/* Reuse gdjs.Level1Code.GDPlayerObjects2 */
{gdjs.evtTools.sound.playSound(runtimeScene, "[Super Mario Bros] 1UP Mushroom Sound Effect [Free Ringtone Download].mp3", false, 100, 1);
}{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects2[i].setScale(0.8);
}
}{for(var i = 0, len = gdjs.Level1Code.GDBucketObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDBucketObjects2[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getScene().getVariables().getFromIndex(0).add(1000);
}}

}


};gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDHider2Objects3Objects = Hashtable.newFrom({"Hider2": gdjs.Level1Code.GDHider2Objects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Level1Code.GDPlayerObjects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDBucket2Objects2Objects = Hashtable.newFrom({"Bucket2": gdjs.Level1Code.GDBucket2Objects2});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level1Code.GDPlayerObjects2});
gdjs.Level1Code.eventsList100 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Hider2"), gdjs.Level1Code.GDHider2Objects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDHider2Objects3Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Bucket2"), gdjs.Level1Code.GDBucket2Objects3);
{for(var i = 0, len = gdjs.Level1Code.GDBucket2Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDBucket2Objects3[i].hide(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bucket2"), gdjs.Level1Code.GDBucket2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDBucket2Objects2Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDBucket2Objects2.length;i<l;++i) {
    if ( gdjs.Level1Code.GDBucket2Objects2[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDBucket2Objects2[k] = gdjs.Level1Code.GDBucket2Objects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDBucket2Objects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDBucket2Objects2 */
/* Reuse gdjs.Level1Code.GDPlayerObjects2 */
{gdjs.evtTools.sound.playSound(runtimeScene, "[Super Mario Bros] 1UP Mushroom Sound Effect [Free Ringtone Download].mp3", false, 100, 1);
}{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects2[i].setScale(0.8);
}
}{for(var i = 0, len = gdjs.Level1Code.GDBucket2Objects2.length ;i < len;++i) {
    gdjs.Level1Code.GDBucket2Objects2[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getScene().getVariables().getFromIndex(0).add(1000);
}}

}


};gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDHider3Objects3Objects = Hashtable.newFrom({"Hider3": gdjs.Level1Code.GDHider3Objects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Level1Code.GDPlayerObjects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDBucket3Objects2Objects = Hashtable.newFrom({"Bucket3": gdjs.Level1Code.GDBucket3Objects2});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level1Code.GDPlayerObjects2});
gdjs.Level1Code.eventsList101 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Hider3"), gdjs.Level1Code.GDHider3Objects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDHider3Objects3Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Bucket3"), gdjs.Level1Code.GDBucket3Objects3);
{for(var i = 0, len = gdjs.Level1Code.GDBucket3Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDBucket3Objects3[i].hide(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bucket3"), gdjs.Level1Code.GDBucket3Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDBucket3Objects2Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDBucket3Objects2.length;i<l;++i) {
    if ( gdjs.Level1Code.GDBucket3Objects2[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDBucket3Objects2[k] = gdjs.Level1Code.GDBucket3Objects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDBucket3Objects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDBucket3Objects2 */
/* Reuse gdjs.Level1Code.GDPlayerObjects2 */
{gdjs.evtTools.sound.playSound(runtimeScene, "[Super Mario Bros] 1UP Mushroom Sound Effect [Free Ringtone Download].mp3", false, 100, 1);
}{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects2[i].setScale(0.8);
}
}{for(var i = 0, len = gdjs.Level1Code.GDBucket3Objects2.length ;i < len;++i) {
    gdjs.Level1Code.GDBucket3Objects2[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getScene().getVariables().getFromIndex(0).add(1000);
}}

}


};gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDHider6Objects3Objects = Hashtable.newFrom({"Hider6": gdjs.Level1Code.GDHider6Objects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Level1Code.GDPlayerObjects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDBucket4Objects2Objects = Hashtable.newFrom({"Bucket4": gdjs.Level1Code.GDBucket4Objects2});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level1Code.GDPlayerObjects2});
gdjs.Level1Code.eventsList102 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Hider6"), gdjs.Level1Code.GDHider6Objects3);
gdjs.copyArray(runtimeScene.getObjects("InvisibleLuckyBlock"), gdjs.Level1Code.GDInvisibleLuckyBlockObjects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDHider6Objects3Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDInvisibleLuckyBlockObjects3.length;i<l;++i) {
    if ( gdjs.Level1Code.GDInvisibleLuckyBlockObjects3[i].getVariableBoolean(gdjs.Level1Code.GDInvisibleLuckyBlockObjects3[i].getVariables().getFromIndex(0), true) ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDInvisibleLuckyBlockObjects3[k] = gdjs.Level1Code.GDInvisibleLuckyBlockObjects3[i];
        ++k;
    }
}
gdjs.Level1Code.GDInvisibleLuckyBlockObjects3.length = k;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Bucket4"), gdjs.Level1Code.GDBucket4Objects3);
{for(var i = 0, len = gdjs.Level1Code.GDBucket4Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDBucket4Objects3[i].hide(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bucket4"), gdjs.Level1Code.GDBucket4Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDBucket4Objects2Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDBucket4Objects2.length;i<l;++i) {
    if ( gdjs.Level1Code.GDBucket4Objects2[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDBucket4Objects2[k] = gdjs.Level1Code.GDBucket4Objects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDBucket4Objects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDBucket4Objects2 */
/* Reuse gdjs.Level1Code.GDPlayerObjects2 */
{gdjs.evtTools.sound.playSound(runtimeScene, "[Super Mario Bros] 1UP Mushroom Sound Effect [Free Ringtone Download].mp3", false, 100, 1);
}{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects2[i].setScale(0.8);
}
}{for(var i = 0, len = gdjs.Level1Code.GDBucket4Objects2.length ;i < len;++i) {
    gdjs.Level1Code.GDBucket4Objects2[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getScene().getVariables().getFromIndex(0).add(1000);
}}

}


};gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDHider4Objects2Objects = Hashtable.newFrom({"Hider4": gdjs.Level1Code.GDHider4Objects2});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level1Code.GDPlayerObjects2});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMarijuanaObjects2Objects = Hashtable.newFrom({"Marijuana": gdjs.Level1Code.GDMarijuanaObjects2});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level1Code.GDPlayerObjects2});
gdjs.Level1Code.asyncCallback17214588 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Stoner"), gdjs.Level1Code.GDStonerObjects2);

{for(var i = 0, len = gdjs.Level1Code.GDStonerObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDStonerObjects2[i].hide();
}
}{gdjs.evtTools.variable.toggleVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(6));
}{gdjs.evtTools.sound.stopSoundOnChannel(runtimeScene, 2);
}{gdjs.evtTools.sound.continueSoundOnChannel(runtimeScene, 1);
}}
gdjs.Level1Code.eventsList103 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Level1Code.GDStonerObjects1) asyncObjectsList.addObject("Stoner", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(10), (runtimeScene) => (gdjs.Level1Code.asyncCallback17214588(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level1Code.eventsList104 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Hider4"), gdjs.Level1Code.GDHider4Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDHider4Objects2Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Marijuana"), gdjs.Level1Code.GDMarijuanaObjects2);
{for(var i = 0, len = gdjs.Level1Code.GDMarijuanaObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDMarijuanaObjects2[i].hide(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Marijuana"), gdjs.Level1Code.GDMarijuanaObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMarijuanaObjects2Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDMarijuanaObjects2.length;i<l;++i) {
    if ( gdjs.Level1Code.GDMarijuanaObjects2[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDMarijuanaObjects2[k] = gdjs.Level1Code.GDMarijuanaObjects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDMarijuanaObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDMarijuanaObjects2 */
/* Reuse gdjs.Level1Code.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects2[i].setScale(0.8);
}
}{for(var i = 0, len = gdjs.Level1Code.GDMarijuanaObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDMarijuanaObjects2[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getScene().getVariables().getFromIndex(0).add(1000);
}{gdjs.evtTools.variable.toggleVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(6));
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(6), true);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17213652);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Stoner"), gdjs.Level1Code.GDStonerObjects1);
{gdjs.evtTools.sound.pauseSoundOnChannel(runtimeScene, 1);
}{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Super Mario Bros - Star.mp3", 2, false, 30, 1);
}{for(var i = 0, len = gdjs.Level1Code.GDStonerObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDStonerObjects1[i].hide(false);
}
}
{ //Subevents
gdjs.Level1Code.eventsList103(runtimeScene);} //End of subevents
}

}


};gdjs.Level1Code.eventsList105 = function(runtimeScene) {

{


gdjs.Level1Code.eventsList99(runtimeScene);
}


{


gdjs.Level1Code.eventsList100(runtimeScene);
}


{


gdjs.Level1Code.eventsList101(runtimeScene);
}


{


gdjs.Level1Code.eventsList102(runtimeScene);
}


{


gdjs.Level1Code.eventsList104(runtimeScene);
}


};gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level1Code.GDPlayerObjects2});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDLuckyBlockObjects2Objects = Hashtable.newFrom({"LuckyBlock": gdjs.Level1Code.GDLuckyBlockObjects2});
gdjs.Level1Code.eventsList106 = function(runtimeScene) {

{

/* Reuse gdjs.Level1Code.GDLuckyBlockObjects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDLuckyBlockObjects2.length;i<l;++i) {
    if ( gdjs.Level1Code.GDLuckyBlockObjects2[i].isCurrentAnimationName("UnusedLB") ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDLuckyBlockObjects2[k] = gdjs.Level1Code.GDLuckyBlockObjects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDLuckyBlockObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDLuckyBlockObjects2 */
{for(var i = 0, len = gdjs.Level1Code.GDLuckyBlockObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDLuckyBlockObjects2[i].setAnimationName("UsedLB");
}
}}

}


};gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level1Code.GDPlayerObjects2});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDInvisibleLuckyBlockObjects2Objects = Hashtable.newFrom({"InvisibleLuckyBlock": gdjs.Level1Code.GDInvisibleLuckyBlockObjects2});
gdjs.Level1Code.asyncCallback17219004 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("InvisibleLuckyBlock"), gdjs.Level1Code.GDInvisibleLuckyBlockObjects3);

{for(var i = 0, len = gdjs.Level1Code.GDInvisibleLuckyBlockObjects3.length ;i < len;++i) {
    gdjs.Level1Code.GDInvisibleLuckyBlockObjects3[i].setVariableBoolean(gdjs.Level1Code.GDInvisibleLuckyBlockObjects3[i].getVariables().getFromIndex(0), true);
}
}}
gdjs.Level1Code.eventsList107 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Level1Code.GDInvisibleLuckyBlockObjects2) asyncObjectsList.addObject("InvisibleLuckyBlock", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Level1Code.asyncCallback17219004(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Level1Code.GDPlayerObjects1});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDInvisibleLuckyBlockObjects1Objects = Hashtable.newFrom({"InvisibleLuckyBlock": gdjs.Level1Code.GDInvisibleLuckyBlockObjects1});
gdjs.Level1Code.eventsList108 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("LuckyBlock"), gdjs.Level1Code.GDLuckyBlockObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects2Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDLuckyBlockObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.Level1Code.eventsList106(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("InvisibleLuckyBlock"), gdjs.Level1Code.GDInvisibleLuckyBlockObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects2Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDInvisibleLuckyBlockObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17217428);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDInvisibleLuckyBlockObjects2.length;i<l;++i) {
    if ( gdjs.Level1Code.GDInvisibleLuckyBlockObjects2[i].getVariableBoolean(gdjs.Level1Code.GDInvisibleLuckyBlockObjects2[i].getVariables().getFromIndex(0), false) ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDInvisibleLuckyBlockObjects2[k] = gdjs.Level1Code.GDInvisibleLuckyBlockObjects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDInvisibleLuckyBlockObjects2.length = k;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDInvisibleLuckyBlockObjects2 */
{for(var i = 0, len = gdjs.Level1Code.GDInvisibleLuckyBlockObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDInvisibleLuckyBlockObjects2[i].setOpacity(255);
}
}{for(var i = 0, len = gdjs.Level1Code.GDInvisibleLuckyBlockObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDInvisibleLuckyBlockObjects2[i].setAnimationName("UnusedLB");
}
}
{ //Subevents
gdjs.Level1Code.eventsList107(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("InvisibleLuckyBlock"), gdjs.Level1Code.GDInvisibleLuckyBlockObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDInvisibleLuckyBlockObjects1.length;i<l;++i) {
    if ( gdjs.Level1Code.GDInvisibleLuckyBlockObjects1[i].isCurrentAnimationName("UnusedLB") ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDInvisibleLuckyBlockObjects1[k] = gdjs.Level1Code.GDInvisibleLuckyBlockObjects1[i];
        ++k;
    }
}
gdjs.Level1Code.GDInvisibleLuckyBlockObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects1Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDInvisibleLuckyBlockObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDInvisibleLuckyBlockObjects1.length;i<l;++i) {
    if ( gdjs.Level1Code.GDInvisibleLuckyBlockObjects1[i].getVariableBoolean(gdjs.Level1Code.GDInvisibleLuckyBlockObjects1[i].getVariables().getFromIndex(0), true) ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDInvisibleLuckyBlockObjects1[k] = gdjs.Level1Code.GDInvisibleLuckyBlockObjects1[i];
        ++k;
    }
}
gdjs.Level1Code.GDInvisibleLuckyBlockObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17221084);
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDInvisibleLuckyBlockObjects1 */
{for(var i = 0, len = gdjs.Level1Code.GDInvisibleLuckyBlockObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDInvisibleLuckyBlockObjects1[i].setAnimationName("UsedLB");
}
}}

}


};gdjs.Level1Code.eventsList109 = function(runtimeScene) {

{


gdjs.Level1Code.eventsList0(runtimeScene);
}


{


gdjs.Level1Code.eventsList1(runtimeScene);
}


{


gdjs.Level1Code.eventsList13(runtimeScene);
}


{


gdjs.Level1Code.eventsList14(runtimeScene);
}


{


gdjs.Level1Code.eventsList17(runtimeScene);
}


{


gdjs.Level1Code.eventsList24(runtimeScene);
}


{


gdjs.Level1Code.eventsList98(runtimeScene);
}


{


gdjs.Level1Code.eventsList105(runtimeScene);
}


{


gdjs.Level1Code.eventsList108(runtimeScene);
}


{


let isConditionTrue_0 = false;
{
}

}


};

gdjs.Level1Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Level1Code.GDPlayerObjects1.length = 0;
gdjs.Level1Code.GDPlayerObjects2.length = 0;
gdjs.Level1Code.GDPlayerObjects3.length = 0;
gdjs.Level1Code.GDPlayerObjects4.length = 0;
gdjs.Level1Code.GDPlayerObjects5.length = 0;
gdjs.Level1Code.GDPlayerObjects6.length = 0;
gdjs.Level1Code.GDGroundObjects1.length = 0;
gdjs.Level1Code.GDGroundObjects2.length = 0;
gdjs.Level1Code.GDGroundObjects3.length = 0;
gdjs.Level1Code.GDGroundObjects4.length = 0;
gdjs.Level1Code.GDGroundObjects5.length = 0;
gdjs.Level1Code.GDGroundObjects6.length = 0;
gdjs.Level1Code.GDUndergroundGroundObjects1.length = 0;
gdjs.Level1Code.GDUndergroundGroundObjects2.length = 0;
gdjs.Level1Code.GDUndergroundGroundObjects3.length = 0;
gdjs.Level1Code.GDUndergroundGroundObjects4.length = 0;
gdjs.Level1Code.GDUndergroundGroundObjects5.length = 0;
gdjs.Level1Code.GDUndergroundGroundObjects6.length = 0;
gdjs.Level1Code.GDPipeObjects1.length = 0;
gdjs.Level1Code.GDPipeObjects2.length = 0;
gdjs.Level1Code.GDPipeObjects3.length = 0;
gdjs.Level1Code.GDPipeObjects4.length = 0;
gdjs.Level1Code.GDPipeObjects5.length = 0;
gdjs.Level1Code.GDPipeObjects6.length = 0;
gdjs.Level1Code.GDPipe2Objects1.length = 0;
gdjs.Level1Code.GDPipe2Objects2.length = 0;
gdjs.Level1Code.GDPipe2Objects3.length = 0;
gdjs.Level1Code.GDPipe2Objects4.length = 0;
gdjs.Level1Code.GDPipe2Objects5.length = 0;
gdjs.Level1Code.GDPipe2Objects6.length = 0;
gdjs.Level1Code.GDPipeLengthObjects1.length = 0;
gdjs.Level1Code.GDPipeLengthObjects2.length = 0;
gdjs.Level1Code.GDPipeLengthObjects3.length = 0;
gdjs.Level1Code.GDPipeLengthObjects4.length = 0;
gdjs.Level1Code.GDPipeLengthObjects5.length = 0;
gdjs.Level1Code.GDPipeLengthObjects6.length = 0;
gdjs.Level1Code.GDLuckyBlockObjects1.length = 0;
gdjs.Level1Code.GDLuckyBlockObjects2.length = 0;
gdjs.Level1Code.GDLuckyBlockObjects3.length = 0;
gdjs.Level1Code.GDLuckyBlockObjects4.length = 0;
gdjs.Level1Code.GDLuckyBlockObjects5.length = 0;
gdjs.Level1Code.GDLuckyBlockObjects6.length = 0;
gdjs.Level1Code.GDInvisibleLuckyBlockObjects1.length = 0;
gdjs.Level1Code.GDInvisibleLuckyBlockObjects2.length = 0;
gdjs.Level1Code.GDInvisibleLuckyBlockObjects3.length = 0;
gdjs.Level1Code.GDInvisibleLuckyBlockObjects4.length = 0;
gdjs.Level1Code.GDInvisibleLuckyBlockObjects5.length = 0;
gdjs.Level1Code.GDInvisibleLuckyBlockObjects6.length = 0;
gdjs.Level1Code.GDBrickObjects1.length = 0;
gdjs.Level1Code.GDBrickObjects2.length = 0;
gdjs.Level1Code.GDBrickObjects3.length = 0;
gdjs.Level1Code.GDBrickObjects4.length = 0;
gdjs.Level1Code.GDBrickObjects5.length = 0;
gdjs.Level1Code.GDBrickObjects6.length = 0;
gdjs.Level1Code.GDUndergroundBrickObjects1.length = 0;
gdjs.Level1Code.GDUndergroundBrickObjects2.length = 0;
gdjs.Level1Code.GDUndergroundBrickObjects3.length = 0;
gdjs.Level1Code.GDUndergroundBrickObjects4.length = 0;
gdjs.Level1Code.GDUndergroundBrickObjects5.length = 0;
gdjs.Level1Code.GDUndergroundBrickObjects6.length = 0;
gdjs.Level1Code.GDStoneObjects1.length = 0;
gdjs.Level1Code.GDStoneObjects2.length = 0;
gdjs.Level1Code.GDStoneObjects3.length = 0;
gdjs.Level1Code.GDStoneObjects4.length = 0;
gdjs.Level1Code.GDStoneObjects5.length = 0;
gdjs.Level1Code.GDStoneObjects6.length = 0;
gdjs.Level1Code.GDNicknameObjects1.length = 0;
gdjs.Level1Code.GDNicknameObjects2.length = 0;
gdjs.Level1Code.GDNicknameObjects3.length = 0;
gdjs.Level1Code.GDNicknameObjects4.length = 0;
gdjs.Level1Code.GDNicknameObjects5.length = 0;
gdjs.Level1Code.GDNicknameObjects6.length = 0;
gdjs.Level1Code.GDTimeObjects1.length = 0;
gdjs.Level1Code.GDTimeObjects2.length = 0;
gdjs.Level1Code.GDTimeObjects3.length = 0;
gdjs.Level1Code.GDTimeObjects4.length = 0;
gdjs.Level1Code.GDTimeObjects5.length = 0;
gdjs.Level1Code.GDTimeObjects6.length = 0;
gdjs.Level1Code.GDWorldObjects1.length = 0;
gdjs.Level1Code.GDWorldObjects2.length = 0;
gdjs.Level1Code.GDWorldObjects3.length = 0;
gdjs.Level1Code.GDWorldObjects4.length = 0;
gdjs.Level1Code.GDWorldObjects5.length = 0;
gdjs.Level1Code.GDWorldObjects6.length = 0;
gdjs.Level1Code.GDPointsObjects1.length = 0;
gdjs.Level1Code.GDPointsObjects2.length = 0;
gdjs.Level1Code.GDPointsObjects3.length = 0;
gdjs.Level1Code.GDPointsObjects4.length = 0;
gdjs.Level1Code.GDPointsObjects5.length = 0;
gdjs.Level1Code.GDPointsObjects6.length = 0;
gdjs.Level1Code.GDCoinAmmoutObjects1.length = 0;
gdjs.Level1Code.GDCoinAmmoutObjects2.length = 0;
gdjs.Level1Code.GDCoinAmmoutObjects3.length = 0;
gdjs.Level1Code.GDCoinAmmoutObjects4.length = 0;
gdjs.Level1Code.GDCoinAmmoutObjects5.length = 0;
gdjs.Level1Code.GDCoinAmmoutObjects6.length = 0;
gdjs.Level1Code.GDLivesAmmoutObjects1.length = 0;
gdjs.Level1Code.GDLivesAmmoutObjects2.length = 0;
gdjs.Level1Code.GDLivesAmmoutObjects3.length = 0;
gdjs.Level1Code.GDLivesAmmoutObjects4.length = 0;
gdjs.Level1Code.GDLivesAmmoutObjects5.length = 0;
gdjs.Level1Code.GDLivesAmmoutObjects6.length = 0;
gdjs.Level1Code.GDTimeLeftObjects1.length = 0;
gdjs.Level1Code.GDTimeLeftObjects2.length = 0;
gdjs.Level1Code.GDTimeLeftObjects3.length = 0;
gdjs.Level1Code.GDTimeLeftObjects4.length = 0;
gdjs.Level1Code.GDTimeLeftObjects5.length = 0;
gdjs.Level1Code.GDTimeLeftObjects6.length = 0;
gdjs.Level1Code.GDPolePointsObjects1.length = 0;
gdjs.Level1Code.GDPolePointsObjects2.length = 0;
gdjs.Level1Code.GDPolePointsObjects3.length = 0;
gdjs.Level1Code.GDPolePointsObjects4.length = 0;
gdjs.Level1Code.GDPolePointsObjects5.length = 0;
gdjs.Level1Code.GDPolePointsObjects6.length = 0;
gdjs.Level1Code.GDLevelObjects1.length = 0;
gdjs.Level1Code.GDLevelObjects2.length = 0;
gdjs.Level1Code.GDLevelObjects3.length = 0;
gdjs.Level1Code.GDLevelObjects4.length = 0;
gdjs.Level1Code.GDLevelObjects5.length = 0;
gdjs.Level1Code.GDLevelObjects6.length = 0;
gdjs.Level1Code.GDGameOverObjects1.length = 0;
gdjs.Level1Code.GDGameOverObjects2.length = 0;
gdjs.Level1Code.GDGameOverObjects3.length = 0;
gdjs.Level1Code.GDGameOverObjects4.length = 0;
gdjs.Level1Code.GDGameOverObjects5.length = 0;
gdjs.Level1Code.GDGameOverObjects6.length = 0;
gdjs.Level1Code.GDBackgroundImgObjects1.length = 0;
gdjs.Level1Code.GDBackgroundImgObjects2.length = 0;
gdjs.Level1Code.GDBackgroundImgObjects3.length = 0;
gdjs.Level1Code.GDBackgroundImgObjects4.length = 0;
gdjs.Level1Code.GDBackgroundImgObjects5.length = 0;
gdjs.Level1Code.GDBackgroundImgObjects6.length = 0;
gdjs.Level1Code.GDBorderObjects1.length = 0;
gdjs.Level1Code.GDBorderObjects2.length = 0;
gdjs.Level1Code.GDBorderObjects3.length = 0;
gdjs.Level1Code.GDBorderObjects4.length = 0;
gdjs.Level1Code.GDBorderObjects5.length = 0;
gdjs.Level1Code.GDBorderObjects6.length = 0;
gdjs.Level1Code.GDMushroom1Objects1.length = 0;
gdjs.Level1Code.GDMushroom1Objects2.length = 0;
gdjs.Level1Code.GDMushroom1Objects3.length = 0;
gdjs.Level1Code.GDMushroom1Objects4.length = 0;
gdjs.Level1Code.GDMushroom1Objects5.length = 0;
gdjs.Level1Code.GDMushroom1Objects6.length = 0;
gdjs.Level1Code.GDMushroom2Objects1.length = 0;
gdjs.Level1Code.GDMushroom2Objects2.length = 0;
gdjs.Level1Code.GDMushroom2Objects3.length = 0;
gdjs.Level1Code.GDMushroom2Objects4.length = 0;
gdjs.Level1Code.GDMushroom2Objects5.length = 0;
gdjs.Level1Code.GDMushroom2Objects6.length = 0;
gdjs.Level1Code.GDMushroom3Objects1.length = 0;
gdjs.Level1Code.GDMushroom3Objects2.length = 0;
gdjs.Level1Code.GDMushroom3Objects3.length = 0;
gdjs.Level1Code.GDMushroom3Objects4.length = 0;
gdjs.Level1Code.GDMushroom3Objects5.length = 0;
gdjs.Level1Code.GDMushroom3Objects6.length = 0;
gdjs.Level1Code.GDMushroom4Objects1.length = 0;
gdjs.Level1Code.GDMushroom4Objects2.length = 0;
gdjs.Level1Code.GDMushroom4Objects3.length = 0;
gdjs.Level1Code.GDMushroom4Objects4.length = 0;
gdjs.Level1Code.GDMushroom4Objects5.length = 0;
gdjs.Level1Code.GDMushroom4Objects6.length = 0;
gdjs.Level1Code.GDMushroom5Objects1.length = 0;
gdjs.Level1Code.GDMushroom5Objects2.length = 0;
gdjs.Level1Code.GDMushroom5Objects3.length = 0;
gdjs.Level1Code.GDMushroom5Objects4.length = 0;
gdjs.Level1Code.GDMushroom5Objects5.length = 0;
gdjs.Level1Code.GDMushroom5Objects6.length = 0;
gdjs.Level1Code.GDMushroom6Objects1.length = 0;
gdjs.Level1Code.GDMushroom6Objects2.length = 0;
gdjs.Level1Code.GDMushroom6Objects3.length = 0;
gdjs.Level1Code.GDMushroom6Objects4.length = 0;
gdjs.Level1Code.GDMushroom6Objects5.length = 0;
gdjs.Level1Code.GDMushroom6Objects6.length = 0;
gdjs.Level1Code.GDMushroom7Objects1.length = 0;
gdjs.Level1Code.GDMushroom7Objects2.length = 0;
gdjs.Level1Code.GDMushroom7Objects3.length = 0;
gdjs.Level1Code.GDMushroom7Objects4.length = 0;
gdjs.Level1Code.GDMushroom7Objects5.length = 0;
gdjs.Level1Code.GDMushroom7Objects6.length = 0;
gdjs.Level1Code.GDMushroom8Objects1.length = 0;
gdjs.Level1Code.GDMushroom8Objects2.length = 0;
gdjs.Level1Code.GDMushroom8Objects3.length = 0;
gdjs.Level1Code.GDMushroom8Objects4.length = 0;
gdjs.Level1Code.GDMushroom8Objects5.length = 0;
gdjs.Level1Code.GDMushroom8Objects6.length = 0;
gdjs.Level1Code.GDMushroom9Objects1.length = 0;
gdjs.Level1Code.GDMushroom9Objects2.length = 0;
gdjs.Level1Code.GDMushroom9Objects3.length = 0;
gdjs.Level1Code.GDMushroom9Objects4.length = 0;
gdjs.Level1Code.GDMushroom9Objects5.length = 0;
gdjs.Level1Code.GDMushroom9Objects6.length = 0;
gdjs.Level1Code.GDMushroom10Objects1.length = 0;
gdjs.Level1Code.GDMushroom10Objects2.length = 0;
gdjs.Level1Code.GDMushroom10Objects3.length = 0;
gdjs.Level1Code.GDMushroom10Objects4.length = 0;
gdjs.Level1Code.GDMushroom10Objects5.length = 0;
gdjs.Level1Code.GDMushroom10Objects6.length = 0;
gdjs.Level1Code.GDMushroom11Objects1.length = 0;
gdjs.Level1Code.GDMushroom11Objects2.length = 0;
gdjs.Level1Code.GDMushroom11Objects3.length = 0;
gdjs.Level1Code.GDMushroom11Objects4.length = 0;
gdjs.Level1Code.GDMushroom11Objects5.length = 0;
gdjs.Level1Code.GDMushroom11Objects6.length = 0;
gdjs.Level1Code.GDMushroom12Objects1.length = 0;
gdjs.Level1Code.GDMushroom12Objects2.length = 0;
gdjs.Level1Code.GDMushroom12Objects3.length = 0;
gdjs.Level1Code.GDMushroom12Objects4.length = 0;
gdjs.Level1Code.GDMushroom12Objects5.length = 0;
gdjs.Level1Code.GDMushroom12Objects6.length = 0;
gdjs.Level1Code.GDGoLeft1Objects1.length = 0;
gdjs.Level1Code.GDGoLeft1Objects2.length = 0;
gdjs.Level1Code.GDGoLeft1Objects3.length = 0;
gdjs.Level1Code.GDGoLeft1Objects4.length = 0;
gdjs.Level1Code.GDGoLeft1Objects5.length = 0;
gdjs.Level1Code.GDGoLeft1Objects6.length = 0;
gdjs.Level1Code.GDGoLeft2Objects1.length = 0;
gdjs.Level1Code.GDGoLeft2Objects2.length = 0;
gdjs.Level1Code.GDGoLeft2Objects3.length = 0;
gdjs.Level1Code.GDGoLeft2Objects4.length = 0;
gdjs.Level1Code.GDGoLeft2Objects5.length = 0;
gdjs.Level1Code.GDGoLeft2Objects6.length = 0;
gdjs.Level1Code.GDGoLeft3Objects1.length = 0;
gdjs.Level1Code.GDGoLeft3Objects2.length = 0;
gdjs.Level1Code.GDGoLeft3Objects3.length = 0;
gdjs.Level1Code.GDGoLeft3Objects4.length = 0;
gdjs.Level1Code.GDGoLeft3Objects5.length = 0;
gdjs.Level1Code.GDGoLeft3Objects6.length = 0;
gdjs.Level1Code.GDGoLeft4Objects1.length = 0;
gdjs.Level1Code.GDGoLeft4Objects2.length = 0;
gdjs.Level1Code.GDGoLeft4Objects3.length = 0;
gdjs.Level1Code.GDGoLeft4Objects4.length = 0;
gdjs.Level1Code.GDGoLeft4Objects5.length = 0;
gdjs.Level1Code.GDGoLeft4Objects6.length = 0;
gdjs.Level1Code.GDGoLeft5Objects1.length = 0;
gdjs.Level1Code.GDGoLeft5Objects2.length = 0;
gdjs.Level1Code.GDGoLeft5Objects3.length = 0;
gdjs.Level1Code.GDGoLeft5Objects4.length = 0;
gdjs.Level1Code.GDGoLeft5Objects5.length = 0;
gdjs.Level1Code.GDGoLeft5Objects6.length = 0;
gdjs.Level1Code.GDGoLeft6Objects1.length = 0;
gdjs.Level1Code.GDGoLeft6Objects2.length = 0;
gdjs.Level1Code.GDGoLeft6Objects3.length = 0;
gdjs.Level1Code.GDGoLeft6Objects4.length = 0;
gdjs.Level1Code.GDGoLeft6Objects5.length = 0;
gdjs.Level1Code.GDGoLeft6Objects6.length = 0;
gdjs.Level1Code.GDGoLeft7Objects1.length = 0;
gdjs.Level1Code.GDGoLeft7Objects2.length = 0;
gdjs.Level1Code.GDGoLeft7Objects3.length = 0;
gdjs.Level1Code.GDGoLeft7Objects4.length = 0;
gdjs.Level1Code.GDGoLeft7Objects5.length = 0;
gdjs.Level1Code.GDGoLeft7Objects6.length = 0;
gdjs.Level1Code.GDGoLeft8Objects1.length = 0;
gdjs.Level1Code.GDGoLeft8Objects2.length = 0;
gdjs.Level1Code.GDGoLeft8Objects3.length = 0;
gdjs.Level1Code.GDGoLeft8Objects4.length = 0;
gdjs.Level1Code.GDGoLeft8Objects5.length = 0;
gdjs.Level1Code.GDGoLeft8Objects6.length = 0;
gdjs.Level1Code.GDGoLeft9Objects1.length = 0;
gdjs.Level1Code.GDGoLeft9Objects2.length = 0;
gdjs.Level1Code.GDGoLeft9Objects3.length = 0;
gdjs.Level1Code.GDGoLeft9Objects4.length = 0;
gdjs.Level1Code.GDGoLeft9Objects5.length = 0;
gdjs.Level1Code.GDGoLeft9Objects6.length = 0;
gdjs.Level1Code.GDGoLeft10Objects1.length = 0;
gdjs.Level1Code.GDGoLeft10Objects2.length = 0;
gdjs.Level1Code.GDGoLeft10Objects3.length = 0;
gdjs.Level1Code.GDGoLeft10Objects4.length = 0;
gdjs.Level1Code.GDGoLeft10Objects5.length = 0;
gdjs.Level1Code.GDGoLeft10Objects6.length = 0;
gdjs.Level1Code.GDGoLeft11Objects1.length = 0;
gdjs.Level1Code.GDGoLeft11Objects2.length = 0;
gdjs.Level1Code.GDGoLeft11Objects3.length = 0;
gdjs.Level1Code.GDGoLeft11Objects4.length = 0;
gdjs.Level1Code.GDGoLeft11Objects5.length = 0;
gdjs.Level1Code.GDGoLeft11Objects6.length = 0;
gdjs.Level1Code.GDGoLeft12Objects1.length = 0;
gdjs.Level1Code.GDGoLeft12Objects2.length = 0;
gdjs.Level1Code.GDGoLeft12Objects3.length = 0;
gdjs.Level1Code.GDGoLeft12Objects4.length = 0;
gdjs.Level1Code.GDGoLeft12Objects5.length = 0;
gdjs.Level1Code.GDGoLeft12Objects6.length = 0;
gdjs.Level1Code.GDGoRight1Objects1.length = 0;
gdjs.Level1Code.GDGoRight1Objects2.length = 0;
gdjs.Level1Code.GDGoRight1Objects3.length = 0;
gdjs.Level1Code.GDGoRight1Objects4.length = 0;
gdjs.Level1Code.GDGoRight1Objects5.length = 0;
gdjs.Level1Code.GDGoRight1Objects6.length = 0;
gdjs.Level1Code.GDGoRight2Objects1.length = 0;
gdjs.Level1Code.GDGoRight2Objects2.length = 0;
gdjs.Level1Code.GDGoRight2Objects3.length = 0;
gdjs.Level1Code.GDGoRight2Objects4.length = 0;
gdjs.Level1Code.GDGoRight2Objects5.length = 0;
gdjs.Level1Code.GDGoRight2Objects6.length = 0;
gdjs.Level1Code.GDGoRight3Objects1.length = 0;
gdjs.Level1Code.GDGoRight3Objects2.length = 0;
gdjs.Level1Code.GDGoRight3Objects3.length = 0;
gdjs.Level1Code.GDGoRight3Objects4.length = 0;
gdjs.Level1Code.GDGoRight3Objects5.length = 0;
gdjs.Level1Code.GDGoRight3Objects6.length = 0;
gdjs.Level1Code.GDGoRight4Objects1.length = 0;
gdjs.Level1Code.GDGoRight4Objects2.length = 0;
gdjs.Level1Code.GDGoRight4Objects3.length = 0;
gdjs.Level1Code.GDGoRight4Objects4.length = 0;
gdjs.Level1Code.GDGoRight4Objects5.length = 0;
gdjs.Level1Code.GDGoRight4Objects6.length = 0;
gdjs.Level1Code.GDGoRight5Objects1.length = 0;
gdjs.Level1Code.GDGoRight5Objects2.length = 0;
gdjs.Level1Code.GDGoRight5Objects3.length = 0;
gdjs.Level1Code.GDGoRight5Objects4.length = 0;
gdjs.Level1Code.GDGoRight5Objects5.length = 0;
gdjs.Level1Code.GDGoRight5Objects6.length = 0;
gdjs.Level1Code.GDGoRight6Objects1.length = 0;
gdjs.Level1Code.GDGoRight6Objects2.length = 0;
gdjs.Level1Code.GDGoRight6Objects3.length = 0;
gdjs.Level1Code.GDGoRight6Objects4.length = 0;
gdjs.Level1Code.GDGoRight6Objects5.length = 0;
gdjs.Level1Code.GDGoRight6Objects6.length = 0;
gdjs.Level1Code.GDGoRight7Objects1.length = 0;
gdjs.Level1Code.GDGoRight7Objects2.length = 0;
gdjs.Level1Code.GDGoRight7Objects3.length = 0;
gdjs.Level1Code.GDGoRight7Objects4.length = 0;
gdjs.Level1Code.GDGoRight7Objects5.length = 0;
gdjs.Level1Code.GDGoRight7Objects6.length = 0;
gdjs.Level1Code.GDGoRight8Objects1.length = 0;
gdjs.Level1Code.GDGoRight8Objects2.length = 0;
gdjs.Level1Code.GDGoRight8Objects3.length = 0;
gdjs.Level1Code.GDGoRight8Objects4.length = 0;
gdjs.Level1Code.GDGoRight8Objects5.length = 0;
gdjs.Level1Code.GDGoRight8Objects6.length = 0;
gdjs.Level1Code.GDGoRight9Objects1.length = 0;
gdjs.Level1Code.GDGoRight9Objects2.length = 0;
gdjs.Level1Code.GDGoRight9Objects3.length = 0;
gdjs.Level1Code.GDGoRight9Objects4.length = 0;
gdjs.Level1Code.GDGoRight9Objects5.length = 0;
gdjs.Level1Code.GDGoRight9Objects6.length = 0;
gdjs.Level1Code.GDGoRight10Objects1.length = 0;
gdjs.Level1Code.GDGoRight10Objects2.length = 0;
gdjs.Level1Code.GDGoRight10Objects3.length = 0;
gdjs.Level1Code.GDGoRight10Objects4.length = 0;
gdjs.Level1Code.GDGoRight10Objects5.length = 0;
gdjs.Level1Code.GDGoRight10Objects6.length = 0;
gdjs.Level1Code.GDGoRight11Objects1.length = 0;
gdjs.Level1Code.GDGoRight11Objects2.length = 0;
gdjs.Level1Code.GDGoRight11Objects3.length = 0;
gdjs.Level1Code.GDGoRight11Objects4.length = 0;
gdjs.Level1Code.GDGoRight11Objects5.length = 0;
gdjs.Level1Code.GDGoRight11Objects6.length = 0;
gdjs.Level1Code.GDGoRight12Objects1.length = 0;
gdjs.Level1Code.GDGoRight12Objects2.length = 0;
gdjs.Level1Code.GDGoRight12Objects3.length = 0;
gdjs.Level1Code.GDGoRight12Objects4.length = 0;
gdjs.Level1Code.GDGoRight12Objects5.length = 0;
gdjs.Level1Code.GDGoRight12Objects6.length = 0;
gdjs.Level1Code.GDHeadDMG1Objects1.length = 0;
gdjs.Level1Code.GDHeadDMG1Objects2.length = 0;
gdjs.Level1Code.GDHeadDMG1Objects3.length = 0;
gdjs.Level1Code.GDHeadDMG1Objects4.length = 0;
gdjs.Level1Code.GDHeadDMG1Objects5.length = 0;
gdjs.Level1Code.GDHeadDMG1Objects6.length = 0;
gdjs.Level1Code.GDHeadDMG2Objects1.length = 0;
gdjs.Level1Code.GDHeadDMG2Objects2.length = 0;
gdjs.Level1Code.GDHeadDMG2Objects3.length = 0;
gdjs.Level1Code.GDHeadDMG2Objects4.length = 0;
gdjs.Level1Code.GDHeadDMG2Objects5.length = 0;
gdjs.Level1Code.GDHeadDMG2Objects6.length = 0;
gdjs.Level1Code.GDHeadDMG3Objects1.length = 0;
gdjs.Level1Code.GDHeadDMG3Objects2.length = 0;
gdjs.Level1Code.GDHeadDMG3Objects3.length = 0;
gdjs.Level1Code.GDHeadDMG3Objects4.length = 0;
gdjs.Level1Code.GDHeadDMG3Objects5.length = 0;
gdjs.Level1Code.GDHeadDMG3Objects6.length = 0;
gdjs.Level1Code.GDHeadDMG4Objects1.length = 0;
gdjs.Level1Code.GDHeadDMG4Objects2.length = 0;
gdjs.Level1Code.GDHeadDMG4Objects3.length = 0;
gdjs.Level1Code.GDHeadDMG4Objects4.length = 0;
gdjs.Level1Code.GDHeadDMG4Objects5.length = 0;
gdjs.Level1Code.GDHeadDMG4Objects6.length = 0;
gdjs.Level1Code.GDHeadDMG5Objects1.length = 0;
gdjs.Level1Code.GDHeadDMG5Objects2.length = 0;
gdjs.Level1Code.GDHeadDMG5Objects3.length = 0;
gdjs.Level1Code.GDHeadDMG5Objects4.length = 0;
gdjs.Level1Code.GDHeadDMG5Objects5.length = 0;
gdjs.Level1Code.GDHeadDMG5Objects6.length = 0;
gdjs.Level1Code.GDHeadDMG6Objects1.length = 0;
gdjs.Level1Code.GDHeadDMG6Objects2.length = 0;
gdjs.Level1Code.GDHeadDMG6Objects3.length = 0;
gdjs.Level1Code.GDHeadDMG6Objects4.length = 0;
gdjs.Level1Code.GDHeadDMG6Objects5.length = 0;
gdjs.Level1Code.GDHeadDMG6Objects6.length = 0;
gdjs.Level1Code.GDHeadDMG7Objects1.length = 0;
gdjs.Level1Code.GDHeadDMG7Objects2.length = 0;
gdjs.Level1Code.GDHeadDMG7Objects3.length = 0;
gdjs.Level1Code.GDHeadDMG7Objects4.length = 0;
gdjs.Level1Code.GDHeadDMG7Objects5.length = 0;
gdjs.Level1Code.GDHeadDMG7Objects6.length = 0;
gdjs.Level1Code.GDHeadDMG8Objects1.length = 0;
gdjs.Level1Code.GDHeadDMG8Objects2.length = 0;
gdjs.Level1Code.GDHeadDMG8Objects3.length = 0;
gdjs.Level1Code.GDHeadDMG8Objects4.length = 0;
gdjs.Level1Code.GDHeadDMG8Objects5.length = 0;
gdjs.Level1Code.GDHeadDMG8Objects6.length = 0;
gdjs.Level1Code.GDHeadDMG9Objects1.length = 0;
gdjs.Level1Code.GDHeadDMG9Objects2.length = 0;
gdjs.Level1Code.GDHeadDMG9Objects3.length = 0;
gdjs.Level1Code.GDHeadDMG9Objects4.length = 0;
gdjs.Level1Code.GDHeadDMG9Objects5.length = 0;
gdjs.Level1Code.GDHeadDMG9Objects6.length = 0;
gdjs.Level1Code.GDHeadDMG10Objects1.length = 0;
gdjs.Level1Code.GDHeadDMG10Objects2.length = 0;
gdjs.Level1Code.GDHeadDMG10Objects3.length = 0;
gdjs.Level1Code.GDHeadDMG10Objects4.length = 0;
gdjs.Level1Code.GDHeadDMG10Objects5.length = 0;
gdjs.Level1Code.GDHeadDMG10Objects6.length = 0;
gdjs.Level1Code.GDHeadDMG11Objects1.length = 0;
gdjs.Level1Code.GDHeadDMG11Objects2.length = 0;
gdjs.Level1Code.GDHeadDMG11Objects3.length = 0;
gdjs.Level1Code.GDHeadDMG11Objects4.length = 0;
gdjs.Level1Code.GDHeadDMG11Objects5.length = 0;
gdjs.Level1Code.GDHeadDMG11Objects6.length = 0;
gdjs.Level1Code.GDHeadDMG12Objects1.length = 0;
gdjs.Level1Code.GDHeadDMG12Objects2.length = 0;
gdjs.Level1Code.GDHeadDMG12Objects3.length = 0;
gdjs.Level1Code.GDHeadDMG12Objects4.length = 0;
gdjs.Level1Code.GDHeadDMG12Objects5.length = 0;
gdjs.Level1Code.GDHeadDMG12Objects6.length = 0;
gdjs.Level1Code.GDUndergroundBGObjects1.length = 0;
gdjs.Level1Code.GDUndergroundBGObjects2.length = 0;
gdjs.Level1Code.GDUndergroundBGObjects3.length = 0;
gdjs.Level1Code.GDUndergroundBGObjects4.length = 0;
gdjs.Level1Code.GDUndergroundBGObjects5.length = 0;
gdjs.Level1Code.GDUndergroundBGObjects6.length = 0;
gdjs.Level1Code.GDBlackFadeObjects1.length = 0;
gdjs.Level1Code.GDBlackFadeObjects2.length = 0;
gdjs.Level1Code.GDBlackFadeObjects3.length = 0;
gdjs.Level1Code.GDBlackFadeObjects4.length = 0;
gdjs.Level1Code.GDBlackFadeObjects5.length = 0;
gdjs.Level1Code.GDBlackFadeObjects6.length = 0;
gdjs.Level1Code.GDTeleport1Objects1.length = 0;
gdjs.Level1Code.GDTeleport1Objects2.length = 0;
gdjs.Level1Code.GDTeleport1Objects3.length = 0;
gdjs.Level1Code.GDTeleport1Objects4.length = 0;
gdjs.Level1Code.GDTeleport1Objects5.length = 0;
gdjs.Level1Code.GDTeleport1Objects6.length = 0;
gdjs.Level1Code.GDTeleport2Objects1.length = 0;
gdjs.Level1Code.GDTeleport2Objects2.length = 0;
gdjs.Level1Code.GDTeleport2Objects3.length = 0;
gdjs.Level1Code.GDTeleport2Objects4.length = 0;
gdjs.Level1Code.GDTeleport2Objects5.length = 0;
gdjs.Level1Code.GDTeleport2Objects6.length = 0;
gdjs.Level1Code.GDCoinObjects1.length = 0;
gdjs.Level1Code.GDCoinObjects2.length = 0;
gdjs.Level1Code.GDCoinObjects3.length = 0;
gdjs.Level1Code.GDCoinObjects4.length = 0;
gdjs.Level1Code.GDCoinObjects5.length = 0;
gdjs.Level1Code.GDCoinObjects6.length = 0;
gdjs.Level1Code.GDCoinUIObjects1.length = 0;
gdjs.Level1Code.GDCoinUIObjects2.length = 0;
gdjs.Level1Code.GDCoinUIObjects3.length = 0;
gdjs.Level1Code.GDCoinUIObjects4.length = 0;
gdjs.Level1Code.GDCoinUIObjects5.length = 0;
gdjs.Level1Code.GDCoinUIObjects6.length = 0;
gdjs.Level1Code.GDHiderObjects1.length = 0;
gdjs.Level1Code.GDHiderObjects2.length = 0;
gdjs.Level1Code.GDHiderObjects3.length = 0;
gdjs.Level1Code.GDHiderObjects4.length = 0;
gdjs.Level1Code.GDHiderObjects5.length = 0;
gdjs.Level1Code.GDHiderObjects6.length = 0;
gdjs.Level1Code.GDHider2Objects1.length = 0;
gdjs.Level1Code.GDHider2Objects2.length = 0;
gdjs.Level1Code.GDHider2Objects3.length = 0;
gdjs.Level1Code.GDHider2Objects4.length = 0;
gdjs.Level1Code.GDHider2Objects5.length = 0;
gdjs.Level1Code.GDHider2Objects6.length = 0;
gdjs.Level1Code.GDHider3Objects1.length = 0;
gdjs.Level1Code.GDHider3Objects2.length = 0;
gdjs.Level1Code.GDHider3Objects3.length = 0;
gdjs.Level1Code.GDHider3Objects4.length = 0;
gdjs.Level1Code.GDHider3Objects5.length = 0;
gdjs.Level1Code.GDHider3Objects6.length = 0;
gdjs.Level1Code.GDHider4Objects1.length = 0;
gdjs.Level1Code.GDHider4Objects2.length = 0;
gdjs.Level1Code.GDHider4Objects3.length = 0;
gdjs.Level1Code.GDHider4Objects4.length = 0;
gdjs.Level1Code.GDHider4Objects5.length = 0;
gdjs.Level1Code.GDHider4Objects6.length = 0;
gdjs.Level1Code.GDHider5Objects1.length = 0;
gdjs.Level1Code.GDHider5Objects2.length = 0;
gdjs.Level1Code.GDHider5Objects3.length = 0;
gdjs.Level1Code.GDHider5Objects4.length = 0;
gdjs.Level1Code.GDHider5Objects5.length = 0;
gdjs.Level1Code.GDHider5Objects6.length = 0;
gdjs.Level1Code.GDHider6Objects1.length = 0;
gdjs.Level1Code.GDHider6Objects2.length = 0;
gdjs.Level1Code.GDHider6Objects3.length = 0;
gdjs.Level1Code.GDHider6Objects4.length = 0;
gdjs.Level1Code.GDHider6Objects5.length = 0;
gdjs.Level1Code.GDHider6Objects6.length = 0;
gdjs.Level1Code.GDHiderCoinObjects1.length = 0;
gdjs.Level1Code.GDHiderCoinObjects2.length = 0;
gdjs.Level1Code.GDHiderCoinObjects3.length = 0;
gdjs.Level1Code.GDHiderCoinObjects4.length = 0;
gdjs.Level1Code.GDHiderCoinObjects5.length = 0;
gdjs.Level1Code.GDHiderCoinObjects6.length = 0;
gdjs.Level1Code.GDFlagTrajectoryObjects1.length = 0;
gdjs.Level1Code.GDFlagTrajectoryObjects2.length = 0;
gdjs.Level1Code.GDFlagTrajectoryObjects3.length = 0;
gdjs.Level1Code.GDFlagTrajectoryObjects4.length = 0;
gdjs.Level1Code.GDFlagTrajectoryObjects5.length = 0;
gdjs.Level1Code.GDFlagTrajectoryObjects6.length = 0;
gdjs.Level1Code.GDFlagPoleObjects1.length = 0;
gdjs.Level1Code.GDFlagPoleObjects2.length = 0;
gdjs.Level1Code.GDFlagPoleObjects3.length = 0;
gdjs.Level1Code.GDFlagPoleObjects4.length = 0;
gdjs.Level1Code.GDFlagPoleObjects5.length = 0;
gdjs.Level1Code.GDFlagPoleObjects6.length = 0;
gdjs.Level1Code.GDFlagBallObjects1.length = 0;
gdjs.Level1Code.GDFlagBallObjects2.length = 0;
gdjs.Level1Code.GDFlagBallObjects3.length = 0;
gdjs.Level1Code.GDFlagBallObjects4.length = 0;
gdjs.Level1Code.GDFlagBallObjects5.length = 0;
gdjs.Level1Code.GDFlagBallObjects6.length = 0;
gdjs.Level1Code.GDFlagObjects1.length = 0;
gdjs.Level1Code.GDFlagObjects2.length = 0;
gdjs.Level1Code.GDFlagObjects3.length = 0;
gdjs.Level1Code.GDFlagObjects4.length = 0;
gdjs.Level1Code.GDFlagObjects5.length = 0;
gdjs.Level1Code.GDFlagObjects6.length = 0;
gdjs.Level1Code.GDDoorObjects1.length = 0;
gdjs.Level1Code.GDDoorObjects2.length = 0;
gdjs.Level1Code.GDDoorObjects3.length = 0;
gdjs.Level1Code.GDDoorObjects4.length = 0;
gdjs.Level1Code.GDDoorObjects5.length = 0;
gdjs.Level1Code.GDDoorObjects6.length = 0;
gdjs.Level1Code.GDWallObjects1.length = 0;
gdjs.Level1Code.GDWallObjects2.length = 0;
gdjs.Level1Code.GDWallObjects3.length = 0;
gdjs.Level1Code.GDWallObjects4.length = 0;
gdjs.Level1Code.GDWallObjects5.length = 0;
gdjs.Level1Code.GDWallObjects6.length = 0;
gdjs.Level1Code.GDWindowObjects1.length = 0;
gdjs.Level1Code.GDWindowObjects2.length = 0;
gdjs.Level1Code.GDWindowObjects3.length = 0;
gdjs.Level1Code.GDWindowObjects4.length = 0;
gdjs.Level1Code.GDWindowObjects5.length = 0;
gdjs.Level1Code.GDWindowObjects6.length = 0;
gdjs.Level1Code.GDPoints100Objects1.length = 0;
gdjs.Level1Code.GDPoints100Objects2.length = 0;
gdjs.Level1Code.GDPoints100Objects3.length = 0;
gdjs.Level1Code.GDPoints100Objects4.length = 0;
gdjs.Level1Code.GDPoints100Objects5.length = 0;
gdjs.Level1Code.GDPoints100Objects6.length = 0;
gdjs.Level1Code.GDPoints400Objects1.length = 0;
gdjs.Level1Code.GDPoints400Objects2.length = 0;
gdjs.Level1Code.GDPoints400Objects3.length = 0;
gdjs.Level1Code.GDPoints400Objects4.length = 0;
gdjs.Level1Code.GDPoints400Objects5.length = 0;
gdjs.Level1Code.GDPoints400Objects6.length = 0;
gdjs.Level1Code.GDPoints800Objects1.length = 0;
gdjs.Level1Code.GDPoints800Objects2.length = 0;
gdjs.Level1Code.GDPoints800Objects3.length = 0;
gdjs.Level1Code.GDPoints800Objects4.length = 0;
gdjs.Level1Code.GDPoints800Objects5.length = 0;
gdjs.Level1Code.GDPoints800Objects6.length = 0;
gdjs.Level1Code.GDPoints2000Objects1.length = 0;
gdjs.Level1Code.GDPoints2000Objects2.length = 0;
gdjs.Level1Code.GDPoints2000Objects3.length = 0;
gdjs.Level1Code.GDPoints2000Objects4.length = 0;
gdjs.Level1Code.GDPoints2000Objects5.length = 0;
gdjs.Level1Code.GDPoints2000Objects6.length = 0;
gdjs.Level1Code.GDPoints4000Objects1.length = 0;
gdjs.Level1Code.GDPoints4000Objects2.length = 0;
gdjs.Level1Code.GDPoints4000Objects3.length = 0;
gdjs.Level1Code.GDPoints4000Objects4.length = 0;
gdjs.Level1Code.GDPoints4000Objects5.length = 0;
gdjs.Level1Code.GDPoints4000Objects6.length = 0;
gdjs.Level1Code.GDPoints5000Objects1.length = 0;
gdjs.Level1Code.GDPoints5000Objects2.length = 0;
gdjs.Level1Code.GDPoints5000Objects3.length = 0;
gdjs.Level1Code.GDPoints5000Objects4.length = 0;
gdjs.Level1Code.GDPoints5000Objects5.length = 0;
gdjs.Level1Code.GDPoints5000Objects6.length = 0;
gdjs.Level1Code.GDfallBorderObjects1.length = 0;
gdjs.Level1Code.GDfallBorderObjects2.length = 0;
gdjs.Level1Code.GDfallBorderObjects3.length = 0;
gdjs.Level1Code.GDfallBorderObjects4.length = 0;
gdjs.Level1Code.GDfallBorderObjects5.length = 0;
gdjs.Level1Code.GDfallBorderObjects6.length = 0;
gdjs.Level1Code.GDBucketObjects1.length = 0;
gdjs.Level1Code.GDBucketObjects2.length = 0;
gdjs.Level1Code.GDBucketObjects3.length = 0;
gdjs.Level1Code.GDBucketObjects4.length = 0;
gdjs.Level1Code.GDBucketObjects5.length = 0;
gdjs.Level1Code.GDBucketObjects6.length = 0;
gdjs.Level1Code.GDBucket2Objects1.length = 0;
gdjs.Level1Code.GDBucket2Objects2.length = 0;
gdjs.Level1Code.GDBucket2Objects3.length = 0;
gdjs.Level1Code.GDBucket2Objects4.length = 0;
gdjs.Level1Code.GDBucket2Objects5.length = 0;
gdjs.Level1Code.GDBucket2Objects6.length = 0;
gdjs.Level1Code.GDBucket3Objects1.length = 0;
gdjs.Level1Code.GDBucket3Objects2.length = 0;
gdjs.Level1Code.GDBucket3Objects3.length = 0;
gdjs.Level1Code.GDBucket3Objects4.length = 0;
gdjs.Level1Code.GDBucket3Objects5.length = 0;
gdjs.Level1Code.GDBucket3Objects6.length = 0;
gdjs.Level1Code.GDBucket4Objects1.length = 0;
gdjs.Level1Code.GDBucket4Objects2.length = 0;
gdjs.Level1Code.GDBucket4Objects3.length = 0;
gdjs.Level1Code.GDBucket4Objects4.length = 0;
gdjs.Level1Code.GDBucket4Objects5.length = 0;
gdjs.Level1Code.GDBucket4Objects6.length = 0;
gdjs.Level1Code.GDMarioObjects1.length = 0;
gdjs.Level1Code.GDMarioObjects2.length = 0;
gdjs.Level1Code.GDMarioObjects3.length = 0;
gdjs.Level1Code.GDMarioObjects4.length = 0;
gdjs.Level1Code.GDMarioObjects5.length = 0;
gdjs.Level1Code.GDMarioObjects6.length = 0;
gdjs.Level1Code.GDMarijuanaObjects1.length = 0;
gdjs.Level1Code.GDMarijuanaObjects2.length = 0;
gdjs.Level1Code.GDMarijuanaObjects3.length = 0;
gdjs.Level1Code.GDMarijuanaObjects4.length = 0;
gdjs.Level1Code.GDMarijuanaObjects5.length = 0;
gdjs.Level1Code.GDMarijuanaObjects6.length = 0;
gdjs.Level1Code.GDStonerObjects1.length = 0;
gdjs.Level1Code.GDStonerObjects2.length = 0;
gdjs.Level1Code.GDStonerObjects3.length = 0;
gdjs.Level1Code.GDStonerObjects4.length = 0;
gdjs.Level1Code.GDStonerObjects5.length = 0;
gdjs.Level1Code.GDStonerObjects6.length = 0;
gdjs.Level1Code.GDGameOverBGObjects1.length = 0;
gdjs.Level1Code.GDGameOverBGObjects2.length = 0;
gdjs.Level1Code.GDGameOverBGObjects3.length = 0;
gdjs.Level1Code.GDGameOverBGObjects4.length = 0;
gdjs.Level1Code.GDGameOverBGObjects5.length = 0;
gdjs.Level1Code.GDGameOverBGObjects6.length = 0;

gdjs.Level1Code.eventsList109(runtimeScene);

return;

}

gdjs['Level1Code'] = gdjs.Level1Code;
